from vocalset_csl.manifest import build_manifest, parse_vocalset_path


def test_parse_by_singer_path():
    row = parse_vocalset_path(
        "VocalSet1-2/by_singer/f2/arpeggios/belt/f2_arpeggios_belt_a.wav"
    )
    assert row["singer_id"] == "f2"
    assert row["context"] == "arpeggio"
    assert row["label"] == "belt"
    assert row["label_family"] == "production_technique"
    assert row["vowel"] == "a"
    assert row["parse_ok"] is True


def test_parse_official_verbose_singer_directory_when_filename_is_incomplete():
    row = parse_vocalset_path(
        "canonical/female2/arpeggios/fast_piano/fast_piano_arps_f.wav"
    )
    assert row["singer_id"] == "f2"
    assert row["context"] == "arpeggio"
    assert row["label"] == "fast_piano"
    assert row["parse_ok"] is True


def test_long_tone_and_alias_parsing():
    row = parse_vocalset_path("FULL/m11/long_tones/vibrado/m11_long_vibrado_e.wav")
    assert row["singer_id"] == "m11"
    assert row["context"] == "long_tone"
    assert row["raw_label"] == "vibrado"
    assert row["label"] == "vibrato"
    assert row["vowel"] == "e"


def test_longer_label_wins_over_trill():
    row = parse_vocalset_path("f1/long_tones/lip_trill/f1_long_lip_trill_o.wav")
    assert row["label"] == "lip_trill"


def test_manifest_has_stable_unique_path_ids():
    paths = [
        "f1/scales/belt/f1_scales_belt_a.wav",
        "m1/scales/belt/m1_scales_belt_a.wav",
    ]
    first = build_manifest(paths)
    second = build_manifest(reversed(paths))
    assert first["clip_id"].is_unique
    assert first.set_index("path")["clip_id"].to_dict() == second.set_index("path")[
        "clip_id"
    ].to_dict()


def test_clip_id_ignores_machine_specific_root():
    relative = "female2/arpeggios/belt/f2_arpeggios_belt_a.wav"
    first = parse_vocalset_path(f"C:/data/VocalSet/{relative}")
    second = parse_vocalset_path(f"E:/corpora/{relative}")
    assert first["canonical_path"] == relative
    assert first["clip_id"] == second["clip_id"]
