from vocalset_csl.feature_families import feature_family, group_feature_indices


def test_acoustic_family_mapping_is_exhaustive_and_disjoint():
    names = [
        "egemaps_F0semitoneFrom27.5Hz_sma3nz_amean",
        "egemaps_loudness_sma3_amean",
        "egemaps_HNRdBACF_sma3nz_amean",
        "egemaps_mfcc1_sma3_amean",
        "spectral_contrast_band2_std",
        "duration_seconds",
    ]
    groups = group_feature_indices(names)
    indices = sorted(index for values in groups.values() for index in values)
    assert indices == list(range(len(names)))
    assert feature_family(names[0]) == "pitch_modulation"
    assert feature_family(names[1]) == "energy_dynamics"
    assert feature_family(names[-1]) == "temporal_voicing"

