import zipfile

from vocalset_csl.zip_repair import FOUR_GIB, open_repaired, resolve_header_offset


def test_normal_zip_keeps_real_header_offsets(tmp_path):
    path = tmp_path / "normal.zip"
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("folder/example.txt", b"content")
    with zipfile.ZipFile(path) as archive:
        item = archive.getinfo("folder/example.txt")
        assert resolve_header_offset(archive, item) == item.header_offset
        assert open_repaired(archive, item).read() == b"content"


def test_resolver_corrects_exact_four_gib_offset_error(tmp_path):
    path = tmp_path / "malformed-in-memory.zip"
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("example.txt", b"voice")
    with zipfile.ZipFile(path) as archive:
        item = archive.getinfo("example.txt")
        item.header_offset += FOUR_GIB
        assert resolve_header_offset(archive, item) == item.header_offset - FOUR_GIB
        assert open_repaired(archive, item).read() == b"voice"

