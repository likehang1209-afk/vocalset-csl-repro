import numpy as np

from vocalset_csl.calibration import apply_temperature, fit_temperature
from vocalset_csl.fusion import fuse_probabilities, select_fusion
from vocalset_csl.metrics import classification_metrics


def test_temperature_preserves_normalized_probabilities():
    probability = np.array([[0.90, 0.10], [0.80, 0.20], [0.30, 0.70], [0.40, 0.60]])
    y = np.array([0, 1, 1, 0])
    temperature = fit_temperature(y, probability)
    scaled = apply_temperature(probability, temperature)
    assert temperature > 0
    np.testing.assert_allclose(scaled.sum(axis=1), 1.0)


def test_fusion_weight_semantics_are_unambiguous():
    acoustic = np.array([[0.9, 0.1], [0.1, 0.9]])
    ssl = np.array([[0.2, 0.8], [0.8, 0.2]])
    np.testing.assert_allclose(fuse_probabilities(acoustic, ssl, 1.0), acoustic)
    np.testing.assert_allclose(fuse_probabilities(acoustic, ssl, 0.0), ssl)


def test_inner_selection_prefers_informative_branch():
    y = np.array([0, 1] * 20)
    acoustic = np.where(y[:, None] == 0, [0.95, 0.05], [0.05, 0.95])
    ssl = np.full((len(y), 2), 0.5)
    choice = select_fusion(y, acoustic, ssl, class_count=2)
    assert choice.acoustic_weight >= 0.9


def test_metrics_report_present_and_global_estimands():
    y = np.array([0, 0, 1, 1])
    p = np.array([[0.8, 0.2, 0.0], [0.6, 0.4, 0.0], [0.2, 0.8, 0.0], [0.1, 0.9, 0.0]])
    result = classification_metrics(y, p, class_count=3)
    assert result["present_class_count"] == 2
    assert result["macro_f1_present"] == 1.0
    assert result["macro_f1_global"] < 1.0

