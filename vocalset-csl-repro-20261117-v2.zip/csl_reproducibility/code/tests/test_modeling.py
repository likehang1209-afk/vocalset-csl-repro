import numpy as np

from vocalset_csl.modeling import aligned_probability, build_model, default_specs


def test_every_default_model_family_produces_aligned_multiclass_probabilities():
    rng = np.random.default_rng(4)
    x = rng.normal(size=(36, 8))
    y = np.repeat(np.arange(3), 12)
    for branch in ("acoustic", "ssl", "early"):
        families = {spec.family: spec for spec in default_specs(branch)}
        for spec in families.values():
            model = build_model(spec, random_state=7)
            model.fit(x, y)
            probability = aligned_probability(model, x[:5], class_count=3)
            assert probability.shape == (5, 3)
            assert np.isfinite(probability).all()
            np.testing.assert_allclose(probability.sum(axis=1), 1.0)
