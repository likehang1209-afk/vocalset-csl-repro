import numpy as np

from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue


def test_clustered_inference_uses_singer_level_values():
    differences = np.array([0.01, 0.02, 0.03, 0.04, 0.05])
    result = paired_cluster_bootstrap(differences, replicates=1000, seed=3)
    assert result["cluster_count"] == 5
    assert result["ci95_low"] > 0
    assert paired_sign_flip_pvalue(differences) < 0.1

