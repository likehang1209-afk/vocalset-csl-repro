import numpy as np
import soundfile as sf

from vocalset_csl.audio_features import (
    extract_interpretable_features,
    singing_specific_features,
)


def synthetic_vibrato(sample_rate: int = 22050, seconds: float = 3.0) -> np.ndarray:
    time = np.arange(int(sample_rate * seconds)) / sample_rate
    instantaneous_frequency = 220.0 * 2 ** ((55.0 * np.sin(2 * np.pi * 5.5 * time)) / 1200.0)
    phase = 2 * np.pi * np.cumsum(instantaneous_frequency) / sample_rate
    return (0.2 * np.sin(phase)).astype(np.float32)


def test_singing_features_find_vibrato_band():
    features = singing_specific_features(synthetic_vibrato(), 22050)
    mapping = dict(zip(features.names, features.values))
    assert len(features.names) == len(features.values)
    assert 4.0 <= mapping["vibrato_rate_hz"] <= 7.0
    assert mapping["voiced_fraction"] > 0.8


def test_full_interpretable_extractor_has_named_schema(tmp_path):
    path = tmp_path / "vibrato.wav"
    sf.write(path, synthetic_vibrato(), 22050)
    features = extract_interpretable_features(path)
    assert len(features.names) == len(features.values)
    assert len(features.names) > 120
    assert len(set(features.names)) == len(features.names)
    assert "duration_seconds" in features.names
    assert any(name.startswith("egemaps_") for name in features.names)

