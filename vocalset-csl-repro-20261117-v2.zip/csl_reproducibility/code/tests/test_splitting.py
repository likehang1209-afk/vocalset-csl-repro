import numpy as np

from vocalset_csl.splitting import (
    count_test_occurrences,
    leave_one_group_out,
    stratified_group_folds,
)


def test_loso_tests_each_sample_once_without_group_leakage():
    groups = np.repeat(["f1", "f2", "m1", "m2"], 6)
    splits = list(leave_one_group_out(groups))
    assert len(splits) == 4
    np.testing.assert_array_equal(count_test_occurrences(splits, len(groups)), 1)
    for split in splits:
        assert set(groups[split.train]).isdisjoint(groups[split.test])


def test_inner_stratified_groups_are_disjoint():
    groups = np.repeat(np.arange(8), 6)
    y = np.tile(np.repeat(np.arange(3), 2), 8)
    splits = stratified_group_folds(y, groups, n_splits=4, seed=7)
    np.testing.assert_array_equal(count_test_occurrences(splits, len(y)), 1)
    for split in splits:
        assert set(groups[split.train]).isdisjoint(groups[split.test])
