import numpy as np

from vocalset_csl.modeling import ModelSpec
from vocalset_csl.nested import run_nested_loso, run_nested_single_branch
from vocalset_csl.splitting import leave_one_group_out


def test_nested_loso_smoke_and_prediction_coverage():
    rng = np.random.default_rng(11)
    singer_count = 5
    classes = 3
    per_singer_per_class = 4
    groups = np.repeat(np.arange(singer_count), classes * per_singer_per_class)
    y = np.tile(np.repeat(np.arange(classes), per_singer_per_class), singer_count)
    class_signal = np.eye(classes)[y]
    singer_shift = rng.normal(0.0, 0.2, size=(singer_count, classes))[groups]
    acoustic = class_signal + singer_shift + rng.normal(0.0, 0.15, size=class_signal.shape)
    ssl_good = np.column_stack([class_signal, class_signal]) + rng.normal(
        0.0, 0.12, size=(len(y), 2 * classes)
    )
    ssl_noise = rng.normal(size=(len(y), 2 * classes))
    clip_ids = np.array([f"clip_{index}" for index in range(len(y))])
    only_lr = (ModelSpec.create("lr", "logistic", c=1.0),)

    predictions, metrics, selections = run_nested_loso(
        acoustic,
        {"good": ssl_good, "noise": ssl_noise},
        y,
        groups,
        clip_ids,
        class_count=classes,
        inner_splits=2,
        seed=13,
        acoustic_specs=only_lr,
        ssl_specs=only_lr,
        early_specs=only_lr,
    )

    methods = predictions["method"].nunique()
    assert methods == 6
    assert len(predictions) == len(y) * methods
    assert predictions.groupby(["method", "clip_id"]).size().eq(1).all()
    assert len(metrics) == singer_count * methods
    assert len(selections) == singer_count
    assert selections["held_out_singer"].nunique() == singer_count
    assert selections["ssl_representation"].eq("good").mean() >= 0.8


def test_outer_labels_cannot_change_inner_selection():
    rng = np.random.default_rng(21)
    groups = np.repeat(np.arange(5), 18)
    y = np.tile(np.repeat(np.arange(3), 6), 5)
    signal = np.eye(3)[y] + rng.normal(0.0, 0.15, size=(len(y), 3))
    ssl = np.column_stack([signal, signal])
    clip_ids = np.array([f"c{index}" for index in range(len(y))])
    only_lr = (ModelSpec.create("lr", "logistic", c=1.0),)
    outer = next(iter(leave_one_group_out(groups)))
    kwargs = {
        "acoustic": signal,
        "ssl_representations": {"layer": ssl},
        "groups": groups,
        "clip_ids": clip_ids,
        "class_count": 3,
        "inner_splits": 2,
        "seed": 22,
        "acoustic_specs": only_lr,
        "ssl_specs": only_lr,
        "early_specs": only_lr,
        "outer_splits": [outer],
    }
    predictions_a, _, selections_a = run_nested_loso(y=y, **kwargs)
    changed = y.copy()
    changed[outer.test] = (changed[outer.test] + 1) % 3
    predictions_b, _, selections_b = run_nested_loso(y=changed, **kwargs)
    assert selections_a.to_dict(orient="records") == selections_b.to_dict(orient="records")
    np.testing.assert_allclose(
        np.stack(predictions_a.probabilities), np.stack(predictions_b.probabilities)
    )


def test_nested_single_branch_covers_every_clip_once_per_method():
    rng = np.random.default_rng(31)
    groups = np.repeat(np.arange(5), 12)
    y = np.tile(np.repeat(np.arange(3), 4), 5)
    features = np.eye(3)[y] + rng.normal(0.0, 0.2, size=(len(y), 3))
    clip_ids = np.array([f"single_{index}" for index in range(len(y))])
    only_lr = (ModelSpec.create("lr", "logistic", c=1.0),)
    predictions, metrics, selections = run_nested_single_branch(
        features,
        y,
        groups,
        clip_ids,
        class_count=3,
        inner_splits=2,
        specs=only_lr,
    )
    assert len(predictions) == 2 * len(y)
    assert predictions.groupby(["method", "clip_id"]).size().eq(1).all()
    assert len(metrics) == 10
    assert len(selections) == 5
