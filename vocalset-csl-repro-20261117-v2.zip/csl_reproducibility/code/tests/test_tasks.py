import pandas as pd
import pytest

from vocalset_csl.tasks import select_task


def test_select_task_applies_ontology_and_context_filter():
    frame = pd.DataFrame(
        {
            "label": ["belt", "belt", "breathy", "fast_forte"],
            "context": ["scale", "excerpt", "arpeggio", "scale"],
        }
    )
    config = {
        "tasks": {"production": ["belt", "breathy"]},
        "task_filters": {"production": {"contexts": ["scale", "arpeggio"]}},
    }
    selected, labels = select_task(frame, config, "production")
    assert labels == ["belt", "breathy"]
    assert selected[["label", "context"]].to_records(index=False).tolist() == [
        ("belt", "scale"),
        ("breathy", "arpeggio"),
    ]
    assert selected.target.tolist() == [0, 1]


def test_select_task_rejects_an_empty_declared_class():
    frame = pd.DataFrame({"label": ["belt"], "context": ["scale"]})
    config = {"tasks": {"production": ["belt", "breathy"]}}
    with pytest.raises(ValueError, match="breathy"):
        select_task(frame, config, "production")
