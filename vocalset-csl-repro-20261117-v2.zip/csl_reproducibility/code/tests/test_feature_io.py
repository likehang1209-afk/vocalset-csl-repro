import numpy as np

from vocalset_csl.feature_io import (
    align_feature_rows,
    exclude_named_features,
    load_feature_npz,
    save_feature_npz,
)


def test_feature_roundtrip_and_alignment(tmp_path):
    clip_ids = np.array(["c", "a", "b"])
    values = np.arange(12, dtype=np.float32).reshape(3, 4)
    path = tmp_path / "features.npz"
    save_feature_npz(path, clip_ids, values, ["f0", "f1", "f2", "f3"])
    loaded = load_feature_npz(path)
    aligned = align_feature_rows(np.array(["a", "b", "c"]), loaded["clip_ids"], loaded["values"])
    np.testing.assert_array_equal(aligned, values[[1, 2, 0]])


def test_exclude_named_features_is_explicit_and_order_preserving():
    values = np.arange(12).reshape(3, 4)
    selected, names = exclude_named_features(values, ["a", "duration_seconds", "b", "c"], ["duration_seconds"])
    assert names == ["a", "b", "c"]
    np.testing.assert_array_equal(selected, values[:, [0, 2, 3]])
