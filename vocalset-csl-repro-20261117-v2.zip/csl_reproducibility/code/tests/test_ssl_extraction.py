
import json

import numpy as np
import pytest

from vocalset_csl.representation_io import load_embedding_store
from vocalset_csl.ssl_extraction import EmbeddingStore, MockBackend, window_audio


def test_windowing_covers_short_and_long_audio():
    short, short_lengths = window_audio(np.ones(8000), 16000, 1.0, 0.5)
    assert short.shape == (1, 16000)
    assert short_lengths.tolist() == [8000]

    long, long_lengths = window_audio(np.ones(40000), 16000, 1.0, 0.5)
    assert long.shape[1] == 16000
    assert len(long) == 4
    assert long_lengths[-1] == 16000


def test_mock_backend_and_store_resume(tmp_path):
    windows, lengths = window_audio(np.sin(np.linspace(0, 100, 20000)), 16000, 1.0, 0.5)
    backend = MockBackend(16000)
    vectors = backend.extract(windows, lengths, batch_size=2)
    assert len(vectors) == 3
    assert all(vector.shape == (8,) for vector in vectors)

    clip_ids = np.array(["a", "b"])
    store = EmbeddingStore(
        tmp_path, clip_ids, backend.model_id, "local-mock-v1", 16000, 1.0, 0.5
    )
    store.initialise(vectors)
    store.write(0, vectors)
    assert store.complete_count() == 1

    reopened = EmbeddingStore(
        tmp_path, clip_ids, backend.model_id, "local-mock-v1", 16000, 1.0, 0.5
    )
    assert reopened.complete_count() == 1
    assert np.isfinite(reopened.layers[0][0]).all()
    assert np.isnan(reopened.layers[0][1]).all()

    with pytest.raises(ValueError, match="manifest_fingerprint|clip order"):
        EmbeddingStore(
            tmp_path,
            clip_ids[::-1],
            backend.model_id,
            "local-mock-v1",
            16000,
            1.0,
            0.5,
        )


def test_embedding_store_rejects_nonfinite_vectors(tmp_path):
    clip_ids = np.array(["a"])
    store = EmbeddingStore(
        tmp_path, clip_ids, "mock", "local-mock-v1", 16000, 1.0, 0.5
    )
    store.initialise([np.ones(4, dtype=np.float32)])
    with pytest.raises(ValueError, match="non-finite"):
        store.write(0, [np.array([1.0, np.nan, 2.0, 3.0], dtype=np.float32)])
    assert store.complete_count() == 0


def test_embedding_loader_requires_model_revision(tmp_path):
    clip_ids = np.array(["a"])
    store = EmbeddingStore(
        tmp_path, clip_ids, "mock", "local-mock-v1", 16000, 1.0, 0.5
    )
    store.initialise([np.ones(4, dtype=np.float32), np.ones(4, dtype=np.float32)])
    store.write(0, [np.ones(4, dtype=np.float32), np.ones(4, dtype=np.float32)])
    metadata = json.loads(store.metadata_path.read_text(encoding="utf-8"))
    del metadata["model_revision"]
    store.metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
    with pytest.raises(ValueError, match="model revision"):
        load_embedding_store(tmp_path, clip_ids, [1.0])
