"""Paper-20 frozen-encoder systems, with selection confined to inner singers."""
from __future__ import annotations

import argparse
import copy
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn import functional as F

from common import (clip_probabilities, digest, environment, file_hash, load_plan,
                    load_segments, read_json, report_record, seed_everything,
                    segment_indices, source_hashes, write_json)
from models import ZhouHead
from vocalset_csl.metrics import classification_metrics, selection_utility


def candidates(cfg, mode):
    layers = cfg["layers"] if mode == "scan" else [None]
    return [{"layer": layer, "learning_rate": lr,
             "name": f"{'mix' if layer is None else 'layer_'+str(layer).zfill(2)}_lr{lr:g}"}
            for layer in layers for lr in cfg["learning_rates"]]


def head_predict(head, x, indices, batch_size):
    head.eval()
    with torch.inference_mode():
        return np.concatenate([head(x[indices[i:i+batch_size]]).softmax(-1).cpu().numpy()
                               for i in range(0, len(indices), batch_size)])


def fit_head(x, targets, tr, va, segment_clip_ids, validation_ids, validation_targets,
             candidate, cfg, classes, seed, fixed_epochs=None):
    seed_everything(seed)
    head = ZhouHead(x.shape[2], classes, cfg["hidden_size"], cfg["dropout"],
                    None if candidate["layer"] is None else candidate["layer"]-1,
                    layers=x.shape[1]).to(x.device)
    optimizer = torch.optim.Adam(head.parameters(), lr=candidate["learning_rate"])
    y = torch.tensor(targets, dtype=torch.long, device=x.device)
    best_score, best_epoch, best_state, best_prob, stale = -np.inf, 0, None, None, 0
    epochs = fixed_epochs if fixed_epochs is not None else cfg["max_epochs"]
    for epoch in range(epochs):
        head.train()
        order = np.random.default_rng(seed+epoch).permutation(tr)
        for begin in range(0, len(order), cfg["batch_size"]):
            indices = order[begin:begin+cfg["batch_size"]]
            optimizer.zero_grad(set_to_none=True)
            loss = F.cross_entropy(head(x[indices]), y[indices])
            if not torch.isfinite(loss):
                raise FloatingPointError("Nonfinite MLP loss")
            loss.backward()
            optimizer.step()
        if fixed_epochs is not None:
            continue
        p = head_predict(head, x, va, cfg["batch_size"])
        p = clip_probabilities(p, [segment_clip_ids[i] for i in va], validation_ids)
        score = selection_utility(classification_metrics(validation_targets, p, classes))
        if score > best_score + 1e-12:
            best_score, best_epoch = score, epoch+1
            best_prob = p
            best_state = copy.deepcopy(head.state_dict())
            stale = 0
        else:
            stale += 1
        if stale >= cfg["patience"]:
            break
    if fixed_epochs is not None:
        return head, {"epochs": epochs}, None
    if best_state is None:
        raise RuntimeError("No valid training checkpoint")
    head.load_state_dict(best_state)
    return head, {"best_epoch": best_epoch, "inner_utility": best_score,
                  "epochs_executed": epoch+1}, best_prob


def load_features(folder, model, plan, segments):
    meta = read_json(folder / "features.json")
    expected = dict(meta)
    fingerprint = expected.pop("fingerprint")
    if digest(expected) != fingerprint:
        raise ValueError("Feature metadata changed")
    if meta["smoke_only"]:
        raise ValueError("Smoke features cannot be used for a reported experiment")
    if meta["model"] != model or meta["config"] != plan["protocol"]["models"][model]:
        raise ValueError("Backbone identity mismatch")
    if meta["plan_fingerprint"] != plan["fingerprint"] or meta["segments_fingerprint"] != segments["fingerprint"]:
        raise ValueError("Feature provenance mismatch")
    if meta["segment_ids"] != [r["segment_id"] for r in segments["segments"]]:
        raise ValueError("Feature/segment row alignment mismatch")
    path = folder / "layer_means.npy"
    if file_hash(path) != meta["sha256"]:
        raise ValueError("Feature contents changed")
    x = np.load(path, allow_pickle=False)
    if list(x.shape) != meta["shape"] or not np.isfinite(x).all():
        raise ValueError("Invalid features")
    return x, meta


def run(args):
    plan = load_plan(args.plan)
    cfg = plan["protocol"]["zhou"]
    fold = plan["folds"][args.fold]
    segments = load_segments(args.audio, plan)
    values, feature_meta = load_features(args.features, args.model, plan, segments)
    x = torch.tensor(values, dtype=torch.float32, device=args.device)
    target_map = {r["clip_id"]: r["target"] for r in plan["clips"]}
    targets = np.array([r["target"] for r in segments["segments"]])
    segment_ids = [r["clip_id"] for r in segments["segments"]]
    dest = args.output / ("smoke" if args.smoke else "zhou") / args.model / args.mode / f"fold_{args.fold:02d}"
    dest.mkdir(parents=True, exist_ok=True)
    identity = {"plan": plan["fingerprint"], "features": feature_meta["fingerprint"],
                "source_hashes": source_hashes(), "environment": environment(),
                "model": args.model, "mode": args.mode, "fold": args.fold, "smoke": args.smoke}
    lock = dest / "run_lock.json"
    if lock.exists() and read_json(lock) != identity:
        raise RuntimeError("Stale run identity")
    write_json(lock, identity)
    if (dest / "result.json").exists():
        print("Completed result already exists", flush=True)
        return
    choices = []
    seed = plan["protocol"]["training_seed"] + args.fold * 1000
    start = time.perf_counter()
    grid = candidates(cfg, args.mode)
    if args.smoke:
        grid = grid[:1]
        cfg = {**cfg, "max_epochs": 2, "patience": 2}
    for candidate in grid:
        records = []
        for index, inner in enumerate(fold["inner"]):
            if args.smoke and index > 0:
                break
            path = dest / "candidates" / candidate["name"] / f"inner_{index}.json"
            if path.exists():
                record = read_json(path)
                if record["identity"] != digest(identity) or record["clip_ids"] != inner["validation"]:
                    raise ValueError("Stale inner checkpoint")
            else:
                tr = segment_indices(segments, inner["train"])
                va = segment_indices(segments, inner["validation"])
                vy = np.array([target_map[i] for i in inner["validation"]])
                _, diagnostics, prob = fit_head(x, targets, tr, va, segment_ids,
                    inner["validation"], vy, candidate, cfg, len(plan["labels"]), seed+index)
                record = {"identity": digest(identity), "candidate": candidate,
                          "clip_ids": inner["validation"], "probabilities": prob.tolist(),
                          "diagnostics": diagnostics}
                write_json(path, record)
            records.append(record)
        if args.smoke:
            write_json(dest / "smoke_report.json", {"identity": identity,
                       "seconds": time.perf_counter()-start, "outer_test_evaluated": False})
            return
        by_id = {clip: p for record in records for clip, p in zip(record["clip_ids"], record["probabilities"])}
        if set(by_id) != set(fold["train"]):
            raise ValueError("Incomplete inner OOF predictions")
        oof = np.array([by_id[i] for i in fold["train"]])
        y = np.array([target_map[i] for i in fold["train"]])
        utility = selection_utility(classification_metrics(y, oof, len(plan["labels"])))
        epochs = max(1, int(np.floor(np.median([r["diagnostics"]["best_epoch"] for r in records])+0.5)))
        choices.append({"candidate": candidate, "inner_utility": utility, "refit_epochs": epochs})
        print(f"{args.model} {args.mode} fold={args.fold}: {candidate['name']} done", flush=True)
    selected = min(choices, key=lambda r: (-r["inner_utility"], r["candidate"]["name"]))
    tr = segment_indices(segments, fold["train"])
    head, _, _ = fit_head(x, targets, tr, None, segment_ids, None, None,
        selected["candidate"], cfg, len(plan["labels"]), seed+999, fixed_epochs=selected["refit_epochs"])
    te = segment_indices(segments, fold["test"])
    probs = head_predict(head, x, te, cfg["batch_size"])
    probs = clip_probabilities(probs, [segment_ids[i] for i in te], fold["test"])
    details = {"selected": selected, "candidates": choices, "seed": seed,
               "feature_fingerprint": feature_meta["fingerprint"], "config": cfg}
    write_json(dest / "result.json", report_record(plan, fold, f"zhou_{args.model}_{args.mode}",
               fold["test"], probs, details, time.perf_counter()-start))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("plan", "audio", "features", "output"):
        parser.add_argument("--"+name, type=Path, required=True)
    parser.add_argument("--model", choices=["muq", "musicfm"], required=True)
    parser.add_argument("--mode", choices=["scan", "weighted"], required=True)
    parser.add_argument("--fold", choices=range(20), type=int, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable")
    torch.set_num_threads(4)
    run(args)


if __name__ == "__main__":
    main()
