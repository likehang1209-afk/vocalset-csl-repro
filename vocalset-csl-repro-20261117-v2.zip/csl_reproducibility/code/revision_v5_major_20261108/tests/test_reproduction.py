"""CPU checks; synthetic fixtures are not manuscript experiments."""
import copy
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np
import torch
from torch import nn

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from common import clip_probabilities, digest, load_plan, validate_plan, write_json, seed_everything
from collect_results import collect
from models import LayerMix, YamamotoSystem, ZhouHead, class_weights
from prepare_audio import segment_bounds
from train_yamamoto import weighted_step, checkpoint_rng, restore_checkpoint_rng
from train_zhou import candidates, fit_head


class ReproductionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_segment_policy(self):
        self.assertEqual(segment_bounds(900, 100, 3), [(0,300),(300,600),(600,900)])
        self.assertEqual(segment_bounds(920, 100, 3), [(0,300),(300,600),(600,900)])
        self.assertEqual(segment_bounds(200, 100, 3), [(0,200)])
        with self.assertRaises(ValueError):
            segment_bounds(0,100,3)

    def test_clip_aggregation_and_coverage(self):
        p = np.array([[.9,.1],[.2,.8],[.5,.5]])
        out = clip_probabilities(p, ["a","b","a"], ["b","a"])
        np.testing.assert_allclose(out, [[.2,.8],[.7,.3]])
        with self.assertRaises(ValueError):
            clip_probabilities(p,["a","b","a"],["a"])
        with self.assertRaises(ValueError):
            clip_probabilities(p*2,["a","b","a"],["a","b"])

    def test_layer_mix_commutes_with_mean(self):
        mix = LayerMix(3)
        x = torch.randn(2,3,5,7)
        w = mix.logits.softmax(0)
        expected = (x * w[None,:,None,None]).sum(1).mean(1)
        torch.testing.assert_close(mix(x.mean(2)), expected)
        self.assertEqual(ZhouHead(7,6,layer=1)(x.mean(2)).shape, (2,6))
        self.assertEqual(ZhouHead(7,6,layers=3)(x.mean(2)).shape, (2,6))

    def test_training_only_loss_weights(self):
        weights = class_weights([0,0,0,1],2,.2)
        torch.testing.assert_close(weights, torch.tensor([3.,1.]).pow(-.2))
        with self.assertRaises(ValueError):
            class_weights([0,0],2)

    def test_gradient_accumulation_weighted_denominator(self):
        class Toy(nn.Module):
            def __init__(self):
                super().__init__()
                self.linear = nn.Linear(4,3)
            def forward(self, x, mask):
                return self.linear(x)
        a = Toy()
        b = copy.deepcopy(a)
        x, y, w = torch.randn(8,4), torch.tensor([0,0,0,0,0,1,2,2]), torch.tensor([.1,.8,.3])
        op_a, op_b = torch.optim.SGD(a.parameters(),lr=.05), torch.optim.SGD(b.parameters(),lr=.05)
        weighted_step(a, op_a, (x,torch.ones_like(x)),y,w,3)
        loss = nn.functional.cross_entropy(b(x,None),y,weight=w)
        loss.backward()
        op_b.step()
        for p,q in zip(a.parameters(),b.parameters()):
            torch.testing.assert_close(p,q,atol=1e-6,rtol=1e-6)

    def test_actual_hf_architectures_freeze_unfreeze(self):
        from transformers import WavLMConfig, WavLMModel, Data2VecAudioConfig, Data2VecAudioModel
        settings = dict(hidden_size=8,num_hidden_layers=2,num_attention_heads=2,
                        intermediate_size=16,conv_dim=(8,8),conv_stride=(2,2),conv_kernel=(4,4),
                        num_conv_pos_embeddings=8,num_conv_pos_embedding_groups=2,
                        conv_pos_kernel_size=7,mask_time_prob=0.0,
                        hidden_dropout=0.0,attention_dropout=0.0,layerdrop=0.0)
        for config_type, model_type in [(WavLMConfig,WavLMModel),(Data2VecAudioConfig,Data2VecAudioModel)]:
            system = YamamotoSystem(model_type(config_type(**settings)),3)
            x, mask = torch.randn(4,256), torch.ones(4,256,dtype=torch.long)
            mask[-1,200:] = 0
            original = {k:v.detach().clone() for k,v in system.backbone.named_parameters()}
            optimizer = torch.optim.Adam([p for p in system.parameters() if p.requires_grad],lr=.001)
            system.train()
            weighted_step(system,optimizer,(x,mask),torch.tensor([0,1,2,1]),torch.ones(3),2)
            for k,v in system.backbone.named_parameters():
                torch.testing.assert_close(v,original[k])
            system.set_stage(2)
            self.assertTrue(system.backbone.training)
            self.assertFalse(system.backbone.feature_extractor.training)
            self.assertFalse(system.backbone.feature_projection.training)
            optimizer = torch.optim.Adam([p for p in system.parameters() if p.requires_grad],lr=.001)
            weighted_step(system,optimizer,(x,mask),torch.tensor([0,1,2,1]),torch.ones(3),2)
            changed = [k for k,v in system.backbone.named_parameters() if not torch.equal(v,original[k])]
            self.assertTrue(changed)
            self.assertTrue(all(k.startswith("encoder.") for k in changed))
            system.eval()
            self.assertFalse(system.backbone.encoder.training)

    def test_mlp_inner_selection_and_refit(self):
        x = torch.randn(24,3,8)
        targets = np.tile([0,1,2],8)
        ids = [str(i) for i in range(24)]
        cfg = dict(hidden_size=12,dropout=0.0,batch_size=8,max_epochs=3,patience=2)
        candidate = {"layer":None,"learning_rate":.001}
        head, diag, p = fit_head(x,targets,np.arange(18),np.arange(18,24),ids,
                         ids[18:],targets[18:],candidate,cfg,3,1)
        self.assertTrue(1 <= diag["best_epoch"] <= 3)
        np.testing.assert_allclose(p.sum(1),1,atol=1e-6)
        _, diag2, p2 = fit_head(x,targets,np.arange(24),None,ids,None,None,
                               candidate,cfg,3,1,fixed_epochs=2)
        self.assertEqual(diag2["epochs"],2)
        self.assertIsNone(p2)

    def test_candidate_count_and_full_layer_scan(self):
        cfg = {"layers":list(range(1,13)),"learning_rates":[1e-4,1e-3,1e-2]}
        self.assertEqual(len(candidates(cfg,"scan")),36)
        self.assertEqual(len(candidates(cfg,"weighted")),3)

    def test_resume_restores_specaugment_and_dropout_rng(self):
        from transformers import WavLMConfig, WavLMModel, Data2VecAudioConfig, Data2VecAudioModel
        settings = dict(hidden_size=8,num_hidden_layers=2,num_attention_heads=2,
                        intermediate_size=16,conv_dim=(8,8),conv_stride=(2,2),conv_kernel=(4,4),
                        num_conv_pos_embeddings=8,num_conv_pos_embedding_groups=2,
                        conv_pos_kernel_size=7,mask_time_prob=0.3,mask_time_length=2,
                        hidden_dropout=0.1,attention_dropout=0.1,layerdrop=0.0)
        devices = ["cpu"] + (["cuda"] if torch.cuda.is_available() else [])
        cases = [(c, m, d) for c, m in [(WavLMConfig,WavLMModel),(Data2VecAudioConfig,Data2VecAudioModel)]
                 for d in devices]
        for config_type, model_type, device in cases:
            with self.subTest(model=model_type.__name__, device=device), tempfile.TemporaryDirectory() as directory:
                seed_everything(91)
                original = YamamotoSystem(model_type(config_type(**settings)),3).to(device)
                original.set_stage(2)
                optimizer = torch.optim.Adam([p for p in original.parameters() if p.requires_grad],lr=.001)
                x = torch.randn(4,256,device=device)
                mask = torch.ones(4,256,dtype=torch.long,device=device)
                y, weights = torch.tensor([0,1,2,1],device=device), torch.ones(3,device=device)
                weighted_step(original,optimizer,(x,mask),y,weights,2)
                path = Path(directory)/"checkpoint.pt"
                torch.save({"model":original.state_dict(), "optimizer":optimizer.state_dict(),
                            "rng":checkpoint_rng(device)},path)
                weighted_step(original,optimizer,(x,mask),y,weights,2)
                expected = copy.deepcopy(original.state_dict())
                restored = YamamotoSystem(model_type(config_type(**settings)),3).to(device)
                restored.set_stage(2)
                restored_optimizer = torch.optim.Adam([p for p in restored.parameters() if p.requires_grad],lr=.001)
                checkpoint = torch.load(path,map_location="cpu",weights_only=False)
                restored.load_state_dict(checkpoint["model"])
                restored_optimizer.load_state_dict(checkpoint["optimizer"])
                restore_checkpoint_rng(checkpoint["rng"],device)
                weighted_step(restored,restored_optimizer,(x,mask),y,weights,2)
                for name, value in restored.state_dict().items():
                    tolerance = 1e-6 if device == "cuda" else 0
                    torch.testing.assert_close(value,expected[name],rtol=tolerance,atol=tolerance)

    def test_incomplete_rng_checkpoint_is_rejected(self):
        with self.assertRaises(RuntimeError):
            restore_checkpoint_rng({"torch":torch.get_rng_state()},"cpu")

    def test_collector_rejects_empty_and_smoke(self):
        with self.assertRaises(ValueError):
            collect({}, [])
        with self.assertRaises(ValueError):
            collect({}, [Path("smoke/result.json")])

    def test_plan_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)/"plan.json"
            write_json(path,{"clips":[],"fingerprint":"invalid"})
            with self.assertRaises(ValueError):
                load_plan(path)

    def test_real_muq_features_train_both_heads(self):
        path = Path('data/major_revision_20261108/cpu_interface_checks_v1/muq_features/layer_means.npy')
        self.check_real_features_train_both_heads(path, "MuQ")

    def test_real_musicfm_features_train_both_heads(self):
        path = Path('data/major_revision_20261108/cpu_interface_checks_v2/musicfm_features/layer_means.npy')
        self.check_real_features_train_both_heads(path, "MusicFM")

    def check_real_features_train_both_heads(self, path, model):
        if not path.exists():
            self.skipTest(f"Optional local pretrained {model} smoke features absent")
        x = torch.tensor(np.load(path,allow_pickle=False))
        self.assertEqual(tuple(x.shape[1:]),(12,1024))
        # Synthetic labels here check numerical/shape compatibility, not accuracy.
        y = torch.arange(len(x)) % 6
        for layer in (5,None):
            head = ZhouHead(1024,6,layer=layer)
            optimizer = torch.optim.Adam(head.parameters(),lr=.001)
            for _ in range(2):
                optimizer.zero_grad(set_to_none=True)
                loss = nn.functional.cross_entropy(head(x),y)
                self.assertTrue(torch.isfinite(loss))
                loss.backward()
                self.assertTrue(all(torch.isfinite(p.grad).all() for p in head.parameters() if p.grad is not None))
                optimizer.step()

    def test_real_plan_has_no_leakage_and_matches_archived_first_fold(self):
        root = Path(__file__).resolve().parents[1]
        path = root/"artifacts/plan.json"
        if not path.exists():
            self.skipTest("Real plan not generated")
        plan = load_plan(path)
        self.assertEqual(len(plan["clips"]),1206)
        old = root.parent/"revision_v4_major_20260922/replay_diagnosis_20260923/sklearn172/f1.json"
        if old.exists():
            import json
            historical = json.loads(old.read_text())
            self.assertEqual([f["validation"] for f in plan["folds"][0]["inner"]],
                             historical["inner_validation_ids"])
        bad = copy.deepcopy(plan)
        bad["folds"][0]["test"].append(bad["folds"][0]["train"][0])
        with self.assertRaises(ValueError):
            validate_plan(bad)


if __name__ == "__main__":
    unittest.main()
