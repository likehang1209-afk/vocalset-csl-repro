# Retrospective fusion-decision condition diagnostic

Date: 2026-11-15. This plan precedes the new condition summaries, but the prior
performance and error-complementarity results are already known. It is not a
preregistration or confirmatory study.

## Scope and preservation

Read only the existing 60 outer-fold records: 20 singers, 1,206 unique clips,
six labels, and schedules 20260824, 30260824, 40260824. The 3,618 clip/schedule
rows are repeated observations, not independent samples. Use the stored
calibrated branches, actual fusion family and actual training-selected weight.
No training, model inference, candidate search, recalibration, threshold/weight
optimization, new gating model, cloud/GPU, downloads, manuscript replacement,
publication or submission. The reliability/deferral proposal is NOT included.

Check existing audit receipts and hashes, exact alignment, all five probability
branches, fusion replay, and agreement with the completed complementarity table.
Freeze a separate input manifest including prior protected evidence, execution
and failure records, original analyses, and the latest delivery_final files.
Verify the same hashes after analysis. New output files use exclusive creation.

## Mathematical object

For each clip and its true class y, derive the subset of w in [0,1] where y
wins under the archived fusion family and fixed calibrated probabilities.
For arithmetic fusion the pairwise margin against j is
  w*(a_y-a_j) + (1-w)*(s_y-s_j).
For geometric fusion replace probabilities by their archived clipped logs.
Intersect all five affine inequalities, not just the branch top-1 pair.
Account for the original first-index argmax tie rule: the inequality is strict
when j precedes y, weak otherwise. Store bounds, endpoint inclusion, binding
competitors, emptiness, and all rival margins. These are standard properties
of the existing fusion, not a proposed theorem or new algorithm.

The geometry uses the same clipping/normalization as the archived replay.
Check boundaries against direct interpolation away from numerical ties.
Report roots within 1e-10 as near-boundary in conflict comparisons rather
than silently treating numerical equality as robust incompatibility.

## Questions and fixed summaries

1. Which actual acoustic-only correct opportunities are retained or missed,
   and which SSL-only correct predictions are harmed? Quantify distances from
   the actual weight to the relevant boundary, with all classes/singers shown.
2. Within the SAME fold and family, is the weight needed to rescue a missed
   acoustic-only opportunity greater than the upper bound of at least one
   currently retained SSL-only correct case? Such a clear conflict means
   increasing this one shared weight cannot rescue that opportunity without
   introducing at least one additional SSL-only error. It says nothing about
   other fusion families, retraining, individual gating or net macro-F1.
3. Also inventory every acoustic-only versus SSL-only pair within a fold;
   report robustly incompatible, compatible and near-boundary pairs. Pairs
   are not independent; no pair-level significance tests.
4. Does the binding competitor differ from the other branch's top-1 label?
   Report all such cases rather than assuming a binary switching problem.
5. Include both-correct and both-wrong groups. The latter may have an empty
   or interior true-class interval; preserve the two known third-label
   corrections per schedule without equating all corrections to acoustic
   top-1 selection.
6. Report all three schedules, all 20 singers, all six labels, and clip-level
   cross-schedule consistency. No selected best seed, class or singer.

No performance-versus-weight sweep, optimum, new fusion score or deployment
threshold will be estimated. If interval checks interpolate additional weights,
they are mathematical tests on stored arrays, not new model experiments.

## Units and uncertainty

Keep the prior macro-F1, 13/37 Holm families and other controls unchanged.
No new p-values. Use 10,000 singer bootstrap draws, RNG seed 2026111501, for
three preselected descriptive quantities only:

- Blocked missed-opportunity count / all clips, averaged over schedules within
  each singer, then equally across all 20 singers.
- Within-singer blocked missed / all missed, pooling the three schedule counts
  before equally averaging eligible singers. No-missed singers are NA, not 0.
- Within-singer robust-conflict pairs / all acoustic-only versus SSL-only pairs,
  pooling schedules before equally averaging eligible singers.

Intervals are exploratory pointwise intervals, not simultaneous guarantees;
eligible-singer counts must be given. They do not eliminate dependence from
overlapping LOSO training sets or establish external validity.

## Verification and decision rule

Add synthetic tests covering arithmetic/geometric boundaries, multiclass
binding competitors, ties, empty/interior intervals and the no-overwrite rule.
Use a separate scalar implementation reading original JSON to verify boundaries,
pair counts and reported summaries without importing the main interval solver.
Verify actual labels and the previous correction/harm counts exactly.

Deliver detailed CSVs, a diagnostic figure, a Chinese findings/novelty assessment,
and proposed English additions in a separate file, not inserted in the paper.
The criterion for a substantive addition is an empirical condition not supplied
by the previous four-state counts alone, with its across-singer distribution.
If findings merely restate the interpolation identity, are weakly supported,
or rely on a few selected cases, recommend supplement-only or no enlargement.
Retain all unfavorable outcomes. No claim of physiological cause, information-
theoretic independence, universal fusion failure, novel formula or new optimal
system is permitted.
