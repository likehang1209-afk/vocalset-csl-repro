"""Read-only diagnostics of archived calibrated probability interpolation."""
from __future__ import annotations

import os
for _name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REV = HERE.parent
OLD = REV / "error_complementarity_20261114"
ANCHOR = REV / "anchor_multiseed_20261111"
RESULTS = ANCHOR / "results_v3"
sys.path.insert(0, str(OLD))
import analyze_saved as old

EPS = 1e-10
SEEDS = old.SEEDS
LABELS = old.LABELS


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    return old.sha(path)


def save_json(path, value):
    old.save_json(path, value)


def frame_save(path, rows):
    old.save_csv(path, rows)


def freeze():
    previous = REV / "writing/round8_reviewfix_20261115/protected_input_hashes.json"
    paths = set()
    for name, expected in read(previous).items():
        path = Path(name)
        if sha(path) != expected:
            raise ValueError("Prior protected evidence changed: " + name)
        paths.add(path.resolve())
    paths.add(previous)
    for folder in (ANCHOR, OLD, REV / "writing/round8_reviewfix_20261115/delivery_final",
                   REV / "innovation_strategy_20261115"):
        paths.update(p.resolve() for p in folder.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    files = {str(p): {"bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(paths)}
    source = {p.name: sha(p) for p in HERE.glob("*.py")}
    manifest = {"created_at_utc": datetime.now(timezone.utc).isoformat(),
                "plan_sha256": sha(HERE / "PLAN.md"), "sources": source, "files": files,
                "total_bytes": sum(v["bytes"] for v in files.values())}
    save_json(HERE / "input_manifest.json", manifest)
    print(json.dumps({"protected_files": len(files), "bytes": manifest["total_bytes"]}))


def check_inputs():
    m = read(HERE / "input_manifest.json")
    if sha(HERE / "PLAN.md") != m["plan_sha256"]:
        raise ValueError("Frozen plan changed")
    for name, expected in m["sources"].items():
        if sha(HERE / name) != expected:
            raise ValueError("Frozen diagnostic source changed: " + name)
    for name, expected in m["files"].items():
        path = Path(name)
        if path.stat().st_size != expected["bytes"] or sha(path) != expected["sha256"]:
            raise ValueError("Protected input changed: " + name)
    return len(m["files"])


def scores(a, s, family):
    a, s = old.normalized([a])[0], old.normalized([s])[0]
    if family == "geometric":
        return np.log(np.clip(a, 1e-12, 1)), np.log(np.clip(s, 1e-12, 1))
    if family != "arithmetic":
        raise ValueError("Unknown family")
    return a, s


def truth_interval(a, s, y, family):
    aa, ss = scores(a, s, family)
    lower, upper, lower_closed, upper_closed = 0.0, 1.0, True, True
    lower_rivals, upper_rivals, constraints = [], [], []
    impossible = False
    for j in range(len(aa)):
        if j == y:
            continue
        am, sm = float(aa[y] - aa[j]), float(ss[y] - ss[j])
        slope, closed = am - sm, j > y
        root = None if slope == 0 else -sm / slope
        sense = "constant" if slope == 0 else "lower" if slope > 0 else "upper"
        constraints.append({"rival": j, "a_margin": am, "s_margin": sm,
                            "slope": slope, "root": root, "sense": sense,
                            "root_included": int(closed)})
        if slope == 0:
            impossible |= sm < 0 or (sm == 0 and not closed)
        elif slope > 0:
            if root > lower:
                lower, lower_closed, lower_rivals = root, closed, [j]
            elif root == lower:
                lower_closed &= closed
                lower_rivals.append(j)
        else:
            if root < upper:
                upper, upper_closed, upper_rivals = root, closed, [j]
            elif root == upper:
                upper_closed &= closed
                upper_rivals.append(j)
    empty = impossible or lower > upper or (lower == upper and not (lower_closed and upper_closed))
    return {"lower": lower, "upper": upper, "lower_closed": int(lower_closed),
            "upper_closed": int(upper_closed), "empty": int(empty),
            "lower_rivals": lower_rivals, "upper_rivals": upper_rivals}, constraints


def contains(interval, weight):
    return not interval["empty"] and (
        weight > interval["lower"] or (weight == interval["lower"] and interval["lower_closed"])
    ) and (weight < interval["upper"] or (weight == interval["upper"] and interval["upper_closed"]))


def summarize(group):
    ac = group.branch_state.eq("acoustic_only")
    sc = group.branch_state.eq("ssl_only")
    missed = ac & group.fusion_correct.eq(0)
    pairs = int(group.pair_total.sum())
    return {"n": len(group), "opportunities": int(ac.sum()),
            "captured": int((ac & group.fusion_correct.eq(1)).sum()),
            "missed": int(missed.sum()), "ssl_only": int(sc.sum()),
            "harmed": int((sc & group.fusion_correct.eq(0)).sum()),
            "blocked_missed": int((missed & group.additional_harms_min.gt(0)).sum()),
            "unblocked_missed": int((missed & group.additional_harms_min.eq(0)).sum()),
            "pair_total": pairs, "conflict_pairs": int(group.pair_conflicts.sum()),
            "near_pairs": int(group.pair_near.sum()),
            "non_top1_lower_binding": int(group.lower_non_top1.sum()),
            "non_top1_upper_binding": int(group.upper_non_top1.sum()),
            "both_wrong_feasible": int((group.branch_state.eq("both_wrong") & group.empty.eq(0)).sum()),
            "both_wrong_rescued": int((group.branch_state.eq("both_wrong") & group.fusion_correct.eq(1)).sum()),
            "blocked_missed_rate": float((missed & group.additional_harms_min.gt(0)).mean()),
            "missed_weight_gap_median": float(group.loc[missed, "lower_minus_actual"].median()) if missed.any() else None,
            "opportunity_lower_median": float(group.loc[ac, "lower"].median()) if ac.any() else None,
            "ssl_only_upper_median": float(group.loc[sc, "upper"].median()) if sc.any() else None}


def grouped(frame, keys):
    out = []
    for identity, group in frame.groupby(keys, sort=True):
        identity = identity if isinstance(identity, tuple) else (identity,)
        out.append(dict(zip(keys, identity), **summarize(group)))
    return pd.DataFrame(out)


def analyze():
    protected = check_inputs()
    prior_frame, _, _, prior_audit = old.load_predictions()
    prior = prior_frame.set_index(["seed", "clip_id"])
    records, rival_rows, pair_rows = [], [], []
    max_replay_error, probes, near_actual = 0.0, 0, 0
    for seed in SEEDS:
        for path in sorted((RESULTS / f"seed_{seed}").glob("fold_*.json")):
            r = read(path)
            family, weight = r["fusion"]["family"], r["fusion"]["acoustic_weight"]
            a = np.asarray(r["probabilities"]["acoustic_calibrated"])
            s = np.asarray(r["probabilities"]["ssl_calibrated"])
            f = np.asarray(r["probabilities"]["late_fusion_calibrated"])
            replay = old.replay_fusion(a, s, weight, family)
            max_replay_error = max(max_replay_error, float(np.max(np.abs(replay - f))))
            fold_rows = []
            for i, (cid, y) in enumerate(zip(r["clip_ids"], r["y_true"])):
                pa, ps, pf = int(a[i].argmax()), int(s[i].argmax()), int(f[i].argmax())
                interval, constraints = truth_interval(a[i], s[i], y, family)
                margins = [c["s_margin"] + weight * c["slope"] for c in constraints]
                if min(abs(m) for m in margins) < EPS:
                    near_actual += 1
                if contains(interval, weight) != (pf == y):
                    raise ValueError("Actual interval prediction mismatch")
                # Direct interpolation checks test geometry, never select a weight.
                boundaries = sorted({0.0, 1.0, *(c["root"] for c in constraints
                                                if c["root"] is not None and 0 < c["root"] < 1)})
                checks = [0.0, 1.0, weight] + [(x + z) / 2 for x, z in zip(boundaries, boundaries[1:])]
                for w in checks:
                    direct = int(old.replay_fusion(a[i:i+1], s[i:i+1], w, family)[0].argmax())
                    if contains(interval, w) != (direct == y):
                        raise ValueError("Interval interior/endpoint replay mismatch")
                    probes += 1
                previous = prior.loc[(seed, cid)]
                assert (pa, ps, pf) == tuple(int(previous[k]) for k in ("acoustic_pred", "ssl_pred", "fusion_pred"))
                state = str(previous.branch_state)
                if state == "acoustic_only":
                    assert not interval["empty"] and interval["upper"] == 1
                if state == "ssl_only":
                    assert not interval["empty"] and interval["lower"] == 0
                row = {"seed": seed, "fold": r["fold"], "singer": r["held_singer"],
                       "clip_id": cid, "target": y, "label": LABELS[y], "family": family,
                       "weight": weight, "acoustic_temperature": r["selection"]["acoustic"]["temperature"],
                       "ssl_temperature": r["selection"]["ssl"]["temperature"],
                       "acoustic_pred": pa, "ssl_pred": ps, "fusion_pred": pf,
                       "branch_state": state, "fusion_correct": int(pf == y), **interval,
                       "lower_minus_actual": interval["lower"] - weight,
                       "actual_minus_upper": weight - interval["upper"],
                       "actual_true_min_margin": min(margins),
                       "actual_closest_rival": constraints[int(np.argmin(margins))]["rival"],
                       "lower_non_top1": int(state == "acoustic_only" and ps not in interval["lower_rivals"]),
                       "upper_non_top1": int(state == "ssl_only" and pa not in interval["upper_rivals"]),
                       "additional_harms_min": 0, "additional_harms_near": 0,
                       "pair_total": 0, "pair_conflicts": 0, "pair_near": 0}
                for c, margin in zip(constraints, margins):
                    rival_rows.append({"seed": seed, "fold": r["fold"], "singer": r["held_singer"],
                                       "clip_id": cid, "target": y, "family": family, "weight": weight,
                                       **c, "margin_at_actual": margin,
                                       "lower_binding": int(c["rival"] in interval["lower_rivals"]),
                                       "upper_binding": int(c["rival"] in interval["upper_rivals"])})
                fold_rows.append(row)
            aonly = [x for x in fold_rows if x["branch_state"] == "acoustic_only"]
            sonly = [x for x in fold_rows if x["branch_state"] == "ssl_only"]
            for ar in aonly:
                for sr in sonly:
                    gap = ar["lower"] - sr["upper"]
                    conflict, near = gap > EPS, abs(gap) <= EPS
                    additional = conflict and not ar["fusion_correct"] and bool(sr["fusion_correct"])
                    ar["pair_total"] += 1
                    ar["pair_conflicts"] += int(conflict)
                    ar["pair_near"] += int(near)
                    ar["additional_harms_min"] += int(additional)
                    ar["additional_harms_near"] += int(near and not ar["fusion_correct"] and bool(sr["fusion_correct"]))
                    pair_rows.append({"seed": seed, "fold": r["fold"], "singer": r["held_singer"],
                                      "family": family, "weight": weight, "acoustic_only_clip": ar["clip_id"],
                                      "ssl_only_clip": sr["clip_id"], "required_lower": ar["lower"],
                                      "retain_upper": sr["upper"], "gap": gap, "conflict": int(conflict),
                                      "near_boundary": int(near), "missed_opportunity": int(not ar["fusion_correct"]),
                                      "ssl_case_retained": sr["fusion_correct"], "additional_harm": int(additional)})
            for row in fold_rows:
                row["lower_rivals"] = ";".join(map(str, row["lower_rivals"]))
                row["upper_rivals"] = ";".join(map(str, row["upper_rivals"]))
            records.extend(fold_rows)
    df = pd.DataFrame(records)
    assert len(df) == 3618 and len(rival_rows) == 18090 and max_replay_error <= 1e-12
    assert not df.duplicated(["seed", "clip_id"]).any()
    fold = grouped(df, ["seed", "fold", "singer", "family", "weight"])
    singer = []
    for name, group in fold.groupby("singer", sort=True):
        assert len(group) == 3
        missed, pairs = int(group.missed.sum()), int(group.pair_total.sum())
        blocked, conflicts = int(group.blocked_missed.sum()), int(group.conflict_pairs.sum())
        singer.append({"singer": name, "clips_per_schedule": int(group.n.iloc[0]),
                       "missed_occurrences": missed, "blocked_missed_occurrences": blocked,
                       "blocked_missed_rate": float(group.blocked_missed_rate.mean()),
                       "blocked_missed_conditional": blocked / missed if missed else None,
                       "pairs": pairs, "conflict_pairs": conflicts,
                       "conflict_pair_fraction": conflicts / pairs if pairs else None,
                       "schedules_with_blocked_missed": int(group.blocked_missed.gt(0).sum())})
    singer = pd.DataFrame(singer)
    ci = []
    for key in ("blocked_missed_rate", "blocked_missed_conditional", "conflict_pair_fraction"):
        values = singer[key].dropna().to_numpy()
        rng = np.random.default_rng(2026111501)
        indices = rng.integers(0, len(values), (10000, len(values)))
        low, high = np.quantile(values[indices].mean(1), [.025, .975])
        ci.append({"quantity": key, "eligible_singers": len(values), "mean": float(values.mean()),
                   "pointwise_ci_low": float(low), "pointwise_ci_high": float(high),
                   "bootstrap_draws": 10000, "bootstrap_seed": 2026111501})
    stability = []
    for cid, group in df.groupby("clip_id", sort=True):
        assert len(group) == 3
        missed = group.branch_state.eq("acoustic_only") & group.fusion_correct.eq(0)
        stability.append({"clip_id": cid, "singer": group.singer.iloc[0], "label": group.label.iloc[0],
                          "opportunity_schedules": int(group.branch_state.eq("acoustic_only").sum()),
                          "missed_schedules": int(missed.sum()),
                          "blocked_missed_schedules": int((missed & group.additional_harms_min.gt(0)).sum()),
                          "harmed_schedules": int((group.branch_state.eq("ssl_only") & group.fusion_correct.eq(0)).sum()),
                          "families": ";".join(group.family), "lower_min": float(group.lower.min()),
                          "lower_max": float(group.lower.max()), "upper_min": float(group.upper.min()),
                          "upper_max": float(group.upper.max())})
    output = HERE / "results_v1"
    output.mkdir(exist_ok=False)
    for name, data in (("clip_conditions", df), ("rival_constraints", rival_rows), ("conflict_pairs", pair_rows),
                       ("fold_summary", fold), ("singer_summary", singer), ("seed_summary", grouped(df, ["seed"])),
                       ("class_summary", grouped(df, ["seed", "label"])), ("cross_schedule", stability),
                       ("uncertainty", ci)):
        frame_save(output / (name + ".csv"), data)
    receipt = {"created_at_utc": datetime.now(timezone.utc).isoformat(), "prior_audit": prior_audit,
               "rows": len(df), "rival_constraints": len(rival_rows), "pairs": len(pair_rows),
               "max_fusion_probability_error": max_replay_error, "direct_interval_probes": probes,
               "near_actual_rival_margins": near_actual, "pair_near_boundaries": int(df.pair_near.sum()),
               "protected_files_verified_before": protected, "protected_files_verified_after": check_inputs(),
               "trained_or_optimized": False, "new_p_values": False,
               "plan_sha256": sha(HERE / "PLAN.md"), "source_sha256": sha(Path(__file__)),
               "outputs": {p.name: sha(p) for p in sorted(output.glob("*.csv"))}}
    save_json(output / "analysis_receipt.json", receipt)
    print(json.dumps({"receipt": receipt, "seeds": grouped(df, ["seed"]).to_dict("records"), "ci": ci}, allow_nan=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("freeze", "run", "check"))
    command = parser.parse_args().command
    if command == "freeze":
        freeze()
    elif command == "run":
        analyze()
    else:
        print(json.dumps({"protected_files_verified": check_inputs()}))
