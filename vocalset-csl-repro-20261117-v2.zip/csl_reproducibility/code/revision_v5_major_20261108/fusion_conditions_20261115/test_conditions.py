import tempfile
import unittest

import numpy as np

from analyze_conditions import contains, old, save_json, truth_interval


class IntervalTests(unittest.TestCase):
    def test_arithmetic_threshold(self):
        z, _ = truth_interval([.8, .2], [.3, .7], 0, "arithmetic")
        self.assertAlmostEqual(z["lower"], .4)
        self.assertEqual(z["upper"], 1)

    def test_geometric_threshold(self):
        z, _ = truth_interval([.8, .2], [.3, .7], 0, "geometric")
        wanted = np.log(.7 / .3) / (np.log(4) + np.log(.7 / .3))
        self.assertAlmostEqual(z["lower"], wanted)

    def test_other_competitor_binds(self):
        z, _ = truth_interval([.50, .01, .49], [.1, .5, .4], 0, "arithmetic")
        self.assertEqual(z["lower_rivals"], [2])
        self.assertAlmostEqual(z["lower"], .3 / .31)

    def test_interior_when_both_top1_wrong(self):
        z, _ = truth_interval([.40, .55, .05], [.40, .05, .55], 0, "arithmetic")
        self.assertAlmostEqual(z["lower"], .3)
        self.assertAlmostEqual(z["upper"], .7)
        self.assertTrue(contains(z, .5))

    def test_empty_interval(self):
        z, _ = truth_interval([.1, .8, .1], [.1, .1, .8], 0, "arithmetic")
        self.assertTrue(z["empty"])

    def test_constant_tie_first_index(self):
        z0, _ = truth_interval([.5, .5], [.5, .5], 0, "arithmetic")
        z1, _ = truth_interval([.5, .5], [.5, .5], 1, "arithmetic")
        self.assertTrue(contains(z0, .5))
        self.assertTrue(z1["empty"])

    def test_strict_endpoint(self):
        z, _ = truth_interval([.2, .8], [.8, .2], 1, "arithmetic")
        self.assertFalse(z["lower_closed"])
        self.assertFalse(contains(z, .5))
        self.assertTrue(contains(z, .501))

    def test_closed_endpoint(self):
        z, _ = truth_interval([.8, .2], [.2, .8], 0, "arithmetic")
        self.assertTrue(z["lower_closed"])
        self.assertTrue(contains(z, .5))

    def test_symmetric_harm_boundary(self):
        z, _ = truth_interval([.3, .7], [.8, .2], 0, "arithmetic")
        self.assertAlmostEqual(z["upper"], .6)
        self.assertFalse(contains(z, .7))

    def test_zero_probability_floor(self):
        z, constraints = truth_interval([1, 0, 0], [0, 1, 0], 0, "geometric")
        self.assertTrue(np.isfinite(z["lower"]))
        self.assertTrue(all(np.isfinite(c["a_margin"]) for c in constraints))

    def test_random_grid_matches_direct_fusion(self):
        rng = np.random.default_rng(15015)
        for family in ("arithmetic", "geometric"):
            for _ in range(80):
                a, s = rng.dirichlet(np.ones(6), 2)
                for y in range(6):
                    z, _ = truth_interval(a, s, y, family)
                    for w in (0, .1, .25, .5, .75, .9, 1):
                        p = old.replay_fusion([a], [s], w, family)[0]
                        self.assertEqual(contains(z, w), int(p.argmax()) == y)

    def test_existing_output_cannot_be_overwritten(self):
        with tempfile.NamedTemporaryFile() as f:
            with self.assertRaises(FileExistsError):
                save_json(f.name, {"should_not_write": True})


if __name__ == "__main__":
    unittest.main(verbosity=2)
