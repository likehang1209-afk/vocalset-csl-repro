"""Synthetic coverage of counts, alignment and singer-level aggregation."""
import unittest

import numpy as np
import pandas as pd

import analyze_saved as a


class DiagnosticsTests(unittest.TestCase):
    def test_all_eight_patterns(self):
        cases = [(ac, ss, fu) for ac in (0, 1) for ss in (0, 1) for fu in (0, 1)]
        y = np.zeros(8, dtype=int)
        pa, ps, pf = [np.array([0 if row[i] else 1 for row in cases]) for i in range(3)]
        row = a.pattern_counts(y, pa, ps, pf)
        self.assertEqual((row["rescued"], row["harmed"], row["net_correct"]), (2, 2, 0))
        for state in a.STATES:
            self.assertEqual(row[state], 2)
            self.assertEqual(row[state + "_fusion_correct"], 1)
            self.assertEqual(row[state + "_fusion_wrong"], 1)
        self.assertEqual(row["capture_conditional"], .5)

    def test_third_label_rescue(self):
        acoustic = np.array([[.40, .01, .39, .10, .05, .05]])
        ssl = np.array([[.01, .40, .39, .10, .05, .05]])
        for family in ("arithmetic", "geometric"):
            fused = a.replay_fusion(acoustic, ssl, .5, family)
            row = a.pattern_counts([2], acoustic.argmax(1), ssl.argmax(1), fused.argmax(1))
            self.assertEqual(row["both_wrong_rescued"], 1)
            self.assertEqual(row["captured"], 0)
            self.assertEqual(row["fusion_third_label_correct"], 1)

    def test_noop_and_no_opportunity(self):
        row = a.pattern_counts([0, 1], [1, 1], [0, 1], [0, 1])
        self.assertEqual((row["rescued"], row["harmed"], row["net_correct"]), (0, 0, 0))
        self.assertIsNone(row["capture_conditional"])
        s = np.array([[.6, .1, .1, .1, .05, .05]])
        ac = np.array([[.1, .6, .1, .1, .05, .05]])
        for family in ("arithmetic", "geometric"):
            np.testing.assert_allclose(a.replay_fusion(ac, s, 0, family), s, atol=1e-15)

    def test_alignment(self):
        frame = pd.DataFrame({"clip_id": ["c", "a", "b"], "v": [3, 1, 2]})
        self.assertEqual(a.aligned_ids(frame, ["a", "b", "c"]).v.tolist(), [1, 2, 3])
        with self.assertRaises(ValueError):
            a.aligned_ids(pd.DataFrame({"clip_id": ["a", "a", "b"]}), ["a", "b", "c"])

    def test_equal_singer_not_pooled_weighting(self):
        rows = []
        for singer in range(20):
            for seed in a.SEEDS:
                n = 10 if singer < 10 else 100
                captured = 5 if singer < 10 else 0
                row = {"seed": seed, "singer": str(singer), "n": n,
                       "acoustic_only": 5 if singer < 10 else 0, "captured": captured,
                       "capture_conditional": 1 if singer < 10 else None,
                       "net_correct_rate": captured / n}
                rows.append(row)
        result = a.average_singers(pd.DataFrame(rows))
        self.assertAlmostEqual(result.net_correct_rate_mean.mean(), .25)
        self.assertNotAlmostEqual(result.net_correct_rate_mean.mean(), 50 / 1100)
        self.assertEqual(result.capture_conditional.count(), 10)

    def test_persistent_clip_identity(self):
        rows = []
        for seed in a.SEEDS:
            rows.append({"seed": seed, "clip_id": "id1", "singer": "s", "label": "belt", "target": 0,
                         "opportunity": 1, "captured": 1, "rescued": 1, "harmed": 0, "both_wrong_rescued": 0,
                         "acoustic_pred": 0, "ssl_pred": 1, "fusion_pred": 0,
                         "acoustic_correct": 1, "ssl_correct": 0, "fusion_correct": 1,
                         "branch_state": "acoustic_only"})
        detail, summary = a.cross_schedule(pd.DataFrame(rows))
        self.assertEqual(len(detail), 1)
        self.assertEqual(detail.rescued_schedules.iloc[0], 3)
        self.assertEqual(sum(r["unique_clips"] for r in summary if r["event"] == "rescued"), 1)


if __name__ == "__main__":
    unittest.main()
