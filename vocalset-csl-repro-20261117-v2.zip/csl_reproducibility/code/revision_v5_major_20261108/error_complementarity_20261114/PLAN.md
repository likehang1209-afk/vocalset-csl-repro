# Saved-prediction error-complementarity analysis

## Status and scope

This exploratory plan was fixed on 2026-11-14 after the original outcomes and the single-schedule 28-rescue/23-harm result were known, but before computing the new joint-error tables. It is not preregistration or independent confirmation. No model fitting, candidate search, calibration fitting, weight optimization, audio processing, downloads, cloud access or GPU use is authorized. Existing evidence and manuscripts must remain unchanged.

Inputs are the 60 completed, audited original-pipeline outer folds in `anchor_multiseed_20261111/results_v3`, their audit receipts, the canonical plan, and the existing `analysis_v6` summaries. The seeds are 20260824, 30260824 and 40260824, with 1,206 canonical clips, 20 singers and six labels in each schedule. Use all clips, singers, labels and schedules. Do not add the separate neural recipes or the unrepeated early-fusion controls to this diagnostic.

## Input validation and preservation

1. Save a new SHA256 manifest before analysis. Include every current results_v3 file (including candidates and failure markers), execution_v2 through execution_v6 records, existing analysis_v6 outputs, the latest manuscript package (excluding page-render copies), earlier protected evidence, and files actually used by this analysis.
2. Validate the existing completion/full-audit bindings and each outer payload hash. Require exact canonical IDs, targets, label order, fold/singer identity and one test prediction per clip per schedule. Check all five stored probability branches and independently replay their saved metrics.
3. Confirm raw and temperature-calibrated acoustic/SSL argmax labels agree. Use stored calibrated branches for the complementarity comparison because they are the inputs to the stored calibrated fusion. Report any argmax ties. Replay the saved fusion using only its archived family and weight; do not select a new weight or family.
4. Match existing per-seed and per-singer macro-F1/accuracy summaries. Recheck protected hashes after analysis. Fail rather than silently omit invalid inputs.

## Fixed definitions

Let A, S and F denote whether the acoustic, selected-SSL and calibrated-late-fusion top-1 labels equal the archived true label. Predictions are argmax in the stored label order; no probability averaging across schedules.

- Four branch states: both correct (A=1,S=1), acoustic-only correct (A=1,S=0), SSL-only correct (A=0,S=1), both wrong (A=0,S=0). For each state report fusion correct and wrong counts, including zeros.
- Acoustic-only correctness is an observed branch opportunity, not proof of conditional information, a deployable selector, an achievable performance gain or an upper bound for soft fusion/macro-F1.
- Rescue: S=0,F=1. Harm: S=1,F=0. Distinguish rescue in the acoustic-only state from rescue when both branches' top-1 labels are wrong. Distinguish harms in the SSL-only state from harms when both branches are correct. Soft pooling can choose a third label, so neither branch's top-1 correctness is a complete description of the probability vectors.
- Opportunity captured: A=1,S=0,F=1. Opportunity missed: A=1,S=0,F=0. The conditional capture proportion is captured/opportunities; zero denominator is undefined (NA), not zero.
- Also report top-1 branch disagreement and identical-wrong-label versus different-wrong-label counts within the both-wrong state. No new conditional model or threshold is fitted.
- Exact count identities: all eight correctness patterns sum to N; rescue minus harm equals fusion-correct minus SSL-correct; opportunity captured plus both-wrong rescue equals all rescue. These describe accuracy, not additive macro-F1 changes.

## Aggregation and uncertainty

Export all 3,618 clip-schedule rows, 60 singer-schedule rows, 360 singer-class-schedule rows, all 18 class-schedule rows and all three pooled schedules. The repeated 3,618 rows are not independent recordings or inference units.

Primary descriptive summaries weight singers equally: within each singer, average the three schedule-specific rates before averaging the 20 singer values. For conditional capture, first sum captured and opportunity counts across that singer's three schedules, divide, and then average over singers with positive opportunity counts; always report the eligible-singer denominator. Pooled conditional rates and equally weighted singer rates must not be conflated.

Use 10,000 singer-bootstrap draws with NumPy default_rng seed 2026111401 and percentile 2.5/97.5 bounds for exactly four fixed rate summaries: acoustic-only opportunity prevalence, rescue prevalence, harm prevalence, and net accuracy difference. The units are the 20 schedule-averaged singers; the intervals are pointwise, exploratory, conditional on these three schedules and overlapping LOSO training sets. Do not use them to replace the original macro-F1 tests or claim multiplicity-controlled significance.

No new p values or subgroup hypothesis tests are planned. The original 13/37-test families and all earlier families are untouched. Class and singer detail is descriptive and complete, not selected by direction or apparent significance.

For each of the 1,206 unique clips, report opportunity, capture, rescue and harm occurrence counts across the three schedules (0,1,2,3), retaining all clips. Report never/sometimes/always counts and cross-schedule label agreement; do not interpret these three schedules as a population of independent datasets.

Archive the 60 previously selected fusion families, weights and temperatures for interpretation, but do not test associations, select thresholds, or claim the selected weight causes any error pattern.

## Verification and reporting

Unit tests must cover all eight correctness states, third-label soft-fusion rescue, no-op fusion, unequal singer sizes, zero conditional denominators and repeated-clip alignment. Verify output tables with a second calculation using independently assembled confusion/crosstab counts, not only the production summary function. Check the first-schedule 28/23 historical result without forcing it.

Report all positive and negative findings. Decide separately what deserves a short main-text paragraph, complete supplementary tables, and a bounded reviewer response. Preserve the current manuscript package; proposed additions are drafts until their substantive value is assessed. Do not submit or publish anything.
