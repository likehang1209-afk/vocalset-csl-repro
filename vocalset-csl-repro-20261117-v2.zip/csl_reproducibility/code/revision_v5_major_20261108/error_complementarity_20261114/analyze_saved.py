"""Analyze immutable saved predictions; no fitting modules or model execution."""
from __future__ import annotations

import os

for _name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
REV = HERE.parent
ANCHOR = REV / "anchor_multiseed_20261111"
RESULTS = ANCHOR / "results_v3"
PREVIOUS = ANCHOR / "analysis_v6"
SEEDS = (20260824, 30260824, 40260824)
LABELS = ("belt", "breathy", "lip_trill", "straight", "vibrato", "vocal_fry")
BRANCHES = ("acoustic", "acoustic_calibrated", "ssl", "ssl_calibrated", "late_fusion_calibrated")
STATES = ("both_correct", "acoustic_only", "ssl_only", "both_wrong")
BOOTSTRAP_SEED = 2026111401
BOOTSTRAP_DRAWS = 10000
sys.path.insert(0, str(ANCHOR))
import audit as archived_audit


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_json(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def save_csv(path, rows):
    frame = rows if isinstance(rows, pd.DataFrame) else pd.DataFrame(rows)
    frame.to_csv(path, index=False, mode="x", float_format="%.17g", na_rep="NA")


def prepare():
    paths = {REV / "artifacts/plan.json", ANCHOR / "audit.py"}
    for directory in (RESULTS, PREVIOUS, *(ANCHOR / f"execution_v{v}" for v in range(2, 7))):
        paths.update(p for p in directory.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    latest = REV / "writing/round6_reviewfix_20261114/delivery"
    paths.update(p for p in latest.rglob("*") if p.is_file() and "page_checks" not in p.parts)
    prior_protected = REV / "writing/round5_v6_20261114/protected_input_hashes.json"
    for name, expected in read(prior_protected).items():
        path = Path(name)
        if sha(path) != expected:
            raise ValueError("Existing protected evidence mismatch: " + name)
        paths.add(path)
    paths.add(prior_protected)
    lock = read(RESULTS / "run_lock.json")
    for relative, expected in lock["sources"].items():
        path = REV.parent / relative
        if sha(path) != expected:
            raise ValueError("Archived scientific source changed: " + relative)
        paths.add(path)
    files = {str(p.resolve()): {"bytes": p.stat().st_size, "sha256": sha(p)} for p in sorted(paths)}
    receipt = {"created_at_utc": datetime.now(timezone.utc).isoformat(),
               "plan_sha256": sha(HERE / "PLAN.md"), "script_sha256": sha(Path(__file__)),
               "files": files, "total_bytes": sum(r["bytes"] for r in files.values()),
               "prior_protected_hashes_verified": True}
    save_json(HERE / "input_manifest.json", receipt)
    print(json.dumps({"protected_files": len(files), "bytes": receipt["total_bytes"]}))


def check_manifest():
    manifest = read(HERE / "input_manifest.json")
    if manifest["plan_sha256"] != sha(HERE / "PLAN.md") or manifest["script_sha256"] != sha(Path(__file__)):
        raise ValueError("Analysis plan/source changed after input freeze")
    for name, expected in manifest["files"].items():
        path = Path(name)
        if path.stat().st_size != expected["bytes"] or sha(path) != expected["sha256"]:
            raise ValueError("Protected file changed: " + name)
    return len(manifest["files"])


def normalized(raw):
    p = np.clip(np.asarray(raw, dtype=float), 1e-12, None)
    return p / p.sum(1, keepdims=True)


def replay_fusion(a, s, weight, family):
    if not 0 <= weight <= 1 or family not in ("arithmetic", "geometric"):
        raise ValueError("Invalid archived fusion selection")
    a, s = normalized(a), normalized(s)
    if family == "arithmetic":
        return normalized(weight * a + (1 - weight) * s)
    logits = weight * np.log(np.clip(a, 1e-12, 1)) + (1 - weight) * np.log(np.clip(s, 1e-12, 1))
    return normalized(np.exp(logits - logits.max(1, keepdims=True)))


def macro_f1(y, pred):
    confusion = np.zeros((6, 6), dtype=np.int64)
    np.add.at(confusion, (np.asarray(y, dtype=int), np.asarray(pred, dtype=int)), 1)
    denominator = confusion.sum(0) + confusion.sum(1)
    f1 = np.divide(2 * confusion.diagonal(), denominator, out=np.zeros(6), where=denominator > 0)
    return float(f1.mean())


def pattern_counts(y, pa, ps, pf, include_f1=True):
    y, pa, ps, pf = [np.asarray(x, dtype=int) for x in (y, pa, ps, pf)]
    if not len(y) or any(x.shape != y.shape for x in (pa, ps, pf)):
        raise ValueError("Nonempty aligned predictions required")
    a, s, f = pa == y, ps == y, pf == y
    masks = {"both_correct": a & s, "acoustic_only": a & ~s, "ssl_only": ~a & s, "both_wrong": ~a & ~s}
    result = {"n": len(y), "acoustic_correct": int(a.sum()), "ssl_correct": int(s.sum()), "fusion_correct": int(f.sum())}
    for name, mask in masks.items():
        result[name] = int(mask.sum())
        result[name + "_fusion_correct"] = int((mask & f).sum())
        result[name + "_fusion_wrong"] = int((mask & ~f).sum())
    result.update({"rescued": int((~s & f).sum()), "harmed": int((s & ~f).sum()),
                   "net_correct": int(f.sum() - s.sum()),
                   "captured": int((a & ~s & f).sum()), "missed": int((a & ~s & ~f).sum()),
                   "both_wrong_rescued": int((~a & ~s & f).sum()),
                   "both_correct_harmed": int((a & s & ~f).sum()),
                   "branch_disagreements": int((pa != ps).sum()),
                   "both_wrong_same_top1": int((~a & ~s & (pa == ps)).sum()),
                   "both_wrong_different_top1": int((~a & ~s & (pa != ps)).sum()),
                   "fusion_third_label": int(((pf != pa) & (pf != ps)).sum()),
                   "fusion_third_label_correct": int(((pf != pa) & (pf != ps) & f).sum())})
    for name in ("acoustic_only", "ssl_only", "both_wrong", "rescued", "harmed", "net_correct", "captured", "missed"):
        result[name + "_rate"] = result[name] / len(y)
    result["capture_conditional"] = result["captured"] / result["acoustic_only"] if result["acoustic_only"] else None
    if include_f1:
        for name, pred in (("acoustic", pa), ("ssl", ps), ("fusion", pf)):
            result[name + "_macro_f1"] = macro_f1(y, pred)
        result["delta_macro_f1"] = result["fusion_macro_f1"] - result["ssl_macro_f1"]
    assert sum(result[k] for k in STATES) == len(y)
    assert sum(result[k + "_fusion_correct"] + result[k + "_fusion_wrong"] for k in STATES) == len(y)
    assert result["rescued"] - result["harmed"] == result["net_correct"]
    assert result["captured"] + result["both_wrong_rescued"] == result["rescued"]
    return result


def aligned_ids(frame, canonical):
    if frame["clip_id"].duplicated().any() or set(frame["clip_id"]) != set(canonical):
        raise ValueError("Duplicate or missing clip IDs")
    return frame.set_index("clip_id").loc[canonical].reset_index()


def load_predictions():
    plan_path = REV / "artifacts/plan.json"
    plan = read(plan_path)
    binding = dict(plan)
    plan_fingerprint = binding.pop("fingerprint")
    compact_digest = hashlib.sha256(json.dumps(binding, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    if compact_digest != plan_fingerprint:
        raise ValueError("Canonical plan fingerprint changed")
    ids = [c["clip_id"] for c in plan["clips"]]
    clips = {c["clip_id"]: c for c in plan["clips"]}
    singers = sorted({c["singer_id"] for c in plan["clips"]})
    assert len(ids) == len(clips) == 1206 and len(singers) == 20 and tuple(plan["labels"]) == LABELS
    assert len(plan["folds"]) == 20
    completed = read(RESULTS / "completion.json")
    v6 = read(ANCHOR / "execution_v6/full_audit_v6.json")
    assert v6["complete"] and v6["outer_folds_verified"] == 60 and v6["probability_outputs_verified"] == 300
    assert v6["candidate_records_verified"] == 6180
    assert v6["full_v3_audit_sha256"] == sha(RESULTS / "full_lineage_audit.json")
    assert completed["inventory_sha256"] == sha(ANCHOR / "execution_v6/inventory.json")
    assert completed["complete"] and completed["completed_jobs"] == completed["required_jobs"] == 60
    assert completed["continued_by"] == "execution_v6"
    audited = read(RESULTS / "full_lineage_audit.json")
    assert audited["all_60_verified"] and audited["complete_candidate_records_verified"] == 6180
    assert completed["results"] == audited["results"]
    expected = {(r["seed"], r["fold"]): r["sha256"] for r in completed["results"]}
    assert len(expected) == 60
    lock = read(RESULTS / "run_lock.json")
    lock_binding = dict(lock)
    fingerprint = lock_binding.pop("fingerprint")
    assert fingerprint == archived_audit.digest(lock_binding) == completed["fingerprint"]
    assert lock_binding["seeds"] == list(SEEDS)
    assert lock_binding["common_plan_fingerprint"] == plan_fingerprint
    assert len(list(RESULTS.glob("seed_*/fold_*.json"))) == 60
    assert len(list((RESULTS / "candidates").rglob("*.json"))) == 6180
    rows, choices, ties = [], [], []
    max_fusion_error = 0.0
    for seed in SEEDS:
        for fold in plan["folds"]:
            path = RESULTS / f"seed_{seed}" / f"fold_{fold['fold']:02d}.json"
            assert sha(path) == expected[seed, fold["fold"]]
            r = archived_audit.checked(path)
            assert (r["seed"], r["fold"], r["held_singer"], r["fingerprint"]) == (seed, fold["fold"], fold["held_singer"], fingerprint)
            assert r["labels"] == list(LABELS) and r["clip_ids"] == fold["test"]
            assert r["y_true"] == [clips[x]["target"] for x in r["clip_ids"]]
            assert set(r["probabilities"]) == set(BRANCHES)
            assert not set(fold["test"]) & set(fold["train"])
            assert all(clips[x]["singer_id"] == r["held_singer"] for x in r["clip_ids"])
            predictions = {}
            for method in BRANCHES:
                p = np.asarray(r["probabilities"][method])
                archived_audit.compare(archived_audit.metrics(r["y_true"], p), r["metrics"][method])
                predictions[method] = p.argmax(1)
                if not np.array_equal(predictions[method], normalized(p).argmax(1)):
                    raise ValueError("Normalization changes the stored top-1 labels")
                tie_count = int(((p == p.max(1, keepdims=True)).sum(1) > 1).sum())
                ties.append({"seed": seed, "fold": fold["fold"], "method": method, "argmax_ties": tie_count})
            assert np.array_equal(predictions["acoustic"], predictions["acoustic_calibrated"])
            assert np.array_equal(predictions["ssl"], predictions["ssl_calibrated"])
            fusion = r["fusion"]
            reconstructed = replay_fusion(r["probabilities"]["acoustic_calibrated"], r["probabilities"]["ssl_calibrated"], fusion["acoustic_weight"], fusion["family"])
            difference = float(np.max(np.abs(reconstructed - np.asarray(r["probabilities"]["late_fusion_calibrated"]))))
            max_fusion_error = max(max_fusion_error, difference)
            if difference > 1e-12:
                raise ValueError("Archived fusion does not reproduce")
            assert np.array_equal(reconstructed.argmax(1), predictions["late_fusion_calibrated"])
            choices.append({"seed": seed, "fold": fold["fold"], "singer": r["held_singer"],
                            "fusion_family": fusion["family"], "acoustic_weight": fusion["acoustic_weight"],
                            "acoustic_temperature": r["selection"]["acoustic"]["temperature"],
                            "ssl_temperature": r["selection"]["ssl"]["temperature"],
                            "ssl_representation": r["selection"]["ssl"]["representation"],
                            "ssl_classifier": r["selection"]["ssl"]["model"],
                            "acoustic_classifier": r["selection"]["acoustic"]["model"]})
            for j, clip_id in enumerate(r["clip_ids"]):
                item = clips[clip_id]
                truth = item["target"]
                pa, ps, pf = (int(predictions[m][j]) for m in ("acoustic_calibrated", "ssl_calibrated", "late_fusion_calibrated"))
                a, s, f = pa == truth, ps == truth, pf == truth
                state = "both_correct" if a and s else "acoustic_only" if a else "ssl_only" if s else "both_wrong"
                rows.append({"seed": seed, "fold": fold["fold"], "clip_id": clip_id, "singer": item["singer_id"],
                             "label": item["label"], "target": truth, "acoustic_pred": pa, "ssl_pred": ps,
                             "fusion_pred": pf, "acoustic_correct": int(a), "ssl_correct": int(s), "fusion_correct": int(f),
                             "branch_state": state, "opportunity": int(a and not s), "captured": int(a and not s and f),
                             "rescued": int(not s and f), "harmed": int(s and not f),
                             "both_wrong_rescued": int(not a and not s and f)})
    frame = pd.DataFrame(rows)
    frame = pd.concat([aligned_ids(frame[frame.seed.eq(seed)], ids) for seed in SEEDS], ignore_index=True)
    assert len(frame) == 3618 and not frame.duplicated(["seed", "clip_id"]).any()
    return frame, choices, ties, {"outer_folds": 60, "probability_branches_replayed": 300,
                                  "unique_clips": 1206, "singers": singers, "labels": list(LABELS),
                                  "max_fusion_replay_error": max_fusion_error,
                                  "argmax_ties": sum(r["argmax_ties"] for r in ties),
                                  "calibration_argmax_unchanged": True}


def grouped_counts(frame, keys, include_f1=True):
    output = []
    for identity, group in frame.groupby(keys, sort=True):
        if not isinstance(identity, tuple):
            identity = (identity,)
        record = dict(zip(keys, identity))
        record.update(pattern_counts(*(group[k].to_numpy() for k in ("target", "acoustic_pred", "ssl_pred", "fusion_pred")), include_f1=include_f1))
        output.append(record)
    return pd.DataFrame(output)


def average_singers(singer_seed):
    if len(singer_seed) != 60 or singer_seed.groupby("singer").size().ne(3).any():
        raise ValueError("Twenty singers and all three schedules required")
    rows = []
    for singer, group in singer_seed.groupby("singer", sort=True):
        assert group.n.nunique() == 1
        record = {"singer": singer, "clips_per_schedule": int(group.n.iloc[0])}
        for column in group.columns:
            if column not in ("seed", "singer", "capture_conditional"):
                record[column + "_mean"] = float(group[column].mean())
        opportunities = int(group.acoustic_only.sum())
        record["opportunity_occurrences"] = opportunities
        record["captured_occurrences"] = int(group.captured.sum())
        record["capture_conditional"] = float(group.captured.sum() / opportunities) if opportunities else None
        rows.append(record)
    return pd.DataFrame(rows)


def uncertainty(singers):
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    indices = rng.integers(0, len(singers), (BOOTSTRAP_DRAWS, len(singers)))
    rows = []
    for key in ("acoustic_only_rate_mean", "rescued_rate_mean", "harmed_rate_mean", "net_correct_rate_mean"):
        values = singers[key].to_numpy()
        low, high = np.quantile(values[indices].mean(1), [0.025, 0.975])
        rows.append({"quantity": key, "singers": len(values), "mean": float(values.mean()),
                     "pointwise_ci_low": float(low), "pointwise_ci_high": float(high),
                     "min_singer": float(values.min()), "max_singer": float(values.max()),
                     "bootstrap_draws": BOOTSTRAP_DRAWS, "bootstrap_seed": BOOTSTRAP_SEED})
    return rows


def cross_schedule(frame):
    rows = []
    for clip_id, group in frame.groupby("clip_id", sort=True):
        group = group.set_index("seed").loc[list(SEEDS)]
        assert len(group) == 3 and group.singer.nunique() == group.label.nunique() == group.target.nunique() == 1
        row = {"clip_id": clip_id, "singer": group.singer.iloc[0], "label": group.label.iloc[0], "target": int(group.target.iloc[0])}
        for key in ("opportunity", "captured", "rescued", "harmed", "both_wrong_rescued"):
            row[key + "_schedules"] = int(group[key].sum())
        for method in ("acoustic", "ssl", "fusion"):
            row[method + "_distinct_top1"] = int(group[method + "_pred"].nunique())
            row[method + "_correct_schedules"] = int(group[method + "_correct"].sum())
        row["states_by_seed"] = ";".join(group.branch_state)
        rows.append(row)
    detail = pd.DataFrame(rows)
    summary = []
    for key in ("opportunity", "captured", "rescued", "harmed", "both_wrong_rescued"):
        for count in range(4):
            summary.append({"event": key, "schedules_with_event": count, "unique_clips": int(detail[key + "_schedules"].eq(count).sum())})
    return detail, summary


def replay_existing_summaries(per_seed, per_singer):
    old_seed = pd.read_csv(PREVIOUS / "per_seed.csv")
    old_singer = pd.read_csv(PREVIOUS / "per_singer.csv")
    errors = []
    for short, method in (("acoustic", "acoustic"), ("ssl", "ssl"), ("fusion", "late_fusion_calibrated")):
        for row in per_seed.to_dict("records"):
            reference = old_seed[old_seed.seed.eq(row["seed"]) & old_seed.method.eq(method)].iloc[0]
            errors.extend((abs(row[short + "_macro_f1"] - reference.pooled_f1), abs(row[short + "_correct"] / row["n"] - reference.accuracy)))
        for row in per_singer.to_dict("records"):
            reference = old_singer[old_singer.seed.eq(row["seed"]) & old_singer.method.eq(method) & old_singer.singer.eq(row["singer"])].iloc[0]
            errors.append(abs(row[short + "_macro_f1"] - reference.macro_f1))
    assert max(errors) < 1e-12
    return max(errors)


def run(destination):
    destination = destination.resolve()
    if not destination.is_relative_to(HERE) or destination == HERE or destination.exists():
        raise ValueError("A new analysis subdirectory is required")
    protected_count = check_manifest()
    frame, choices, ties, validation = load_predictions()
    per_seed = grouped_counts(frame, ["seed"])
    per_singer = grouped_counts(frame, ["seed", "singer"])
    per_class = grouped_counts(frame, ["seed", "label"], include_f1=False)
    per_singer_class = grouped_counts(frame, ["seed", "singer", "label"], include_f1=False)
    assert (len(per_seed), len(per_singer), len(per_class), len(per_singer_class)) == (3, 60, 18, 360)
    validation["max_existing_summary_error"] = replay_existing_summaries(per_seed, per_singer)
    singers = average_singers(per_singer)
    intervals = uncertainty(singers)
    stability, stability_summary = cross_schedule(frame)
    class_average = per_singer_class.groupby(["singer", "label"], sort=True)[[c for c in per_singer_class if c.endswith("_rate")]].mean().reset_index()
    class_summary = class_average.groupby("label", sort=True).mean(numeric_only=True).reset_index()
    joint = []
    for row in per_seed.to_dict("records"):
        for state in STATES:
            joint.append({"seed": row["seed"], "branch_state": state, "n": row[state],
                          "fusion_correct": row[state + "_fusion_correct"], "fusion_wrong": row[state + "_fusion_wrong"],
                          "fusion_accuracy_conditional": row[state + "_fusion_correct"] / row[state] if row[state] else None})
    protected_after = check_manifest()
    assert protected_count == protected_after
    destination.mkdir()
    for name, data in (("clip_schedule", frame), ("per_seed", per_seed), ("per_singer_seed", per_singer),
                       ("per_class_seed", per_class), ("per_singer_class_seed", per_singer_class),
                       ("singer_summary", singers), ("class_singer_schedule_average", class_average),
                       ("class_summary", class_summary), ("intervals_pointwise", intervals), ("joint_states", joint),
                       ("clip_stability", stability), ("stability_summary", stability_summary),
                       ("archived_fusion_choices", choices), ("argmax_ties", ties)):
        save_csv(destination / (name + ".csv"), data)
    conditional = singers.capture_conditional.dropna()
    record = {"status": "exploratory_saved_prediction_analysis_complete",
              "created_at_utc": datetime.now(timezone.utc).isoformat(), "validation": validation,
              "protected_files_unchanged": protected_count, "input_manifest_sha256": sha(HERE / "input_manifest.json"),
              "plan_sha256": sha(HERE / "PLAN.md"), "script_sha256": sha(Path(__file__)),
              "python": sys.version, "numpy": np.__version__, "pandas": pd.__version__,
              "per_seed": per_seed.to_dict("records"), "pointwise_intervals": intervals,
              "singer_conditional_capture_mean": float(conditional.mean()), "singer_conditional_capture_eligible": len(conditional),
              "singers_net_accuracy_positive_zero_negative": [int(singers.net_correct_rate_mean.gt(0).sum()), int(singers.net_correct_rate_mean.eq(0).sum()), int(singers.net_correct_rate_mean.lt(0).sum())],
              "new_p_values": False, "original_13_37_tests_untouched": True,
              "model_fit_or_parameter_selection_performed": False, "submission_or_publication": False,
              "limits": ["exploratory after prior outcomes", "20 singer units, not 3618 independent rows",
                         "conditional on three observed schedules and overlapping LOSO training sets",
                         "counts decompose accuracy, not macro-F1", "pointwise intervals without multiplicity-controlled claims",
                         "no oracle or improved alternative fusion evaluated", "no external or causal validation"]}
    save_json(destination / "analysis.json", record)
    print(per_seed[["seed", "n", *STATES, "captured", "missed", "rescued", "harmed", "net_correct", "both_wrong_rescued", "capture_conditional"]].to_string(index=False))
    print(pd.DataFrame(intervals).to_string(index=False))
    print(json.dumps({"singer_capture_mean": record["singer_conditional_capture_mean"], "eligible": len(conditional),
                      "singer_accuracy_signs": record["singers_net_accuracy_positive_zero_negative"], "validation": validation}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "run"))
    parser.add_argument("--output", type=Path, default=HERE / "results_v1")
    args = parser.parse_args()
    prepare() if args.mode == "prepare" else run(args.output)
