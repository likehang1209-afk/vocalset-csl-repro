"""The two paper-level downstream systems; backbone weights are never invented."""
from __future__ import annotations

import torch
from torch import nn


class LayerMix(nn.Module):
    def __init__(self, layers):
        super().__init__()
        self.logits = nn.Parameter(torch.zeros(layers))

    def forward(self, x):
        if x.shape[1] != len(self.logits):
            raise ValueError("Unexpected hidden layer count")
        return (x * self.logits.softmax(0)[None, :, None]).sum(1)


class ZhouHead(nn.Module):
    def __init__(self, dimension, classes, hidden=512, dropout=0.2, layer=None, layers=12):
        super().__init__()
        self.layer = layer
        self.mix = LayerMix(layers) if layer is None else None
        self.classifier = nn.Sequential(nn.Linear(dimension, hidden), nn.ReLU(),
                                        nn.Dropout(dropout), nn.Linear(hidden, classes))

    def forward(self, layer_means):
        x = self.mix(layer_means) if self.layer is None else layer_means[:, self.layer]
        return self.classifier(x)


class YamamotoSystem(nn.Module):
    def __init__(self, backbone, classes):
        super().__init__()
        self.backbone = backbone
        self.mix = LayerMix(backbone.config.num_hidden_layers + 1)
        self.classifier = nn.Linear(backbone.config.hidden_size, classes)
        self.stage = 1
        # Layer dropping would make the identity/count of learned layer weights ambiguous.
        self.backbone.config.layerdrop = 0.0
        if hasattr(self.backbone, "encoder") and hasattr(self.backbone.encoder, "config"):
            self.backbone.encoder.config.layerdrop = 0.0
        self.set_stage(1)

    def set_stage(self, stage):
        if stage not in (1, 2):
            raise ValueError("Stage must be 1 or 2")
        self.stage = stage
        self.backbone.requires_grad_(False)
        if stage == 2:
            self.backbone.encoder.requires_grad_(True)
        self.train(self.training)

    def train(self, mode=True):
        super().train(mode)
        self.backbone.eval()
        if mode and self.stage == 2:
            self.backbone.train()
            self.backbone.feature_extractor.eval()
            self.backbone.feature_projection.eval()
        return self

    def forward(self, values, attention_mask):
        args = {"input_values": values, "output_hidden_states": True, "return_dict": True}
        # The attention mask is also required for excluding right-padded hidden frames.
        args["attention_mask"] = attention_mask
        if self.stage == 1:
            with torch.no_grad():
                hidden = self.backbone(**args).hidden_states
        else:
            hidden = self.backbone(**args).hidden_states
        valid = self.backbone._get_feature_vector_attention_mask(hidden[0].shape[1], attention_mask)
        denominator = valid.sum(1).clamp_min(1).unsqueeze(1)
        means = torch.stack([(x * valid.unsqueeze(-1)).sum(1) / denominator for x in hidden], dim=1)
        return self.classifier(self.mix(means))


def class_weights(targets, classes, exponent=0.2):
    counts = torch.bincount(torch.as_tensor(targets, dtype=torch.long), minlength=classes).float()
    if torch.any(counts == 0):
        raise ValueError("Training partition lacks a class")
    return counts.pow(-exponent)
