# Frozen class-aware probability correction experiment

Date: 2026-11-16, Asia/Shanghai. Local CPU only. New user authorization permits
small decision-layer fits, not base-model retraining, uploads, or submission.
The user additionally suggested limiting intervention to suitable conditions.
This plan fixes one observable condition before any new fitting or outcome.
Historical outer outcomes and the earlier failed dual success criterion are
already known. This is an exploratory follow-up, not independent confirmation.

## Questions and complete population

1. Does adding acoustic probabilities improve singer-mean macro-F1 over an
   SSL-only probability correction layer in the same residual model family?
2. What does an agreement-preserving intervention policy gain and sacrifice?

No singer, technique, recording, schedule, unfavorable outcome, or old failure
marker is removed. All 1,206 recordings, six classes, 20 held-out singers and
three original schedules (20260824, 30260824, 40260824) remain. There are 60
outer folds and exactly 120 new small-model fits. The old six methods are
imported byte-for-byte at the probability-array level, never refitted.

## Inputs and leakage boundary

Reuse the audited, hash-frozen input bundles in risk_gated_fusion_20261116/locked.
For each outer fold, only its own outer-training raw OOF probabilities and
training labels enter fitting. Do not pool outer-test predictions across folds.
The existing splits enforce singer isolation in all four inner validation folds.
Base candidate selection already used these training labels: the selected OOF
bundles are valid training inputs, not a pristine validation set for tuning.
There is no validation-driven choice, threshold search, model selection or
alternative initialization. No calibration learned from the same OOF labels is
used as an input feature. Both correct and both wrong training cases remain.

All 120 fits finish and are sealed before any outer-input bundle is loaded.
All 60 files of nine-method outer probabilities are sealed before evaluation
labels or historical diagnostic labels are opened. Fitting and prediction
interfaces reject unexpected fields. Stored models include exact training hashes.

## Two fixed, SSL-anchored linear residual models

Let S and A be ordered raw six-class SSL and acoustic probability vectors.
The fixed log floor is 1e-12. The SSL reference offset is log(max(S, floor)).

SSL-only: X = S (six features).
Dual-branch: X = [S, A-S] (twelve features).

Each feature is standardized using only the current outer-training OOF rows,
unweighted population mean/SD; a constant column uses scale 1. The first six
standardization quantities must match between the two fits. No feature pruning.
An intercept column is appended. Predicted probabilities are

    Q = softmax(log(max(S, 1e-12)) + standardized(X) @ W + b).

At W=b=0 this is exactly clipped-and-renormalized SSL. Correction is linear in
the class-position-preserving features, followed by softmax; it is not a new
deep model. There are 42 stored SSL-only and 78 stored dual coefficients,
including intercepts. These are an input ablation in the same model family,
NOT equal-effective-capacity models. Added capacity remains a limitation.

Fit all outer-training OOF rows by singer-balanced mean cross-entropy plus
0.1/2 times the sum of squared coefficients AND intercepts. Each singer has
equal total weight; no class weights or added-error cost are used. The 0.1
penalty is fixed before fitting to shrink corrections toward the SSL anchor.
It does not guarantee improvement or non-degradation.

Use scipy.optimize.minimize(method='L-BFGS-B') with an analytic gradient, all-zero
initialization, maxiter=2000, maxfun=20000, ftol=1e-12, gtol=1e-8, maxls=30,
maxcor=10. No bounds or random starts. A warning, failed convergence, nonfinite
value, final gradient infinity norm above 1e-6, or objective above its initial
value by more than 1e-10 stops the run. No automatic replacement fit is allowed.

## Prespecified protection condition: a third output, not a third fit

Report both unrestricted dual correction and dual_agreement_guard. For the
guarded output, if raw A and S have identical argmax (lowest-index tie rule),
return the archived calibrated SSL vector; otherwise return unrestricted dual Q.
This is observable at inference and needs no true label or tuned threshold.
The SSL-only control does NOT use this acoustic-informed rule.

The guard cannot introduce additional errors relative to SSL on agreement cases,
and its total SSL-relative harms cannot exceed unrestricted dual harms. This is
a construction property, not a newly discovered generalization guarantee. It
can lose useful corrections when both branches agree on a wrong label. Audit
both sides, and never select between guarded and unrestricted variants post hoc.
All nine methods use the full test population. No subgroup is a success target.

## Statistics and fixed decision rule

Average three schedules WITHIN each singer, then use 20 paired singer units.
Primary metric: six-class macro-F1. Report pooled F1 separately, all singer and
class results, corrections of SSL errors, newly induced SSL errors, net correct
counts, branch states, agreement interventions, NLL and Brier scores. Rates use
all recordings in that singer, not only intervention/eligible cases. Do not
interpret descriptive NLL/Brier values as proved calibration improvement.

The ten fixed two-sided contrasts are specified in protocol.json; contrast 1
(dual minus SSL-only macro-F1) is the primary incremental-information question.
Compute 10,000 singer bootstrap draws (seed 2026111602), pointwise percentile
95% intervals, and the existing exact sign-flip convention (tail+1)/(2^20+1).
Report Holm-10 for this round, Holm-16 with the previous six gate contrasts, and
Holm-53 with those 16 plus the previously recorded joint family of 37 tests.
Old published/draft numbers and their 13/37/6 adjustments stay unchanged; the
new cumulative adjustments are additional columns, not overwritten evidence.
These corrections do not erase adaptive reuse of historical test outcomes.

Only a positive primary contrast with Holm-53 < .05 supports a statistically
supported exploratory incremental benefit in this configuration. Otherwise do
not claim acoustic benefit over SSL correction. Other contrasts, all harms, and
the guarded trade-off must also be disclosed. No noninferiority/equivalence
claim is allowed because none is planned. No protected subgroup-only claim.
Even success remains exploratory; independent untouched data would be needed
for a strong generalization/performance-innovation claim. Do not automatically
insert results into the manuscript or call this a novel algorithm.

## Runtime and preservation

Use the existing local isolated Python; one scientific process, one numerical
thread, CUDA hidden and model hubs offline. All old source, result, evidence and
failure files are hash-protected. A separately named execution_v1 Windows Job
owns the real worker and its redirector/descendants. No automatic restart.
Hard cap 30 minutes, no-log-progress cap 5 minutes, available memory hard stop
1 GiB, disk floor 4 GiB. Require 2 GiB before launch and each fold; wait no more
than five minutes. No closing applications, downloads, cloud/GPU or power changes.
Synthetic gradient, input separation, guard, metric and preservation tests and
a Windows Job child termination test must pass before real training.

After fitting and evaluation, confirm all task processes ended. Independently
replay feature scaling, objective/gradients, scalar probabilities, guard masks,
confusion metrics, transitions, bootstrap and Holm adjustments without refits;
reuse the pre-existing exact sign-flip routine transparently. Recheck every old
hash, input/source hash and ordering seal. Preserve all failures and adverse
findings. A separate report then judges whether any result is worth supplementing.

## Method provenance

Linear multiclass probability correction and post-hoc routing are established
ideas. This residual construction is a fixed diagnostic follow-up, not a claim
to invent Dirichlet calibration or learning-to-defer:

- https://proceedings.neurips.cc/paper/2019/hash/8ca01ea920679a0fe3728441494041b9-Abstract.html
- https://proceedings.neurips.cc/paper_files/paper/2023/hash/1f09e1ee5035a4c3fe38a5681cae5815-Abstract-Conference.html
- https://docs.scipy.org/doc/scipy/reference/optimize.minimize-lbfgsb.html
