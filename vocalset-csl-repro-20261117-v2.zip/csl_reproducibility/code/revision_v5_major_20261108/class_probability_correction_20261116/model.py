"""Small convex SSL-anchored probability correction, with no data-loading API."""
from collections import Counter
import warnings
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp, softmax
from threadpoolctl import threadpool_limits


def probabilities(value):
    p = np.asarray(value, dtype=float)
    if p.ndim != 2 or p.shape[1] != 6 or not np.isfinite(p).all() or (p < 0).any() or (p > 1).any():
        raise ValueError("Invalid six-class probabilities")
    if not np.allclose(p.sum(1), 1, atol=1e-9, rtol=0):
        raise ValueError("Invalid probability sums")
    return p


def features(ssl, acoustic=None):
    s = probabilities(ssl)
    if acoustic is None:
        return s.copy()
    a = probabilities(acoustic)
    if s.shape != a.shape:
        raise ValueError("Unaligned branch probabilities")
    return np.column_stack((s, a - s))


def singer_weights(groups):
    counts = Counter(groups)
    weights = np.array([1 / counts[g] for g in groups], dtype=float)
    return weights / weights.sum()


def objective(theta, design, offset, y, weights, ridge):
    matrix = np.asarray(theta).reshape(design.shape[1], 6)
    logits = offset + design @ matrix
    loss = float(weights @ (logsumexp(logits, axis=1) - logits[np.arange(len(y)), y]))
    residual = softmax(logits, axis=1)
    residual[np.arange(len(y)), y] -= 1
    gradient = design.T @ (weights[:, None] * residual) + ridge * matrix
    return loss + ridge * float(np.square(matrix).sum()) / 2, gradient.ravel()


def fit_one(ssl, y, groups, protocol, acoustic=None):
    s = probabilities(ssl)
    y = np.asarray(y, dtype=int)
    if len(y) != len(s) or len(groups) != len(s) or not np.isin(y, np.arange(6)).all():
        raise ValueError("Invalid training labels/groups")
    x = features(s, acoustic)
    mean, scale = x.mean(0), x.std(0)
    scale[np.ptp(x, axis=0) == 0] = 1
    design = np.column_stack(((x - mean) / scale, np.ones(len(x))))
    offset = np.log(np.maximum(s, protocol["log_floor"]))
    weights = singer_weights(groups)
    initial = np.zeros(design.shape[1] * 6)
    args = (design, offset, y, weights, protocol["ridge"])
    first = objective(initial, *args)[0]
    with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
        warnings.simplefilter("always")
        result = minimize(objective, initial, args=args, method="L-BFGS-B", jac=True, options=protocol["optimizer"])
    value, gradient = objective(result.x, *args)
    if caught or not result.success or not np.isfinite(result.x).all() or not np.isfinite(value):
        raise RuntimeError("Small-layer optimizer failed; no alternative fit: " + str(result.message))
    if np.max(np.abs(gradient)) > protocol["gradient_audit_tolerance"] or value > first + 1e-10:
        raise RuntimeError("Objective or stationary-gradient gate failed")
    return {"feature_mean": mean.tolist(), "feature_scale": scale.tolist(),
            "coefficients": result.x.reshape(design.shape[1], 6).tolist(),
            "parameters_stored": len(result.x), "initial_objective": first, "objective": value,
            "gradient_inf_norm": float(np.max(np.abs(gradient))), "iterations": int(result.nit),
            "evaluations": int(result.nfev), "optimizer_message": str(result.message),
            "uses_acoustic": acoustic is not None, "training_rows": len(y), "singer_count": len(set(groups)),
            "weight_sum": float(weights.sum()), "warnings": []}


def fit_models(training, protocol):
    allowed = {"seed", "fold", "held_singer", "clip_ids", "singers", "y", "acoustic_oof", "ssl_oof"}
    if set(training) != allowed:
        raise ValueError("Unexpected training field, possibly evaluation information")
    n = len(training["y"])
    if len(set(training["clip_ids"])) != n or len(training["singers"]) != n or training["held_singer"] in training["singers"]:
        raise ValueError("Duplicate, unaligned, or held-out training identity")
    s, a = probabilities(training["ssl_oof"]), probabilities(training["acoustic_oof"])
    if len(s) != n or s.shape != a.shape:
        raise ValueError("Training branch rows differ")
    models = {"ssl_correction": fit_one(s, training["y"], training["singers"], protocol),
              "dual_correction": fit_one(s, training["y"], training["singers"], protocol, a)}
    np.testing.assert_allclose(models["ssl_correction"]["feature_mean"], models["dual_correction"]["feature_mean"][:6], atol=1e-14)
    np.testing.assert_allclose(models["ssl_correction"]["feature_scale"], models["dual_correction"]["feature_scale"][:6], atol=1e-14)
    return {k: training[k] for k in ("seed", "fold", "held_singer")} | {"models": models}


def predict_one(model, ssl, protocol, acoustic=None):
    if model["uses_acoustic"] != (acoustic is not None):
        raise ValueError("Model branch contract differs")
    s = probabilities(ssl)
    x = features(s, acoustic)
    z = (x - np.array(model["feature_mean"])) / np.array(model["feature_scale"])
    design = np.column_stack((z, np.ones(len(z))))
    result = softmax(np.log(np.maximum(s, protocol["log_floor"])) + design @ np.array(model["coefficients"]), axis=1)
    return probabilities(result)


def agreement_guard(dual, acoustic, ssl, archived_ssl):
    a, s, q, reference = map(probabilities, (acoustic, ssl, dual, archived_ssl))
    if not (a.shape == s.shape == q.shape == reference.shape):
        raise ValueError("Guard branch alignment differs")
    if not np.array_equal(s.argmax(1), reference.argmax(1)):
        raise ValueError("Archived SSL calibration changed argmax")
    agreement = a.argmax(1) == s.argmax(1)
    return np.where(agreement[:, None], reference, q), agreement


def predict_models(fitted, outer, protocol):
    allowed = {"seed", "fold", "held_singer", "clip_ids", "singers", "acoustic", "ssl", "acoustic_calibrated", "ssl_calibrated", "static_fusion"}
    if set(outer) != allowed:
        raise ValueError("Unexpected outer field, possibly evaluation labels")
    if any(outer[k] != fitted[k] for k in ("seed", "fold", "held_singer")):
        raise ValueError("Wrong fold/singer model")
    if set(outer["singers"]) != {outer["held_singer"]} or len(set(outer["clip_ids"])) != len(outer["ssl"]):
        raise ValueError("Wrong outer identities")
    ss = predict_one(fitted["models"]["ssl_correction"], outer["ssl"], protocol)
    dual = predict_one(fitted["models"]["dual_correction"], outer["ssl"], protocol, outer["acoustic"])
    guarded, agreement = agreement_guard(dual, outer["acoustic"], outer["ssl"], outer["ssl_calibrated"])
    return {k: outer[k] for k in ("seed", "fold", "held_singer", "clip_ids")} | {
        "probabilities": {"ssl_correction": ss.tolist(), "dual_correction": dual.tolist(), "dual_agreement_guard": guarded.tolist()},
        "branch_agreement": agreement.tolist()}
