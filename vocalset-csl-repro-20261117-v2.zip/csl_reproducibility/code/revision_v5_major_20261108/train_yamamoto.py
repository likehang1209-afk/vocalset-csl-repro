"""Fixed two-stage paper-19 training, one held-out singer per invocation."""
from __future__ import annotations

import argparse
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch.nn import functional as F

from common import (clip_probabilities, digest, environment, file_hash, load_plan,
                    load_segments, read_json, report_record, seed_everything,
                    segment_indices, source_hashes, verify_model_folder, write_json)
from models import YamamotoSystem, class_weights


def checkpoint_rng(device):
    return {"version": 1, "python": random.getstate(), "numpy": np.random.get_state(),
            "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if device.startswith("cuda") else None}


def restore_checkpoint_rng(state, device):
    if state.get("version") != 1 or not {"python", "numpy", "torch", "cuda"} <= state.keys():
        raise RuntimeError("Incomplete RNG checkpoint; restart this fold in a fresh output directory")
    if device.startswith("cuda") and state["cuda"] is None:
        raise RuntimeError("CUDA RNG state missing from checkpoint")
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if device.startswith("cuda"):
        torch.cuda.set_rng_state_all(state["cuda"])


def build_system(model_dir, cfg, classes, device):
    from transformers import AutoConfig, AutoFeatureExtractor, AutoModel
    verify_model_folder(model_dir, cfg)
    config = AutoConfig.from_pretrained(model_dir, local_files_only=True)
    config.layerdrop = 0.0
    model = AutoModel.from_pretrained(model_dir, config=config, local_files_only=True)
    if config.num_hidden_layers != 12 or config.hidden_size != 768:
        raise ValueError("Unexpected paper-19 backbone architecture")
    processor = AutoFeatureExtractor.from_pretrained(model_dir, local_files_only=True)
    return YamamotoSystem(model, classes).to(device), processor


def prepare_batch(wave, metadata, indices, processor, sr, device):
    audio = [np.asarray(wave[i, :metadata["segments"][i][f"valid_{sr}"]]) for i in indices]
    batch = processor(audio, sampling_rate=sr, padding="max_length", max_length=wave.shape[1],
                      return_attention_mask=True, return_tensors="pt")
    return batch.input_values.to(device), batch.attention_mask.to(device)


def weighted_step(system, optimizer, inputs, targets, weights, micro_batch):
    """Preserve the logical-batch weighted CE denominator across accumulation."""
    optimizer.zero_grad(set_to_none=True)
    denominator = weights[targets].sum()
    total = 0.0
    for begin in range(0, len(targets), micro_batch):
        end = begin + micro_batch
        logits = system(inputs[0][begin:end], inputs[1][begin:end])
        loss = F.cross_entropy(logits, targets[begin:end], weight=weights, reduction="sum") / denominator
        if not torch.isfinite(loss):
            raise FloatingPointError("Nonfinite training loss; no result will be saved")
        loss.backward()
        total += float(loss.detach())
    optimizer.step()
    return total


def predict(system, processor, wave, meta, indices, sr, device, batch_size):
    system.eval()
    output = []
    with torch.inference_mode():
        for begin in range(0, len(indices), batch_size):
            inp = prepare_batch(wave, meta, indices[begin:begin+batch_size], processor, sr, device)
            output.append(system(*inp).softmax(-1).cpu().numpy())
    return np.concatenate(output)


def run(args):
    plan = load_plan(args.plan)
    recipe = plan["protocol"]["yamamoto"]
    cfg = plan["protocol"]["models"][args.model]
    fold = plan["folds"][args.fold]
    meta = load_segments(args.audio, plan)
    audio_path = args.audio / "waveforms_16000.npy"
    if file_hash(audio_path) != meta["files"][audio_path.name]:
        raise ValueError("Audio cache was changed")
    wave = np.load(audio_path, mmap_mode="r", allow_pickle=False)
    tr = segment_indices(meta, fold["train"])
    targets = np.array([r["target"] for r in meta["segments"]])
    seed = plan["protocol"]["training_seed"] + 1000 * args.fold
    seed_everything(seed)
    system, processor = build_system(args.models / args.model, cfg, len(plan["labels"]), args.device)
    if args.device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats()
    weights = class_weights(targets[tr], len(plan["labels"]), recipe["loss_weight_exponent"]).to(args.device)
    destination = args.output / ("smoke" if args.smoke else "yamamoto") / args.model / f"fold_{args.fold:02d}"
    destination.mkdir(parents=True, exist_ok=True)
    identity = {"plan": plan["fingerprint"], "segments": meta["fingerprint"],
                "model": cfg, "fold": args.fold, "source_hashes": source_hashes(),
                "environment": environment(), "smoke": args.smoke}
    lock = destination / "run_lock.json"
    if lock.exists() and read_json(lock) != identity:
        raise RuntimeError("Stale run: code, data, environment or configuration changed")
    write_json(lock, identity)
    if (destination / "result.json").exists():
        print("Completed result already exists", flush=True)
        return
    checkpoint = destination / "training.pt"
    start_epoch, history, restored = 0, [], None
    if checkpoint.exists():
        # Only checkpoints written by this run directory are accepted.
        restored = torch.load(checkpoint, map_location="cpu", weights_only=False)
        if restored["identity"] != digest(identity):
            raise RuntimeError("Checkpoint fingerprint mismatch")
        if "rng_state" not in restored:
            raise RuntimeError("Legacy checkpoint lacks complete RNG state; restart this fold in a fresh output directory")
        system.load_state_dict(restored["state"])
        start_epoch, history = restored["next_epoch"], restored["history"]
    start = time.perf_counter()
    optimizer, previous_stage = None, None
    epoch_numbers = [0, recipe["frozen_epochs"]] if args.smoke else range(start_epoch, recipe["epochs"])
    for epoch in epoch_numbers:
        stage = 1 if epoch < recipe["frozen_epochs"] else 2
        if stage != previous_stage:
            system.set_stage(stage)
            optimizer = torch.optim.Adam([p for p in system.parameters() if p.requires_grad],
                lr=recipe["stage1_lr"] if stage == 1 else recipe["stage2_lr"])
            if restored is not None and restored["stage"] == stage:
                optimizer.load_state_dict(restored["optimizer"])
                for state in optimizer.state.values():
                    for key, value in state.items():
                        if torch.is_tensor(value):
                            state[key] = value.to(args.device)
            previous_stage = stage
        if restored is not None:
            restore_checkpoint_rng(restored["rng_state"], args.device)
            restored = None
        system.train()
        order = np.random.default_rng(seed+epoch).permutation(tr)
        if args.smoke:
            order = order[:recipe["effective_batch_size"]]
        losses = []
        for begin in range(0, len(order), recipe["effective_batch_size"]):
            indices = order[begin:begin+recipe["effective_batch_size"]]
            inputs = prepare_batch(wave, meta, indices, processor, 16000, args.device)
            labels = torch.tensor(targets[indices], device=args.device)
            losses.append(weighted_step(system, optimizer, inputs, labels, weights, recipe["micro_batch_size"]))
        history.append({"epoch": epoch+1, "stage": stage, "mean_batch_loss": float(np.mean(losses))})
        print(f"{args.model} fold={args.fold} epoch={epoch+1} stage={stage} loss={np.mean(losses):.5f}", flush=True)
        if not args.smoke:
            tmp = checkpoint.with_suffix(".tmp")
            torch.save({"identity": digest(identity), "next_epoch": epoch+1, "stage": stage,
                        "state": system.state_dict(), "optimizer": optimizer.state_dict(),
                        "history": history, "rng_state": checkpoint_rng(args.device)}, tmp)
            tmp.replace(checkpoint)
    details = {"recipe": recipe, "history": history, "training_segments": len(tr),
               "seed": seed, "training_class_weights": weights.cpu().tolist(),
               "peak_cuda_bytes": torch.cuda.max_memory_allocated() if args.device.startswith("cuda") else None}
    if args.smoke:
        write_json(destination / "smoke_report.json", {"identity": identity, "details": details,
                   "seconds": time.perf_counter()-start, "outer_test_evaluated": False})
        return
    te = segment_indices(meta, fold["test"])
    segments_p = predict(system, processor, wave, meta, te, 16000, args.device, recipe["micro_batch_size"])
    p = clip_probabilities(segments_p, [meta["segments"][i]["clip_id"] for i in te], fold["test"])
    record = report_record(plan, fold, f"yamamoto_{args.model}", fold["test"], p,
                           details, time.perf_counter()-start)
    write_json(destination / "result.json", record)
    # A completed result can be regenerated from the pinned recipe; free this run's large optimizer cache.
    if checkpoint.exists():
        checkpoint.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("plan", "audio", "models", "output"):
        parser.add_argument("--"+name, type=Path, required=True)
    parser.add_argument("--model", choices=["music2vec", "wavlm"], required=True)
    parser.add_argument("--fold", type=int, choices=range(20), required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; this command does not start a cloud instance")
    if args.device == "cpu" and not args.smoke:
        raise RuntimeError("Full backbone training is GPU-only to prevent accidental multi-day CPU runs")
    torch.set_num_threads(4)
    run(args)


if __name__ == "__main__":
    main()
