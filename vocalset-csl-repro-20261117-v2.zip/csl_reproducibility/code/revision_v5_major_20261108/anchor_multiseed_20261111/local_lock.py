"""Windows process-scoped file lease preventing duplicate local writers."""
import msvcrt
from pathlib import Path


class OutputLease:
    def __init__(self, output):
        output = Path(output)
        output.mkdir(parents=True, exist_ok=True)
        self.stream = (output / '.writer.lock').open('a+b')
        if self.stream.seek(0, 2) == 0:
            self.stream.write(b'0')
            self.stream.flush()
        self.stream.seek(0)
        try:
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            self.stream.close()
            raise RuntimeError('Output directory already has an active writer') from error

    def close(self):
        if not self.stream.closed:
            self.stream.seek(0)
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            self.stream.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
