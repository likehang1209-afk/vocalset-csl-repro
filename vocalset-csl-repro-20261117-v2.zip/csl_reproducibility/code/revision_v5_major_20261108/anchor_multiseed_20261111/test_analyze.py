import unittest
import numpy as np
import analyze as a


class AnalysisTests(unittest.TestCase):
    def test_float32_neural_tolerance_is_explicit(self):
        probability = np.full((6, 6), 1 / 6, dtype=np.float32).astype(float)
        with self.assertRaises(ValueError):
            a.audit.metrics(np.arange(6), probability)
        result = a.audit.metrics(np.arange(6), probability, 1e-5)
        self.assertTrue(np.isfinite(result['nll']))

    def test_singer_is_the_unit(self):
        values = np.arange(60).reshape(3, 20)
        np.testing.assert_array_equal(a.mean_within_singer(values), np.arange(20) + 20)

    def test_incomplete_and_nonfinite_fail(self):
        for values in (np.zeros((2, 20)), np.zeros((3, 19)), np.full((3, 20), np.nan)):
            with self.assertRaises(ValueError):
                a.mean_within_singer(values)

    def test_all_contrasts_and_joint_family(self):
        rows = [{'method': 'late_fusion_calibrated', 'anchor': 'ssl', 'p_raw': .01}]
        rows += [{'method': m, 'anchor': anchor, 'p_raw': .1} for anchor in ('ssl', 'late_fusion_calibrated') for m in a.NEURAL]
        prior = [{'p_raw': .2} for _ in range(24)]
        a.adjust(rows, prior)
        self.assertAlmostEqual(rows[0]['p_holm_13'], .13)
        self.assertAlmostEqual(rows[0]['p_holm_joint_37'], .37)
        self.assertTrue(all(r['p_holm_joint_37'] >= r['p_holm_13'] for r in rows))
        with self.assertRaises(ValueError):
            a.adjust(rows[:-1], prior)

    def test_holm_known_vector(self):
        np.testing.assert_allclose(a.holm([.01, .04, .03]), [.03, .06, .06])


if __name__ == '__main__':
    unittest.main()
