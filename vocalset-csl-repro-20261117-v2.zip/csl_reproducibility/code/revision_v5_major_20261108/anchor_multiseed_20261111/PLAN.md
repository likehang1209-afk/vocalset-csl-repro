# Original-pipeline training-seed sensitivity

Recorded 2026-11-11 before new fits. This is an exploratory extension of an
already inspected corpus, not preregistration or independent confirmation.

## Scope and estimand

Repeat the original acoustic and selected-SSL branches, training-only
calibration and late-fusion selection. Early fusion is not needed to construct
either comparator and is outside this bounded extension. Preserve all original
results and all360 completed neural records unchanged.

Use training schedules20260824,30260824,40260824 and all twenty outer singers.
Freeze the exact original inner and outer clip IDs from the existing validated
plan. Never pass a new training seed into the partition generator. Keep the
original candidate sets, features, precision, losses, stopping criteria, model
selection and final-refit offsets. Rerank every candidate, not only historical
winners. The primary control is a full-search baseline replay, not a selected
model replay. All three schedules run in the same compatible environment.

The old historical predictions remain a separate anchor. New baseline results
are checked against them, but new summaries use three newly evaluated schedules
rather than silently counting an old unverified fit as one of three. If full
search selects differently, retain the discrepancy and investigate before
continuing; do not use outer scores to choose between implementations.

LogisticRegression(lbfgs) ignores random_state. Its identical within-fold
candidate probabilities may be reused across schedules only after a same-input
different-seed numerical check passes. Record reuse explicitly. All tree and
LinearSVC candidates are refitted for each schedule. Reusing deterministic
calculations does not create additional independent evidence.

## Validation and resources

Use the existing scikit-learn1.7.2 compatibility implementation. Verify source,
feature-store metadata, clip order, stored completion flags, selected arrays,
data/plan fingerprints and explicit split equality before fitting. Input files
are read-only. Persist each candidate and outer result atomically, tied to the
full run fingerprint. Fail on a changed identity, invalid probability,
convergence warning or disk-space shortage. A pilot uses the first outer singer,
fixed in advance, without inspecting its score to change the recipe.

Local CPU only, at most three concurrent candidate fits, BLAS/OpenMP one thread
per fit; tree fitting uses at most three threads when no candidate pool runs.
No cloud operation, model download, GPU extraction or alteration of old files.
Report measured timing rather than promising a fixed duration. A complete
block needs60 outer jobs (three schedules x twenty singers), each with five
probability outputs (raw/calibrated acoustic and SSL, plus late fusion).

## Analysis fixed before new outcomes

For each of the three primary methods, report each schedule, mean pooled F1
and sample seed SD. Average F1 within singer over the three schedules. Compare
newly repeated late fusion versus newly repeated SSL as the one focal contrast.
Retain the other twelve neural-system-versus-anchor contrasts as a complete
secondary family, with all old analyses unchanged and separately labelled.
Use twenty singer differences,10000 bootstrap draws(seed20260825), the inherited
exhaustive sign-flip calculation and Holm adjustment across all thirteen new
contrasts. Also show a conservative adjustment across the previously reported
24 and these13 tests if inference is presented jointly. No best seed, outer-score
model shopping, post-hoc equivalence margin or60-singer pseudoreplication.

The three original-pipeline training seeds differ from neural seeds. No paired
random-number correspondence is claimed. The singer is the pairing unit.
The extension measures training sensitivity under fixed partitions, not an
independent corpus or an algorithmic innovation. Partial coverage remains a
timing/pilot record and does not enter manuscript conclusions.
