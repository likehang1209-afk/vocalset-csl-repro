"""Read-only independent confusion/probability audit of the local seed results."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SEEDS = (20260824, 30260824, 40260824)
METHODS = {'acoustic', 'acoustic_calibrated', 'ssl', 'ssl_calibrated', 'late_fusion_calibrated'}


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def checked(path):
    record = load(path)
    supplied = record.pop('payload_sha256')
    if supplied != digest(record):
        raise ValueError('Payload hash mismatch: ' + str(path))
    return record


def metrics(y, raw, sum_tolerance=1e-9):
    p = np.asarray(raw, dtype=np.float64)
    y = np.asarray(y, dtype=int)
    if p.shape != (len(y), 6) or not np.isfinite(p).all() or (p < 0).any() or not np.allclose(p.sum(1), 1, atol=sum_tolerance, rtol=0):
        raise ValueError('Invalid probability matrix')
    p = np.clip(p, 1e-12, None)
    p /= p.sum(1, keepdims=True)
    prediction = p.argmax(1)
    cm = np.zeros((6, 6), dtype=int)
    np.add.at(cm, (y, prediction), 1)
    support, predicted = cm.sum(1), cm.sum(0)
    diagonal = cm.diagonal()
    f1 = np.divide(2 * diagonal, support + predicted, out=np.zeros(6), where=(support + predicted) > 0)
    recall = np.divide(diagonal, support, out=np.zeros(6), where=support > 0)
    present = support > 0
    confidence = p.max(1)
    correct = prediction == y
    ece = 0.
    edges = np.linspace(0, 1, 16)
    for i in range(15):
        use = (confidence >= edges[i]) & ((confidence < edges[i + 1]) if i < 14 else (confidence <= edges[i + 1]))
        if use.any():
            ece += use.mean() * abs(correct[use].mean() - confidence[use].mean())
    return {'sample_count': len(y), 'present_class_count': int(present.sum()), 'accuracy': float(correct.mean()),
            'macro_f1_present': float(f1[present].mean()), 'macro_f1_global': float(f1.mean()),
            'uar_present': float(recall[present].mean()), 'uar_global': float(recall.mean()),
            'nll': float(-np.log(np.clip(p[np.arange(len(y)), y], 1e-12, 1)).mean()),
            'brier': float(((p - np.eye(6)[y]) ** 2).sum(1).mean()), 'ece': float(ece),
            'class_support': support.tolist(), 'confusion': cm.tolist()}


def compare(actual, expected):
    if set(actual) != set(expected):
        raise ValueError('Metric field set differs')
    for key in expected:
        if not np.allclose(actual[key], expected[key], atol=1e-11, rtol=0):
            raise ValueError('Metric replay failed: ' + key)


def audit(output, partial=False):
    lock = load(output / 'run_lock.json')
    binding = dict(lock)
    fingerprint = binding.pop('fingerprint')
    if digest(binding) != fingerprint or binding['seeds'] != list(SEEDS):
        raise ValueError('Run binding changed')
    for name, wanted in binding['sources'].items():
        if sha(ROOT / name) != wanted:
            raise ValueError('Frozen source changed: ' + name)
    plan = load(HERE.parent / 'artifacts/plan.json')
    clips = {c['clip_id']: c for c in plan['clips']}
    complete, missing, seen, candidate_count = [], [], set(), 0
    for seed in SEEDS:
        seed_ids = []
        for fold in plan['folds']:
            path = output / f'seed_{seed}' / f"fold_{fold['fold']:02d}.json"
            if not path.exists():
                missing.append({'seed': seed, 'fold': fold['fold']})
                continue
            r = checked(path)
            if r['fingerprint'] != fingerprint or r['seed'] != seed or r['fold'] != fold['fold'] or r['held_singer'] != fold['held_singer']:
                raise ValueError('Fold identity mismatch')
            if r['labels'] != plan['labels'] or r['clip_ids'] != fold['test'] or r['y_true'] != [clips[x]['target'] for x in fold['test']]:
                raise ValueError('Test identity/target mismatch')
            if set(r['probabilities']) != METHODS:
                raise ValueError('Incomplete branch results')
            for method in METHODS:
                compare(metrics(r['y_true'], r['probabilities'][method]), r['metrics'][method])
            if seed == SEEDS[0]:
                if set(r['historical_replay']) != METHODS or any(x['max_probability_error'] > 1e-5 or x['changed_labels'] for x in r['historical_replay'].values()):
                    raise ValueError('Historical baseline not replayed')
                if len(r['historical_selection_replay']) != 7:
                    raise ValueError('Historical selection audit missing')
            if not partial:
                for branch, expected_count in (('acoustic', 7), ('ssl', 96)):
                    directory = output / 'candidates' / f'seed_{seed}' / f"fold_{fold['fold']:02d}" / branch
                    records = list(directory.glob('*.json'))
                    if len(records) != expected_count or r['selection'][branch]['candidate_count'] != expected_count:
                        raise ValueError('Candidate search coverage differs')
                    identities = set()
                    for source in records:
                        c = checked(source)
                        if c['fingerprint'] != fingerprint or c['seed'] != seed or c['fold'] != fold['fold'] or c['branch'] != branch or not c['warning_audit_passed']:
                            raise ValueError('Candidate provenance/warning failure')
                        identity = (c['representation'], c['spec'])
                        if identity in identities:
                            raise ValueError('Duplicate candidate identity')
                        identities.add(identity)
                        metrics([clips[x]['target'] for x in fold['train']], c['oof'])
                        candidate_count += 1
            seed_ids.extend(r['clip_ids'])
            seen.add(path.resolve())
            complete.append({'seed': seed, 'fold': fold['fold'], 'sha256': sha(path)})
        if len(seed_ids) != len(set(seed_ids)):
            raise ValueError('Repeated outer test clip')
        if not partial and set(seed_ids) != set(clips):
            raise ValueError('Incomplete per-seed test coverage')
    on_disk = {p.resolve() for p in output.glob('seed_*/fold_*.json')}
    if on_disk != seen:
        raise ValueError('Unexpected seed/fold files')
    if missing and not partial:
        raise ValueError('Not all60 outer results exist')
    if not partial:
        data = Path('local_inputs/final_release_archive_20260824/vocalset_data')
        for name, wanted in binding['data'].items():
            if sha(data / name) != wanted:
                raise ValueError('Input hash changed: ' + name)
        receipt = load(output / 'completion.json')
        if not receipt['complete'] or receipt['results'] != complete or receipt['fingerprint'] != fingerprint:
            raise ValueError('Completion receipt differs')
    result = {'audited_unix': time.time(), 'fingerprint': fingerprint, 'completed': len(complete), 'required': 60,
              'missing': missing, 'all_60_verified': len(complete) == 60 and not partial,
              'complete_candidate_records_verified': candidate_count, 'independent_metric_replay': True,
              'partial_inspection_only': partial, 'cloud_accessed': False, 'results': complete}
    destination = output / ('partial_audit.json' if partial else 'full_audit.json')
    temporary = destination.with_suffix('.tmp')
    temporary.write_text(json.dumps(result, indent=2), encoding='utf-8')
    temporary.replace(destination)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=HERE / 'results_v2')
    parser.add_argument('--partial', action='store_true')
    args = parser.parse_args()
    report = audit(args.output, args.partial)
    print(json.dumps({k: v for k, v in report.items() if k not in ('missing', 'results')}))
