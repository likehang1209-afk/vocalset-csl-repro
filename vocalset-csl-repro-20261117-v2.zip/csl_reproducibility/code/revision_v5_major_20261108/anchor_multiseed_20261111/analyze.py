"""Analyze only a complete verified original-pipeline seed extension."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd

import audit

HERE = Path(__file__).resolve().parent
REV = HERE.parent
sys.path.insert(0, str(REV.parent / 'src'))
from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue

PRIMARY = ('acoustic', 'ssl', 'late_fusion_calibrated')
NEURAL = ('yamamoto_music2vec', 'yamamoto_wavlm', 'zhou_muq_weighted', 'zhou_muq_scan',
          'zhou_musicfm_weighted', 'zhou_musicfm_scan')
NEURAL_SEEDS = (20261108, 30261108, 40261108)
CAPTURE = Path('local_inputs/major_revision_20261108/seed_final_live_capture_20261110T142951Z')


def mean_within_singer(values):
    x = np.asarray(values, dtype=float)
    if x.shape != (3, 20) or not np.isfinite(x).all():
        raise ValueError('Exactly three schedules and twenty singers required')
    return x.mean(0)


def holm(values):
    p = np.asarray(values, dtype=float)
    if p.ndim != 1 or not len(p) or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError('Invalid p values')
    order = np.argsort(p, kind='stable')
    result = np.empty_like(p)
    result[order] = np.minimum(1, np.maximum.accumulate(p[order] * np.arange(len(p), 0, -1)))
    return result


def contrast(method, anchor, difference):
    difference = np.asarray(difference)
    if difference.shape != (20,) or not np.isfinite(difference).all():
        raise ValueError('Paired unit must be twenty singers')
    interval = paired_cluster_bootstrap(difference, replicates=10000, seed=20260825)
    return {'method': method, 'anchor': anchor, **interval, 'p_raw': paired_sign_flip_pvalue(difference),
            'wins': int((difference > 0).sum()), 'ties': int((difference == 0).sum()),
            'losses': int((difference < 0).sum())}


def adjust(new, prior):
    expected = {('late_fusion_calibrated', 'ssl')} | {(m, a) for a in ('ssl', 'late_fusion_calibrated') for m in NEURAL}
    if len(new) != 13 or {(r['method'], r['anchor']) for r in new} != expected or len(prior) != 24:
        raise ValueError('Declared complete contrast families required')
    for row, p in zip(new, holm([r['p_raw'] for r in new])):
        row['p_holm_13'] = float(p)
    for row, p in zip(prior + new, holm([r['p_raw'] for r in prior + new])):
        row['p_holm_joint_37'] = float(p)


def run(results, destination):
    if destination.exists():
        raise FileExistsError('Use a new analysis destination')
    verification = audit.audit(results)
    if not verification['all_60_verified'] or verification['complete_candidate_records_verified'] != 6180:
        raise ValueError('Complete original-pipeline verification required')
    plan = audit.load(REV / 'artifacts/plan.json')
    ids = [c['clip_id'] for c in plan['clips']]
    y = np.array([c['target'] for c in plan['clips']])
    singers = sorted({c['singer_id'] for c in plan['clips']})
    masks = {s: np.array([c['singer_id'] == s for c in plan['clips']]) for s in singers}
    pooled, per_singer, matrices = [], [], {}

    def add(seed, method, p, sum_tolerance=1e-9):
        score = audit.metrics(y, p, sum_tolerance)
        pooled.append({'seed': seed, 'method': method, 'pooled_f1': score['macro_f1_global'],
                       'uar': score['uar_global'], 'accuracy': score['accuracy'], 'nll': score['nll'],
                       'brier': score['brier'], 'ece': score['ece']})
        values = []
        for s in singers:
            score = audit.metrics(y[masks[s]], p[masks[s]], sum_tolerance)
            if score['present_class_count'] != 6:
                raise ValueError('Six-class singer support changed')
            values.append(score['macro_f1_global'])
            per_singer.append({'seed': seed, 'method': method, 'singer': s, 'macro_f1': values[-1]})
        matrices.setdefault(method, []).append(values)

    for seed in audit.SEEDS:
        by_method = {m: {} for m in PRIMARY}
        for fold in plan['folds']:
            r = audit.checked(results / f'seed_{seed}' / f"fold_{fold['fold']:02d}.json")
            for method in PRIMARY:
                by_method[method].update(zip(r['clip_ids'], r['probabilities'][method]))
        for method in PRIMARY:
            if set(by_method[method]) != set(ids):
                raise ValueError('Original test coverage differs')
            add(seed, method, np.array([by_method[method][x] for x in ids]))

    receipt_path = CAPTURE / 'verified_three_seed_360_20261110T144147Z.json'
    receipt = audit.load(receipt_path)
    aggregate = Path(receipt['aggregate_path'])
    if receipt['completed_results'] != 360 or receipt['seed_schedules'] != list(NEURAL_SEEDS) or audit.sha(aggregate) != receipt['aggregate_sha256']:
        raise ValueError('Neural source is not the verified360-result block')
    data = audit.load(aggregate)
    if set(data) != {str(s) for s in NEURAL_SEEDS}:
        raise ValueError('Unexpected neural schedules')
    for seed in NEURAL_SEEDS:
        records = data[str(seed)]['methods']
        seed_plan_path = REV / 'artifacts/plan.json' if seed == NEURAL_SEEDS[0] else REV / f'seed_extension_20261109/plans/seed_{seed}.json'
        if data[str(seed)]['plan_fingerprint'] != audit.load(seed_plan_path)['fingerprint']:
            raise ValueError('Neural plan identity differs')
        if set(records) != set(NEURAL):
            raise ValueError('Neural method inventory differs')
        for method in NEURAL:
            item = records[method]
            if item['clip_ids'] != ids:
                raise ValueError('Neural clip order differs')
            p = np.asarray(item['probabilities'])
            # Preserve the inherited neural float32 output tolerance; local fits remain strict float64.
            audit.compare(audit.metrics(y, p, 1e-5), item['pooled'])
            add(seed, method, p, 1e-5)
    averaged = {m: mean_within_singer(x) for m, x in matrices.items()}
    summary = []
    for method in PRIMARY + NEURAL:
        rows = [r for r in pooled if r['method'] == method]
        r = {'method': method, 'singer_mean_f1': float(averaged[method].mean()),
             'singer_sd_of_seed_means': float(averaged[method].std(ddof=1))}
        for key in ('pooled_f1', 'uar', 'accuracy'):
            values = [x[key] for x in rows]
            r[key + '_mean'] = float(np.mean(values))
            r[key + '_seed_sd'] = float(np.std(values, ddof=1))
        summary.append(r)
    contrasts = [contrast('late_fusion_calibrated', 'ssl', averaged['late_fusion_calibrated'] - averaged['ssl'])]
    for anchor in ('ssl', 'late_fusion_calibrated'):
        contrasts.extend(contrast(method, anchor, averaged[method] - averaged[anchor]) for method in NEURAL)
    prior_path = REV / 'analysis_multiseed_20261110/results_v1/analysis.json'
    prior_analysis = audit.load(prior_path)
    if prior_analysis['completed_folds'] != 360 or prior_analysis['family_sizes'] != [12, 24]:
        raise ValueError('Prior multiplicity family differs')
    prior = [dict(r, family='historical_fixed_anchor') for r in prior_analysis['historical_contrasts_with_joint_correction']]
    prior += [dict(r, family='neural_multiseed_fixed_anchor') for r in prior_analysis['contrasts']]
    adjust(contrasts, prior)
    destination.mkdir(parents=True)
    for name, rows in (('per_seed', pooled), ('per_singer', per_singer), ('summary', summary),
                       ('contrasts_13', contrasts), ('previous_24_with_joint37', prior)):
        pd.DataFrame(rows).to_csv(destination / (name + '.csv'), index=False)
    report = {'status': 'complete_audited', 'time_unix': time.time(), 'original_outer_jobs': 60,
              'neural_outer_results': 360, 'original_training_seeds': list(audit.SEEDS), 'neural_training_seeds': list(NEURAL_SEEDS),
              'inference_units': 20, 'singers': singers, 'family_sizes': [13, 37], 'bootstrap_seed': 20260825,
              'bootstrap_draws': 10000, 'contrasts': contrasts, 'summary': summary,
              'provenance': {'original_fingerprint': verification['fingerprint'], 'neural_aggregate_sha256': audit.sha(aggregate),
                             'prior_analysis_sha256': audit.sha(prior_path), 'source_sha256': audit.sha(Path(__file__)),
                             'plan_sha256': audit.sha(HERE / 'PLAN.md'), 'auditor_sha256': audit.sha(HERE / 'audit.py'),
                             'inference_sha256': audit.sha(REV.parent / 'src/vocalset_csl/inference.py')},
              'limits': ['exploratory extension after observing earlier outcomes', 'three schedules not three independent datasets',
                         'twenty singer pairs; overlapping LOSO training sets', 'pointwise bootstrap intervals',
                         'no early-fusion seed extension', 'no equivalence or causal training-recipe claim']}
    (destination / 'analysis.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    print(pd.DataFrame(summary).to_string(index=False))
    print(pd.DataFrame(contrasts).to_string(index=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, default=HERE / 'results_v2')
    parser.add_argument('--output', type=Path, default=HERE / 'analysis_v1')
    args = parser.parse_args()
    run(args.results, args.output)
