"""Bounded local reranking of historical branches with fixed explicit partitions."""
from __future__ import annotations

import argparse
from contextlib import nullcontext
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import warnings
from local_lock import OutputLease

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
VENDOR = ROOT / 'revision_v4_major_20260922/replay_vendor_sklearn172'
sys.path.insert(0, str(VENDOR))
sys.path.insert(0, str(ROOT / 'src'))
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits, threadpool_info
from vocalset_csl.calibration import apply_temperature, fit_temperature
from vocalset_csl.feature_io import load_feature_npz, align_feature_rows, exclude_named_features
from vocalset_csl.fusion import fuse_probabilities, select_fusion
from vocalset_csl.metrics import classification_metrics, selection_utility
from vocalset_csl.modeling import default_specs, build_model, aligned_probability
from vocalset_csl.representation_io import load_multiple_embedding_stores
from vocalset_csl.splitting import Split, stratified_group_folds, assert_group_disjoint
from vocalset_csl.tasks import select_task

SEEDS = (20260824, 30260824, 40260824)
DATA = Path('local_inputs/final_release_archive_20260824/vocalset_data')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    tmp.replace(path)


def sign(value):
    return {**value, 'payload_sha256': digest(value)}


def verify(value):
    body = dict(value)
    supplied = body.pop('payload_sha256')
    if digest(body) != supplied:
        raise ValueError('Cached payload hash mismatch')
    return body


def probability_check(p, n):
    p = np.asarray(p, dtype=float)
    if p.shape != (n, 6) or not np.isfinite(p).all() or (p < 0).any() or not np.allclose(p.sum(1), 1, atol=1e-9, rtol=0):
        raise ValueError('Invalid candidate probabilities')
    return p


def explicit_splits(frame, fold):
    ids = frame.clip_id.tolist()
    positions = {clip: i for i, clip in enumerate(ids)}
    train = np.array([positions[x] for x in fold['train']], dtype=int)
    test = np.array([positions[x] for x in fold['test']], dtype=int)
    local = {ids[j]: i for i, j in enumerate(train)}
    inner = [Split('inner_' + str(i), np.array([local[x] for x in row['train']], dtype=int),
                   np.array([local[x] for x in row['validation']], dtype=int))
             for i, row in enumerate(fold['inner'])]
    groups = frame.singer_id.to_numpy()
    assert_group_disjoint(train, test, groups)
    for split in inner:
        assert_group_disjoint(split.train, split.test, groups[train])
    if sorted(np.concatenate([s.test for s in inner]).tolist()) != list(range(len(train))):
        raise ValueError('Inner coverage changed')
    expected = stratified_group_folds(frame.target.to_numpy()[train], groups[train], 4, 20260824 + fold['fold'])
    if len(inner) != 4 or len(expected) != 4 or any(not np.array_equal(a.train, b.train) or not np.array_equal(a.test, b.test) for a, b in zip(inner, expected)):
        raise ValueError('Explicit partitions do not equal the compatible historical algorithm')
    return train, test, inner


def prepare(data, output, workers):
    if sklearn.__version__ != '1.7.2':
        raise RuntimeError('Use the existing compatible scikit-learn1.7.2 implementation')
    config = read(ROOT / 'configs/protocol_v2.json')
    plan_path = HERE.parent / 'artifacts/plan.json'
    plan = read(plan_path)
    signed = dict(plan)
    supplied = signed.pop('fingerprint')
    compact = hashlib.sha256(json.dumps(signed, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    if compact != supplied:
        raise ValueError('Neural/common split-plan fingerprint changed')
    frame, labels = select_task(pd.read_csv(data / 'manifest.csv'), config, 'production_shared_6')
    if len(frame) != 1206 or len(labels) != 6 or frame.singer_id.nunique() != 20:
        raise ValueError('Cohort differs')
    if frame.clip_id.tolist() != [c['clip_id'] for c in plan['clips']] or labels != plan['labels']:
        raise ValueError('Common clip order/labels differ')
    ids = frame.clip_id.to_numpy()
    f = load_feature_npz(data / 'features/acoustic_egemaps_singing.npz')
    acoustic = align_feature_rows(ids, f['clip_ids'], f['values'])
    acoustic, names = exclude_named_features(acoustic, f['feature_names'], ['duration_seconds'])
    if len(names) != 183:
        raise ValueError('Acoustic dimension changed')
    models = list(config['ssl_models'])
    ssl, metadata = load_multiple_embedding_stores(data / 'embeddings', models, ids, config['layer_probe']['normalized_depths'])
    source_paths = list((ROOT / 'src/vocalset_csl').glob('*.py')) + [Path(__file__), HERE / 'local_lock.py', HERE / 'PLAN.md', HERE / 'EXECUTION_V2.md', ROOT / 'configs/protocol_v2.json', plan_path]
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in source_paths}
    historical = data / 'results/nested_loso_full_checkpointed_20260824/production_shared_6'
    paths = [data / 'manifest.csv', data / 'features/acoustic_egemaps_singing.npz',
             historical / 'outer_predictions.csv', historical / 'inner_selections.csv']
    for model, meta in metadata.items():
        base = data / 'embeddings' / model
        paths += [base / x for x in ('metadata.json', 'clip_ids.npy', 'status.npy')]
        paths += [base / meta['layers'][s['layer_index']]['file'] for s in meta['selected_layers']]
    versions = {k: v.__version__ for k, v in [('numpy', np), ('pandas', pd), ('scipy', scipy), ('sklearn', sklearn)]}
    binding = {'sources': sources, 'data': {p.relative_to(data).as_posix(): sha(p) for p in paths},
               'versions': versions, 'splitter_sha256': sha(Path(sklearn.__file__).parent / 'model_selection/_split.py'),
               'python_version': sys.version, 'workers': workers,
               'threadpool_libraries': [{k: t.get(k) for k in ('internal_api', 'version', 'num_threads', 'architecture')} for t in threadpool_info()],
               'worker_model': 'isolated processes; one BLAS/OpenMP thread; trees at most workers threads',
               'seeds': list(SEEDS), 'common_plan_fingerprint': supplied, 'branches': ['acoustic', 'ssl', 'late_fusion_calibrated']}
    fingerprint = digest(binding)
    lock = output / 'run_lock.json'
    if lock.exists() and read(lock)['fingerprint'] != fingerprint:
        raise ValueError('Output run identity changed')
    write(lock, {'fingerprint': fingerprint, **binding})
    split_rows = []
    for fold in plan['folds']:
        train, test, inner = explicit_splits(frame, fold)
        split_rows.append({'fold': fold['fold'], 'train': train.tolist(), 'test': test.tolist(),
                           'inner': [{'train': s.train.tolist(), 'test': s.test.tolist()} for s in inner]})
    write(output / 'explicit_splits.json', split_rows)
    return frame, acoustic.astype(float), {k: v.astype(float) for k, v in ssl.items()}, plan, fingerprint


def fit_candidate(spec, x, y, inner, random_state, tree_workers):
    """One isolated worker owns its RNG and warning state throughout a candidate."""
    start = time.perf_counter()
    with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
        warnings.simplefilter('always')
        p = np.full((len(y), 6), np.nan)
        for fi, split in enumerate(inner):
            model = build_model(spec, random_state + fi)
            if spec.family == 'extra_trees':
                model.set_params(model__n_jobs=tree_workers)
            model.fit(x[split.train], y[split.train])
            p[split.test] = aligned_probability(model, x[split.test], 6)
        captured = [{'category': w.category.__name__, 'message': str(w.message)} for w in caught]
        if any(issubclass(w.category, ConvergenceWarning) for w in caught):
            raise RuntimeError('Candidate convergence warning: ' + json.dumps(captured))
    return {'oof': probability_check(p, len(y)).tolist(), 'seconds': time.perf_counter() - start,
            'warning_audit_passed': True, 'warnings': captured, 'training_random_state': random_state}


def historical_selection_check(record, selections):
    rows = selections[selections.held_out_singer.eq(record['held_singer'])]
    if len(rows) != 1:
        raise ValueError('Historical selection identity is not unique')
    old = rows.iloc[0]
    errors = {}
    for branch in ('acoustic', 'ssl'):
        new = record['selection'][branch]
        if new['model'] != old[branch + '_model'] or (branch == 'ssl' and new['representation'] != old['ssl_representation']):
            raise ValueError('Full-search selected model or representation differs from historical baseline')
        for key, tolerance in (('utility', 1e-8), ('temperature', 1e-5)):
            column = branch + ('_inner_utility' if key == 'utility' else '_temperature')
            difference = abs(float(new[key]) - float(old[column]))
            errors[branch + '_' + key] = difference
            if difference > tolerance:
                raise ValueError('Historical selection parameter mismatch: ' + column)
    if record['fusion']['family'] != old.fusion_family:
        raise ValueError('Historical fusion family differs')
    for key, column, tolerance in (('acoustic_weight', 'fusion_acoustic_weight', 1e-12),
                                   ('utility', 'fusion_inner_utility', 1e-8), ('nll', 'fusion_inner_nll', 1e-5)):
        difference = abs(float(record['fusion'][key]) - float(old[column]))
        errors['fusion_' + key] = difference
        if difference > tolerance:
            raise ValueError('Historical fusion selection differs: ' + key)
    return errors


def validate_record(record, fingerprint, seed, fold, plan):
    if record['fingerprint'] != fingerprint or record['seed'] != seed or record['fold'] != fold['fold'] or record['held_singer'] != fold['held_singer']:
        raise ValueError('Stale fold identity')
    if record['clip_ids'] != fold['test']:
        raise ValueError('Changed test identities')
    clips = {c['clip_id']: c for c in plan['clips']}
    if record['labels'] != plan['labels'] or record['y_true'] != [clips[x]['target'] for x in fold['test']]:
        raise ValueError('Cached labels/targets differ from authoritative plan')
    if set(record['selection']) != {'acoustic', 'ssl'}:
        raise ValueError('Missing branch selection evidence')
    for branch, count in (('acoustic', 7), ('ssl', 96)):
        choice = record['selection'][branch]
        if choice['candidate_count'] != count or choice['model'] not in {s.name for s in default_specs(branch)}:
            raise ValueError('Invalid selection model or search coverage')
        if not np.isfinite([choice['utility'], choice['temperature']]).all() or choice['temperature'] <= 0:
            raise ValueError('Invalid calibration/selection parameters')
    fusion = record['fusion']
    if fusion['family'] not in ('arithmetic', 'geometric') or not 0 <= fusion['acoustic_weight'] <= 1:
        raise ValueError('Invalid fusion selection')
    if not np.isfinite([fusion['utility'], fusion['nll']]).all():
        raise ValueError('Invalid fusion selection scores')
    expected = {'acoustic', 'acoustic_calibrated', 'ssl', 'ssl_calibrated', 'late_fusion_calibrated'}
    if set(record['probabilities']) != expected or set(record['metrics']) != expected:
        raise ValueError('Incomplete probability methods')
    for method, raw in record['probabilities'].items():
        p = probability_check(raw, len(fold['test']))
        metrics = classification_metrics(np.asarray(record['y_true']), p, 6)
        if digest(metrics) != digest(record['metrics'][method]):
            raise ValueError('Cached metric does not match probabilities')


def historical_replay_check(record, historical):
    old, old_selection = historical
    selections = historical_selection_check(record, old_selection)
    errors = {}
    for name, raw in record['probabilities'].items():
        p = np.asarray(raw)
        rows = old[old.method.eq(name)].set_index('clip_id').loc[record['clip_ids']]
        old_p = np.stack(rows.probabilities.map(json.loads))
        errors[name] = {'max_probability_error': float(np.abs(old_p - p).max()),
                        'changed_labels': int((old_p.argmax(1) != p.argmax(1)).sum())}
    if any(r['max_probability_error'] > 1e-5 or r['changed_labels'] for r in errors.values()):
        raise ValueError('Full-search historical replay differs')
    return errors, selections


def run_fold(frame, acoustic, ssl, plan, fingerprint, seed, fold, output, workers, pool, historical):
    index = fold['fold']
    dest = output / f'seed_{seed}' / f'fold_{index:02d}.json'
    if dest.exists():
        record = verify(read(dest))
        validate_record(record, fingerprint, seed, fold, plan)
        if seed == SEEDS[0]:
            errors, selections = historical_replay_check(record, historical)
            if record.get('historical_replay') != errors or record.get('historical_selection_replay') != selections:
                raise ValueError('Cached historical parity evidence differs or is missing')
        return record
    if shutil.disk_usage(output).free < 4 * 1024**3:
        raise RuntimeError('Less than4GiB local free space')
    start = time.perf_counter()
    train, test, inner = explicit_splits(frame, fold)
    ids, y = frame.clip_id.to_numpy(), frame.target.to_numpy(dtype=int)
    branch_results, selections = {}, {}
    for branch, values, select_offset, fit_offset in [('acoustic', {'acoustic': acoustic}, 10000, 40000), ('ssl', ssl, 20000, 50000)]:
        specs = default_specs(branch)
        candidates = [(name, x, spec, si) for name, x in values.items() for si, spec in enumerate(specs)]

        def cached_candidate(item):
            name, x, spec, si = item
            path = output / 'candidates' / f'seed_{seed}' / f'fold_{index:02d}' / branch / f'{name}__{spec.name}.json'
            identity = {'fingerprint': fingerprint, 'seed': seed, 'fold': index, 'branch': branch, 'representation': name, 'spec': spec.name}
            if path.exists():
                rec = verify(read(path))
                if any(rec[k] != v for k, v in identity.items()):
                    raise ValueError('Stale candidate')
                if not rec['warning_audit_passed']:
                    raise ValueError('Candidate warnings have not been validated')
                probability_check(rec['oof'], len(train))
                return item, path, identity, rec, None
            else:
                task = (spec, x[train], y[train], inner, seed + select_offset * index + 1000 * si, workers)
                # Trees run sequentially, with a capped internal pool. SSL models use isolated processes.
                if branch == 'acoustic':
                    rec = {**identity, **fit_candidate(*task)}
                    write(path, sign(rec))
                    return item, path, identity, rec, None
                return item, path, identity, None, pool.submit(fit_candidate, *task)

        ranked = []
        batch_size = workers if branch == 'ssl' else 1
        for offset in range(0, len(candidates), batch_size):
            pending = [cached_candidate(c) for c in candidates[offset:offset + batch_size]]
            for item, path, identity, rec, future in pending:
                name, _, spec, _ = item
                if future is not None:
                    rec = {**identity, **future.result()}
                    write(path, sign(rec))
                p = probability_check(rec['oof'], len(train))
                score = selection_utility(classification_metrics(y[train], p, 6))
                print(json.dumps({'event': 'candidate', 'seed': seed, 'fold': index, 'branch': branch, 'representation': name, 'spec': spec.name, 'seconds': round(rec['seconds'], 2)}), flush=True)
                ranked.append((-score, name, spec.name, spec, p))

        with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
            warnings.simplefilter('always')
            chosen = min(ranked, key=lambda row: row[:3])
            neg_utility, name, _, spec, p = chosen
            temp = fit_temperature(y[train], p)
            fitted = build_model(spec, seed + fit_offset * index)
            if spec.family == 'extra_trees':
                fitted.set_params(model__n_jobs=workers)
            fitted.fit(values[name][train], y[train])
            outer = aligned_probability(fitted, values[name][test], 6)
            probability_check(outer, len(test))
            if any(issubclass(w.category, ConvergenceWarning) for w in caught):
                raise RuntimeError('Final-refit convergence warning; result rejected')
        selections[branch] = {'representation': name, 'model': spec.name, 'utility': -neg_utility, 'temperature': float(temp), 'candidate_count': len(candidates)}
        branch_results[branch] = outer
        branch_results[branch + '_calibrated'] = apply_temperature(outer, temp)
        branch_results[branch + '_oof'] = apply_temperature(p, temp)
    choice = select_fusion(y[train], branch_results.pop('acoustic_oof'), branch_results.pop('ssl_oof'), 6)
    branch_results['late_fusion_calibrated'] = fuse_probabilities(branch_results['acoustic_calibrated'], branch_results['ssl_calibrated'], choice.acoustic_weight, choice.family)
    record = {'fingerprint': fingerprint, 'seed': seed, 'fold': index, 'held_singer': fold['held_singer'], 'clip_ids': ids[test].tolist(),
              'labels': plan['labels'], 'y_true': y[test].tolist(), 'selection': selections,
              'fusion': {'family': choice.family, 'acoustic_weight': float(choice.acoustic_weight), 'utility': float(choice.inner_utility), 'nll': float(choice.inner_nll)},
              'probabilities': {k: v.tolist() for k, v in branch_results.items()},
              'metrics': {k: classification_metrics(y[test], v, 6) for k, v in branch_results.items()}, 'seconds': time.perf_counter() - start}
    if seed == SEEDS[0]:
        try:
            errors, selections = historical_replay_check(record, historical)
            record['historical_replay'] = errors
            record['historical_selection_replay'] = selections
        except ValueError:
            write(output / f'baseline_discrepancy_{index:02d}.json', record)
            raise
    validate_record(record, fingerprint, seed, fold, plan)
    write(dest, sign(record))
    print(json.dumps({'event': 'fold_complete', 'seed': seed, 'fold': index, 'seconds': round(record['seconds'], 2)}), flush=True)
    return record


def execute(args):
    if (args.output / 'failure.json').exists():
        raise RuntimeError('Previous failure requires investigation; no automatic restart')
    frame, acoustic, ssl, plan, fingerprint = prepare(args.data, args.output, args.workers)
    print(json.dumps({'event': 'preflight_passed', 'fingerprint': fingerprint, 'features': len(ssl), 'workers': args.workers}), flush=True)
    jobs = [(seed, fold) for seed in SEEDS for fold in plan['folds']][:args.max_jobs]
    old = args.data / 'results/nested_loso_full_checkpointed_20260824/production_shared_6'
    historical = (pd.read_csv(old / 'outer_predictions.csv'), pd.read_csv(old / 'inner_selections.csv'))
    try:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            for seed, fold in jobs:
                run_fold(frame, acoustic, ssl, plan, fingerprint, seed, fold, args.output, args.workers, pool, historical)
        completed = []
        for seed, fold in jobs:
            path = args.output / f'seed_{seed}' / f"fold_{fold['fold']:02d}.json"
            record = verify(read(path))
            validate_record(record, fingerprint, seed, fold, plan)
            completed.append({'seed': seed, 'fold': fold['fold'], 'sha256': sha(path)})
        write(args.output / 'completion.json', {'fingerprint': fingerprint, 'completed_jobs': len(completed),
              'required_jobs': 60, 'complete': len(completed) == 60, 'results': completed})
    except Exception as error:
        write(args.output / 'failure.json', {'error': type(error).__name__ + ': ' + str(error), 'time_unix': time.time()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=DATA)
    parser.add_argument('--output', type=Path, default=HERE / 'results_v2')
    parser.add_argument('--workers', type=int, default=3)
    parser.add_argument('--max-jobs', type=int, default=1)
    args = parser.parse_args()
    args.output = args.output.resolve()
    if not 1 <= args.workers <= 3 or not 1 <= args.max_jobs <= 60:
        raise ValueError('Bounded local resources required')
    # The protected entry point sets this only after joining the supervisor job.
    inherited = os.environ.get('CSL_LOCAL_PROTECTED_OUTPUT') == str(args.output)
    with nullcontext() if inherited else OutputLease(args.output):
        previous = args.output / 'supervision.json'
        if not inherited and previous.exists() and read(previous)['state'] == 'running':
            raise RuntimeError('Unclosed previous supervision needs explicit investigation')
        execute(args)


if __name__ == '__main__':
    main()
