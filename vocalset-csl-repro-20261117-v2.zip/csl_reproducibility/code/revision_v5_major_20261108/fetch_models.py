"""Explicit model download step. Never connects to or starts a cloud instance."""
import argparse
import fnmatch
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

from common import ROOT, PROJECT, digest, file_hash, read_json, write_json


def curl_snapshot(repo, revision, patterns, target, ranged=False):
    from huggingface_hub import HfApi
    info = HfApi(token=False).model_info(repo, revision=revision, files_metadata=True)
    if info.sha != revision:
        raise ValueError("Hub metadata did not resolve the pinned revision")
    target.mkdir(parents=True, exist_ok=True)
    for blob in info.siblings:
        if not any(fnmatch.fnmatch(blob.rfilename,p) for p in patterns):
            continue
        dest = target/blob.rfilename
        expected = blob.lfs.sha256 if blob.lfs else None
        def valid(path):
            if not path.is_file() or path.stat().st_size != blob.size:
                return False
            if expected:
                return file_hash(path)==expected
            data = path.read_bytes()
            return hashlib.sha1(f"blob {len(data)}\0".encode()+data).hexdigest()==blob.blob_id
        if valid(dest):
            continue
        temp = dest.with_suffix(dest.suffix+".curl-part")
        temp.parent.mkdir(parents=True,exist_ok=True)
        url = f"https://huggingface.co/{repo}/resolve/{revision}/{blob.rfilename}"
        if ranged and blob.size > 32*1024*1024:
            sys.path.insert(0,str(PROJECT/"scripts"))
            from download_segmented import download_range
            pieces = [(i,min(i+16*1024*1024-1,blob.size-1))
                      for i in range(0,blob.size,16*1024*1024)]
            directory = dest.with_suffix(dest.suffix+".ranges")
            def job(bounds):
                left,right = bounds
                path = directory/f"{left}_{right}.part"
                download_range(url+f"?range_start={left}",path,left,right,retries=3,timeout=45)
                return path
            with ThreadPoolExecutor(max_workers=4) as pool:
                paths = list(pool.map(job,pieces))
            with temp.open("wb") as out:
                for path in paths:
                    with path.open("rb") as src:
                        shutil.copyfileobj(src,out,length=1024*1024)
        else:
            subprocess.run(["curl.exe" if os.name=="nt" else "curl", "--fail", "--location", "--silent", "--show-error",
                            "--connect-timeout","15","--max-time","900","--speed-limit","1024","--speed-time","45",
                            "--retry","2","--output",str(temp),url+"?download=true"],check=True)
        if not valid(temp):
            raise ValueError(f"Downloaded bytes do not match Hub size/content hash: {blob.rfilename}")
        temp.replace(dest)
        print(f"Verified {blob.rfilename} ({blob.size} bytes)",flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", choices=["music2vec", "wavlm", "muq", "musicfm"], required=True)
    parser.add_argument("--reuse-cache", type=Path, help="Reuse an already downloaded exact snapshot without network")
    parser.add_argument("--curl", action="store_true", help="Use curl and verify the Hub LFS/Git hashes")
    parser.add_argument("--ranges",action="store_true",help="With --curl, reuse the existing resumable range downloader for large files")
    args = parser.parse_args()
    from huggingface_hub import snapshot_download
    cfg = read_json(ROOT / "protocol.json")["models"][args.model]
    target = args.output / args.model
    if (target / "revision_lock.json").exists():
        lock = read_json(target / "revision_lock.json")
        if lock["config"] != cfg:
            raise RuntimeError("Existing model lock differs")
    patterns = ["config.json", "preprocessor_config.json", "*.safetensors", "pytorch_model.bin"]
    if args.model == "musicfm":
        patterns = ["msd_stats.json", "pretrained_msd.pt"]
    if args.reuse_cache:
        source = Path(snapshot_download(cfg["id"], revision=cfg["revision"],
                                       cache_dir=args.reuse_cache, local_files_only=True))
        target.mkdir(parents=True, exist_ok=True)
        for path in source.iterdir():
            if not any(fnmatch.fnmatch(path.name, pattern) for pattern in patterns):
                continue
            dest = target / path.name
            if dest.exists():
                if file_hash(dest) != file_hash(path):
                    raise ValueError("Existing model file differs from the pinned cache")
                continue
            try:
                os.link(path.resolve(), dest)
            except OSError:
                shutil.copy2(path, dest)
    elif args.curl:
        curl_snapshot(cfg["id"], cfg["revision"], patterns, target,args.ranges)
    else:
        snapshot_download(cfg["id"], revision=cfg["revision"], allow_patterns=patterns, local_dir=target)
    if args.model == "musicfm":
        if args.curl:
            curl_snapshot(cfg["config_id"],cfg["config_revision"],["config.json"],target/"conformer_config")
        else:
            snapshot_download(cfg["config_id"], revision=cfg["config_revision"],
                              allow_patterns=["config.json"], local_dir=target / "conformer_config")
    files = {p.relative_to(target).as_posix(): file_hash(p) for p in target.rglob("*")
             if p.is_file() and ".cache" not in p.parts and p.name != "revision_lock.json"
             and not any(part.endswith(".ranges") for part in p.parts)
             and not p.name.endswith((".part",".curl-part"))}
    write_json(target / "revision_lock.json", {"config": cfg, "config_hash": digest(cfg), "files": files})
    print(f"Prepared pinned snapshot: {args.model}")


if __name__ == "__main__":
    main()
