"""Collect complete, comparable outer predictions; never mix smoke or partial folds."""
import argparse
from pathlib import Path

import numpy as np

from common import digest, load_plan, read_json, write_json
from vocalset_csl.metrics import classification_metrics


def collect(plan, paths):
    methods = {}
    for path in paths:
        if "smoke" in path.parts:
            raise ValueError("Smoke results are not publishable")
        r = read_json(path)
        if r["plan_fingerprint"] != plan["fingerprint"]:
            raise ValueError("Mixed evaluation plans")
        fold = plan["folds"][r["fold"]]
        if r["clip_ids"] != fold["test"] or r["labels"] != plan["labels"] or r["held_singer"] != fold["held_singer"]:
            raise ValueError("Fold, label or recording identity mismatch")
        method = methods.setdefault(r["method"], {})
        if r["fold"] in method:
            raise ValueError("Duplicate fold result")
        method[r["fold"]] = r
    if not methods:
        raise ValueError("No formal results exist")
    output = {}
    targets = {r["clip_id"]:r["target"] for r in plan["clips"]}
    ids = [r["clip_id"] for r in plan["clips"]]
    for name, folds in methods.items():
        if set(folds) != set(range(len(plan["folds"]))):
            raise ValueError(f"Incomplete LOSO result: {name}")
        if len({digest(r["source_hashes"]) for r in folds.values()}) != 1:
            raise ValueError("Source changed across folds")
        if len({digest(r["environment"]) for r in folds.values()}) != 1:
            raise ValueError("Environment changed across folds")
        by_id = {}
        singer_metrics = {}
        for record in folds.values():
            true = [targets[i] for i in record["clip_ids"]]
            if true != record["y_true"]:
                raise ValueError("Target alignment mismatch")
            prob = np.array(record["probabilities"],dtype=float)
            if not np.isfinite(prob).all() or (prob<0).any() or not np.allclose(prob.sum(1),1,atol=1e-5):
                raise ValueError("Invalid probability matrix")
            by_id.update(zip(record["clip_ids"],prob))
            singer_metrics[record["held_singer"]] = classification_metrics(np.array(true),prob,len(plan["labels"]))
        probabilities = np.stack([by_id[i] for i in ids])
        output[name] = {"pooled":classification_metrics(np.array([targets[i] for i in ids]), probabilities, len(plan["labels"])),
                        "singer_metrics":singer_metrics, "clip_ids":ids,
                        "probabilities":probabilities.tolist()}
    return {"plan_fingerprint":plan["fingerprint"],"methods":output,
            "note":"Paired singer-level inference and prespecified multiplicity families are required before manuscript claims."}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--plan",type=Path,required=True)
    p.add_argument("--results",type=Path,required=True)
    p.add_argument("--output",type=Path,required=True)
    args = p.parse_args()
    paths = [path for group in ("yamamoto","zhou") for path in (args.results/group).rglob("result.json")]
    write_json(args.output,collect(load_plan(args.plan),paths))


if __name__ == "__main__":
    main()
