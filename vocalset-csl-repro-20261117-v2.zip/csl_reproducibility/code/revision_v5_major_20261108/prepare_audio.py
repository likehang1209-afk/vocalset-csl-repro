"""Create a separate, hash-bound three-second audio cache without a GPU."""
from __future__ import annotations

import argparse
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

from common import digest, environment, file_hash, load_plan, write_json


def segment_bounds(samples, sample_rate, seconds):
    width = round(sample_rate * seconds)
    if samples <= 0:
        raise ValueError("Empty audio after trimming")
    return [(start, min(start + width, samples))
            for start in range(0, max(width, (samples // width) * width), width)]


def inspect_audio(plan, audio_root):
    cfg = plan["protocol"]["audio"]
    segments = []
    for index, row in enumerate(plan["clips"]):
        path = audio_root / row["relative_path"]
        if file_hash(path) != row["content_sha256"]:
            raise ValueError(f"Audio hash mismatch: {path}")
        audio, sr = sf.read(path, dtype="float32", always_2d=True)
        audio = audio.mean(axis=1)
        if not np.isfinite(audio).all() or not np.any(audio):
            raise ValueError(f"Invalid or silent audio: {path}")
        _, (begin, end) = librosa.effects.trim(audio, top_db=cfg["trim_top_db"],
            frame_length=cfg["trim_frame_length"], hop_length=cfg["trim_hop_length"])
        for part, (left, right) in enumerate(segment_bounds(int(end-begin), sr, cfg["seconds"])):
            segments.append({"segment_id": f"{row['clip_id']}_{part:03d}",
                             "clip_id": row["clip_id"], "singer_id": row["singer_id"],
                             "target": row["target"], "relative_path": row["relative_path"],
                             "source_sr": sr, "start": int(begin+left), "stop": int(begin+right),
                             "valid_seconds": (right-left)/sr})
        if index % 100 == 0:
            print(f"Audited {index+1}/{len(plan['clips'])} recordings", flush=True)
    return segments


def pack_audio(plan, audio_root, output):
    if output.exists():
        raise FileExistsError("Use a fresh cache directory; partial caches are never accepted")
    output.mkdir(parents=True)
    segments = inspect_audio(plan, audio_root)
    cfg = plan["protocol"]["audio"]
    arrays = {sr: np.lib.format.open_memmap(output / f"waveforms_{sr}.npy", mode="w+",
              dtype="float32", shape=(len(segments), round(sr*cfg["seconds"])))
              for sr in cfg["sample_rates"]}
    last = None
    for i, segment in enumerate(segments):
        if last != segment["relative_path"]:
            audio, sr = sf.read(audio_root / segment["relative_path"], dtype="float32", always_2d=True)
            audio = audio.mean(axis=1)
            last = segment["relative_path"]
        original = audio[segment["start"]:segment["stop"]]
        for target, arr in arrays.items():
            samples = librosa.resample(original, orig_sr=sr, target_sr=target, res_type=cfg["resample_type"])
            valid = min(len(samples), arr.shape[1])
            arr[i] = 0
            arr[i, :valid] = samples[:valid]
            segment[f"valid_{target}"] = valid
    files = {}
    for sr, arr in arrays.items():
        arr.flush()
        path = output / f"waveforms_{sr}.npy"
        files[path.name] = file_hash(path)
    meta = {"plan_fingerprint": plan["fingerprint"], "protocol_hash": digest(plan["protocol"]),
            "segments": segments, "files": files, "environment": environment(),
            "short_padded_segments": sum(r["valid_seconds"] < cfg["seconds"] for r in segments)}
    meta["fingerprint"] = digest(meta)
    write_json(output / "segments.json", meta)
    print(f"Prepared {len(segments)} segments; {meta['short_padded_segments']} short segments padded", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--audio-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    pack_audio(load_plan(args.plan), args.audio_root, args.output)


if __name__ == "__main__":
    main()
