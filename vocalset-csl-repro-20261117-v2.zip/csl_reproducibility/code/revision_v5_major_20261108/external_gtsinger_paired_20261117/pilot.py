"""Restore the one declared model pair and score sealed GTSinger utterances."""
from collections import Counter
import csv
from io import StringIO
import json
from pathlib import Path
import sys
import warnings

from common import (ANCHOR, AUDIODIR, CONTRASTS, DATA, DATA_HOME, HEADS, HERE, METHODS,
                    PAIRS, PROTOCOL, RESULTS, REV, ROOT, file_hash, load, pairs_locked,
                    save_new, stamp, write_new)
from paired_data import clip_name

SOURCE_PLAN = REV / "artifacts/plan.json"
SOURCE_CONFIG = ROOT / "configs/protocol_v2.json"
ACOUSTIC_FILE = "features/acoustic_egemaps_singing.npz"
SSL_DIR = DATA / "embeddings/muq_large"
VENDOR = ROOT / "revision_v4_major_20260922/replay_vendor_sklearn172"
SUPPLEMENT = REV / "writing/round10_evidence_closure_20261117/delivery_v1"


def local_stack(use_vendor=False):
    if use_vendor:
        sys.path.insert(0, str(VENDOR))
    sys.path.insert(0, str(ROOT / "src"))


def check_resources(minimum=1.0):
    sys.path.insert(0, str(ANCHOR))
    from supervise import GiB, memory_available
    if memory_available() < minimum * GiB:
        raise RuntimeError(f"Available memory below {minimum} GiB")


def source_paths():
    p = load(PROTOCOL)
    return (p, RESULTS / f"seed_{p['source_seed']}/fold_{p['source_fold']:02d}.json")


def verify_source():
    p, path = source_paths()
    record = load(path)
    audit_path = RESULTS / "full_lineage_audit.json"
    audit = load(audit_path)
    lock_path = RESULTS / "run_lock.json"
    lock = load(lock_path)
    expected_sha = [r["sha256"] for r in audit["results"]
                    if (r["seed"], r["fold"]) == (p["source_seed"], p["source_fold"])]
    if (not audit["all_60_verified"] or not audit["independent_metric_replay"]
            or expected_sha != [file_hash(path)]
            or len({audit["fingerprint"], lock["fingerprint"], record["fingerprint"]}) != 1):
        raise ValueError("Source fold is not the declared audited fold")
    used_data = ["manifest.csv", ACOUSTIC_FILE, "embeddings/muq_large/metadata.json",
                 "embeddings/muq_large/clip_ids.npy", "embeddings/muq_large/status.npy",
                 "embeddings/muq_large/layer_12.npy"]
    used_code = [SOURCE_PLAN, SOURCE_CONFIG, ANCHOR / "run.py",
                 *sorted((ROOT / "src/vocalset_csl").glob("*.py"))]
    file_hashes = {str(f): file_hash(f) for f in (path, lock_path, audit_path)}
    for directory, mapping, keys in (
        (DATA, lock["data"], used_data),
        (ROOT, lock["sources"], [f.relative_to(ROOT).as_posix() for f in used_code]),
    ):
        for key in keys:
            f = directory / key
            digest = file_hash(f)
            if mapping[key] != digest:
                raise ValueError(f"Source is not byte-identical to original lock: {f}")
            file_hashes[str(f)] = digest
    return p, record, lock, file_hashes


def restore():
    pairs_locked()
    local_stack(use_vendor=True)
    import joblib
    import numpy as np
    import pandas as pd
    import scipy
    import sklearn
    from sklearn.exceptions import ConvergenceWarning
    from threadpoolctl import threadpool_limits
    from vocalset_csl.calibration import apply_temperature
    from vocalset_csl.feature_io import align_feature_rows, exclude_named_features, load_feature_npz
    from vocalset_csl.fusion import fuse_probabilities
    from vocalset_csl.modeling import aligned_probability, build_model, find_default_spec
    from vocalset_csl.representation_io import load_embedding_store
    from vocalset_csl.splitting import assert_group_disjoint
    from vocalset_csl.tasks import select_task

    p, record, lock, hashes = verify_source()
    versions = {k: v.__version__ for k, v in (("numpy", np), ("pandas", pd), ("scipy", scipy), ("sklearn", sklearn))}
    if versions != lock["versions"]:
        raise ValueError(f"Original scientific library versions differ: {versions}")
    config, plan = load(SOURCE_CONFIG), load(SOURCE_PLAN)
    if (record["seed"], record["fold"]) != (p["source_seed"], p["source_fold"]):
        raise ValueError("Unexpected fold ID")
    f, labels = select_task(pd.read_csv(DATA / "manifest.csv"), config, "production_shared_6")
    ids = f.clip_id.to_numpy()
    if list(ids) != [c["clip_id"] for c in plan["clips"]] or labels != record["labels"] or len(labels) != 6:
        raise ValueError("Original source cohort order or labels differ")
    fold = plan["folds"][p["source_fold"]]
    if fold["fold"] != p["source_fold"] or fold["test"] != record["clip_ids"]:
        raise ValueError("Held-out recording IDs do not match")
    pos = {c: i for i, c in enumerate(ids)}
    train, test = (np.asarray([pos[c] for c in fold[key]], dtype=int) for key in ("train", "test"))
    y = f.target.to_numpy()
    singers = f.singer_id.to_numpy()
    assert_group_disjoint(train, test, singers)
    if list(y[test]) != record["y_true"] or set(singers[test]) != {record["held_singer"]}:
        raise ValueError("Held-out labels or singer differ")
    feat = load_feature_npz(DATA / ACOUSTIC_FILE)
    acoustic, names = exclude_named_features(align_feature_rows(ids, feat["clip_ids"], feat["values"]),
                                             feat["feature_names"], ["duration_seconds"])
    ssl, ssl_meta = load_embedding_store(SSL_DIR, ids, [1.0])
    if (len(names) != 183 or set(ssl) != {"depth_1.00_layer_12"}
            or record["selection"]["ssl"]["representation"] != "muq_large__depth_1.00_layer_12"):
        raise ValueError("Source representation differs")
    matrices = {"acoustic": acoustic.astype(float), "ssl": ssl["depth_1.00_layer_12"].astype(float)}
    models = {}
    replay = {}
    predicted = {}
    config_receipt = {}

    def verify(key, arr):
        desired = np.asarray(record["probabilities"][key], dtype=float)
        max_dev = float(np.max(np.abs(arr - desired)))
        if (not np.isfinite(arr).all() or max_dev > p["source_replay_max_abs_difference"]
                or not np.array_equal(arr.argmax(1), desired.argmax(1))):
            raise ValueError(f"Restored {key} differs from archived probabilities: {max_dev}")
        replay[key] = max_dev

    for branch, offset in (("acoustic", 40000), ("ssl", 50000)):
        check_resources(2.0)
        selection = record["selection"][branch]
        spec = find_default_spec(branch, selection["model"])
        seed = p["source_seed"] + offset * p["source_fold"]
        model = build_model(spec, seed)
        if spec.family == "extra_trees":
            model.set_params(model__n_jobs=1)
        with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
            warnings.simplefilter("always")
            model.fit(matrices[branch][train], y[train])
            raw = aligned_probability(model, matrices[branch][test], 6)
        if any(issubclass(w.category, ConvergenceWarning) for w in caught):
            raise RuntimeError(f"Convergence warning while restoring {branch}")
        verify(branch, raw)
        predicted[branch] = apply_temperature(raw, selection["temperature"])
        verify(branch + "_calibrated", predicted[branch])
        models[branch] = model
        config_receipt[branch] = {**selection, "fit_seed": seed, "parameters": spec.as_dict(),
                                  "warnings": [str(w.message) for w in caught]}
        print(f"Restored {branch} only, original probability replay max deviation {replay[branch]:.3g}", flush=True)
    fusion = record["fusion"]
    verify("late_fusion_calibrated", fuse_probabilities(predicted["acoustic"], predicted["ssl"],
                                                       fusion["acoustic_weight"], fusion["family"]))
    HEADS.mkdir(exist_ok=True)
    head_hashes = {}
    for branch, model in models.items():
        model_file = HEADS / f"{branch}.joblib"
        with model_file.open("xb") as out:
            joblib.dump(model, out)
        head_hashes[branch] = file_hash(model_file)
    save_new(HEADS / "receipt.json", {
        "created_utc": stamp(), "source": str(source_paths()[1]), "original_inputs": hashes,
        "seed": p["source_seed"], "fold": p["source_fold"], "held_singer": record["held_singer"],
        "n_train": len(train), "n_replayed": len(test), "fit_count": 2,
        "all_original_argmax_unchanged": True, "replay_max_abs_difference": replay,
        "num_original_inner_or_search_fits": 0, "base_model_fits": 0, "labels": labels,
        "fit_config": config_receipt, "fusion": fusion, "acoustic_names": names,
        "ssl_metadata": ssl_meta, "versions": versions, "head_sha256": head_hashes,
    })


def input_audio():
    pairs = pairs_locked()
    receipt = load(HERE / "audio_receipt.json")
    entries = receipt["clips"]
    expected = [clip_name(pair, role) for pair in pairs for role in ("technique", "control")]
    if (receipt["pairs_sha256"] != file_hash(PAIRS) or [r["file"] for r in entries] != expected
            or {p.name for p in AUDIODIR.glob("*.wav")} != set(expected)):
        raise ValueError("Audio directory does not match frozen list")
    paths = [AUDIODIR / name for name in expected]
    for path, row in zip(paths, entries):
        if row["sha256"] != file_hash(path):
            raise ValueError(f"External audio changed: {path}")
    return paths


def features_save(branch, paths, values, details):
    import numpy as np
    target = HERE / f"{branch}_features.npz"
    with target.open("xb") as stream:
        np.savez_compressed(stream, names=[p.name for p in paths], matrix=np.stack(values))
    save_new(HERE / f"{branch}_features.json", {"feature_sha256": file_hash(target),
                                               "entries": len(values), **details})


def acoustic():
    paths = input_audio()
    names = load(HEADS / "receipt.json")["acoustic_names"]
    local_stack()
    import librosa
    import numpy as np
    import opensmile
    from vocalset_csl.audio_features import extract_interpretable_features
    from vocalset_csl.feature_io import exclude_named_features

    values = []
    for i, f in enumerate(paths, 1):
        check_resources()
        a = extract_interpretable_features(f)
        vector, ordered = exclude_named_features(a.values[np.newaxis, :], a.names, ["duration_seconds"])
        if ordered != names or np.isinf(vector).any():
            raise ValueError(f"Unexpected acoustic feature schema at {f.name}")
        values.append(vector[0])
        print(f"Acoustic {i}/{len(paths)} {f.name}", flush=True)
    features_save("acoustic", paths, values, {"librosa": librosa.__version__, "opensmile": opensmile.__version__,
                                             "dimension": len(names), "duration_omitted": True})


def ssl():
    paths = input_audio()
    local_stack()
    import importlib.metadata
    import librosa
    import numpy as np
    import soundfile as sf
    import torch
    from vocalset_csl.ssl_extraction import build_backend, window_audio

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    if torch.version.cuda is not None:
        raise ValueError("Expected the installed CPU-only PyTorch build")
    meta = load(HEADS / "receipt.json")["ssl_metadata"]
    config = load(SOURCE_CONFIG)["ssl_models"]["muq_large"]
    rate, win, hop = meta["sample_rate"], meta["window_seconds"], meta["hop_seconds"]
    if (meta["model_id"], meta["model_revision"], rate, win, hop) != (
            config["model_id"], config["revision"], config["sample_rate"], 5.0, 2.5):
        raise ValueError("Original MuQ extraction configuration differs")
    snapshot = DATA_HOME / f"hf_cache_local/hub/models--OpenMuQ--MuQ-large-msd-iter/snapshots/{meta['model_revision']}"
    model_files = [snapshot / name for name in ("config.json", "model.safetensors")]
    if not all(f.is_file() for f in model_files):
        raise FileNotFoundError("Original pinned local MuQ snapshot is unavailable")
    model_hashes = {str(f): file_hash(f) for f in model_files}
    print("Loading pinned MuQ locally (CPU/fp32)", flush=True)
    backend = build_backend("muq", str(snapshot), meta["model_revision"], rate, "cpu", "fp32")
    first_param = next(backend.model.parameters())
    if first_param.device.type != "cpu" or first_param.dtype != torch.float32 or backend.model.training:
        raise ValueError("MuQ must be in fp32 CPU evaluation mode")
    batch = load(PROTOCOL)["ssl_window_batch_size"]
    layer = meta["selected_layers"][0]
    values = []
    for i, f in enumerate(paths, 1):
        check_resources()
        audio, sr = sf.read(f, dtype="float32", always_2d=False)
        if audio.ndim == 2:
            audio = audio.mean(axis=1)
        if sr != rate:
            audio = librosa.resample(audio, orig_sr=sr, target_sr=rate)
        windows, lengths = window_audio(audio, rate, win, hop)
        vector = backend.extract(windows, lengths, batch)[layer["layer_index"]]
        if vector.shape != (layer["dimension"],) or not np.isfinite(vector).all():
            raise ValueError(f"Invalid MuQ vector at {f.name}")
        values.append(vector)
        print(f"SSL {i}/{len(paths)} {f.name}, {len(windows)} windows", flush=True)
    features_save("ssl", paths, values, {"device": "cpu", "precision": "fp32",
                 "torch": torch.__version__, "muq": importlib.metadata.version("muq"),
                 "revision": meta["model_revision"], "model_sha256": model_hashes,
                 "librosa": librosa.__version__, "audio_seconds_per_window": win, "hop_seconds": hop,
                 "window_batch_size": batch, **layer})


def sign_rank(delta, tolerance):
    return "correct" if delta > tolerance else "reversed" if delta < -tolerance else "tie"


def score_pairs(pairs, probabilities, labels, tolerance):
    rows = []
    for pair in pairs:
        row = {k: pair[k] for k in ("pair_id", "singer", "technique", "song", "segment")}
        i = labels.index(pair["technique"])
        pos = probabilities[clip_name(pair, "technique")]
        neg = probabilities[clip_name(pair, "control")]
        for method in METHODS:
            p, n = float(pos[method][i]), float(neg[method][i])
            row.update({method + "_technique": p, method + "_control": n, method + "_delta": p - n,
                        method + "_rank": sign_rank(p - n, tolerance)})
        rows.append(row)
    return rows


def summarize(rows):
    methods = {}
    contrasts = {}
    for method in METHODS:
        counts = Counter(row[method + "_rank"] for row in rows)
        methods[method] = {k: counts[k] for k in ("correct", "reversed", "tie")}
    for new, old in CONTRASTS:
        outcome = Counter((row[old + "_rank"] == "correct", row[new + "_rank"] == "correct") for row in rows)
        corrections, harms = outcome[False, True], outcome[True, False]
        if methods[new]["correct"] - methods[old]["correct"] != corrections - harms:
            raise AssertionError("Paired transitions do not reconstruct counts")
        contrasts[f"{new}_vs_{old}"] = {
            "corrections": corrections, "new_errors": harms, "net": corrections - harms,
            "both_correct": outcome[True, True], "neither_correct": outcome[False, False],
        }
    joint = {name: {"pairs": 0, "correct_after_fusion": 0}
             for name in ("both_correct", "acoustic_only", "ssl_only", "neither_correct")}
    key = {(True, True): "both_correct", (True, False): "acoustic_only",
           (False, True): "ssl_only", (False, False): "neither_correct"}
    for row in rows:
        cell = joint[key[row["acoustic_rank"] == "correct", row["ssl_rank"] == "correct"]]
        cell["pairs"] += 1
        cell["correct_after_fusion"] += row["fusion_rank"] == "correct"
    return {"pairs": len(rows), "methods": methods, "contrasts": contrasts, "branch_joint": joint}


def analysis():
    pairs = pairs_locked()
    paths = input_audio()
    local_stack(use_vendor=True)
    import joblib
    import numpy as np
    from threadpoolctl import threadpool_limits
    from vocalset_csl.calibration import apply_temperature
    from vocalset_csl.fusion import fuse_probabilities
    from vocalset_csl.modeling import aligned_probability

    source = load(HEADS / "receipt.json")
    p = load(PROTOCOL)
    labels = source["labels"]
    out, raw = {}, {}
    for branch in ("acoustic", "ssl"):
        feature_path = HERE / f"{branch}_features.npz"
        head_path = HEADS / f"{branch}.joblib"
        if (file_hash(feature_path) != load(HERE / f"{branch}_features.json")["feature_sha256"]
                or file_hash(head_path) != source["head_sha256"][branch]):
            raise ValueError(f"{branch} artifact changed after creation")
        with np.load(feature_path, allow_pickle=False) as features:
            if list(features["names"]) != [f.name for f in paths]:
                raise ValueError("Feature recording order differs")
            with threadpool_limits(limits=1):
                model = joblib.load(head_path)
                raw[branch] = aligned_probability(model, features["matrix"].astype(float), len(labels))
        out[branch] = apply_temperature(raw[branch], source["fit_config"][branch]["temperature"])
    out["fusion"] = fuse_probabilities(out["acoustic"], out["ssl"],
                                        source["fusion"]["acoustic_weight"], source["fusion"]["family"])
    for a in (*out.values(), *raw.values()):
        if (a.shape != (len(paths), len(labels)) or not np.isfinite(a).all()
                or np.any(a < 0) or not np.allclose(a.sum(1), 1, atol=1e-9, rtol=0)):
            raise ValueError("Invalid external six-class probabilities")
    probabilities = {f.name: {k: out[k][i].tolist() for k in METHODS} for i, f in enumerate(paths)}
    save_new(HERE / "clip_probabilities.json", {"classes": labels, "probabilities": probabilities,
             "raw_branches": {f.name: {k: raw[k][i].tolist() for k in raw} for i, f in enumerate(paths)}})
    rows = score_pairs(pairs, probabilities, labels, p["tie_abs_probability_difference"])
    buffer = StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    write_new(HERE / "paired_results.csv", buffer.getvalue().encode("utf-8-sig"))
    summary = {"scope": "exploratory paired target ranking only", "overall": summarize(rows),
               "by_singer": {s: summarize([r for r in rows if r["singer"] == s]) for s in p["singers"]},
               "by_technique": {t: summarize([r for r in rows if r["technique"] == t]) for t in p["techniques"]},
               "by_singer_technique": {s: {t: summarize([r for r in rows if r["singer"] == s and r["technique"] == t])
                                            for t in p["techniques"]} for s in p["singers"]}}
    save_new(HERE / "summary.json", summary)
    print(json.dumps(summary["overall"], indent=2), flush=True)


def audit():
    from audit_results import run_audit
    run_audit()
