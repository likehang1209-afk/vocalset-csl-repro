"""Fast tests using invented annotation rows and probability differences only."""
import unittest

from common import PROTOCOL, load
from paired_data import annotation, select_pairs
from pilot import score_pairs, sign_rank, summarize


def item(role, song="test song", segment="0001", flags=(0, 1), word="test"):
    fields = ("English", "EN-Alto-1", "Breathy", song, role, segment)
    return {"language": "English", "singer": "EN-Alto-1", "item_name": "#".join(fields),
            "wav_fn": "/".join(fields) + ".wav", "txt": ["<SP>", word],
            "ph": ["<SP>", "T_en"], "ph_durs": [1.0, 2.0], "breathy_tech": flags}


class PilotTests(unittest.TestCase):
    def setUp(self):
        self.p = load(PROTOCOL)
        self.t = item("Breathy_Group")
        self.c = item("Control_Group", flags=(0, 0), word="TEST")

    def test_matches_canonical_song_segment_not_case_or_pause(self):
        pairs, cells = select_pairs([self.c, self.t], self.p)
        self.assertEqual(len(pairs), 1)
        self.assertEqual(cells[0]["eligible"], 1)
        self.assertEqual(pairs[0]["clips"]["technique"]["target_seconds"], 2.0)

    def test_reject_marked_control_and_mismatched_lyric(self):
        for change in ({"breathy_tech": (0, 1)}, {"txt": ["different"]}, {"breathy_tech": (0,)}):
            with self.subTest(change=change):
                selected, _ = select_pairs([self.t, {**self.c, **change}], self.p)
                self.assertEqual(selected, [])

    def test_missing_phoneme_annotation_is_not_zero(self):
        with self.assertRaises(KeyError):
            annotation(self.c, "vibrato")

    def test_one_pair_per_song_and_order_invariant(self):
        rows = [item(role, song, seg, flags=f) for song in ("s1", "s2") for seg in ("0001", "0002")
                for role, f in (("Control_Group", (0, 0)), ("Breathy_Group", (0, 1)))]
        pairs_a, _ = select_pairs(rows, self.p)
        pairs_b, _ = select_pairs(list(reversed(rows)), self.p)
        self.assertEqual(pairs_a, pairs_b)
        self.assertEqual(len(pairs_a), 2)

    def test_duplicates_fail(self):
        with self.assertRaises(ValueError):
            select_pairs([self.t, self.t, self.c], self.p)

    def test_sign_rank_including_tie_boundary(self):
        self.assertEqual([sign_rank(x, 1e-12) for x in (0.1, -0.1, -1e-12, 0, 1e-12)],
                         ["correct", "reversed", "tie", "tie", "tie"])

    def test_score_and_transition_counts(self):
        pair, = select_pairs([self.t, self.c], self.p)[0]
        probabilities = {
            "P01_technique.wav": {"acoustic": [.6, .4], "ssl": [.7, .3], "fusion": [.6, .4]},
            "P01_control.wav": {"acoustic": [.8, .2], "ssl": [.7, .3], "fusion": [.7, .3]}
        }
        scores = score_pairs([pair], probabilities, ["belt", "breathy"], 1e-12)
        result = summarize(scores)
        self.assertEqual(result["contrasts"]["fusion_vs_ssl"]["corrections"], 1)
        loss = [{**scores[0], "ssl_rank": "correct", "fusion_rank": "reversed"}]
        self.assertEqual(summarize(loss)["contrasts"]["fusion_vs_ssl"]["new_errors"], 1)


if __name__ == "__main__":
    unittest.main()
