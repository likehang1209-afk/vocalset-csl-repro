# GTSinger paired transfer pilot

Locked before audio download or evaluation. The goal is to see whether
corrections and newly introduced ranking errors coexist on songs recorded
outside VocalSet, not to optimize a new method.

## Sampling

- Use the pinned official release and only the three listed English singer
  IDs and the Breathy and Vibrato categories. Read non-audio annotations
  first. Match singer, song, segment number and case-folded lyric tokens
  after removing annotation tokens in angle brackets.
- For both versions, annotated duration must be 2-20 s. The technique
  rendition must have at least 0.5 s of non-silence phonemes explicitly
  marked for the target; the control's target flags must all be zero.
  Pairs with absent or malformed labels are ineligible. The natural
  rendition is not assumed to be straight tone or free of other techniques.
- In each singer-technique cell, order eligible pairs by SHA-256 of the
  protocol ID and the singer, technique, song and segment ID. Use the first
  eligible pair from each of up to four distinct songs. Report shortfalls
  without replacement or switch to a different data source. Freeze the
  exact list before fetching WAVs. Fetch only the designated files.
- The recordings remain the dataset's original utterances. Do not normalize
  one rendition against the other, add labels, or crop based on model output.
  Keep exact-byte hashes, source URLs and annotation coverage. Other style
  attributes and pitch can differ within a pair.

## Models and outcomes

- Recover at most one acoustic and one SSL classifier from schedule
  20260824, fold 00 (the first by protocol order). Fit only the selected
  original head specifications to archived training features and labels
  with the original split and random states. Replay the archived held-out
  probabilities (raw, calibrated and fused), with all argmax labels unchanged
  and max absolute probability deviation at most 1e-6. No search, new
  temperature fit, original inner fits or extra outer fits.
- Apply the original eGeMAPS-plus-singing features (exclude named duration),
  local pinned MuQ layer and pooling, original temperatures, and original
  fusion family and weight. No new encoders or base-model training.
  CPU only, one scientific worker at a time, offline except official data
  reads. No third-party classifier, interpretation from model predictions,
  or adjustment using GTSinger results.
- For each method and pair, subtract the natural rendition's probability
  of the named target from that of the technique rendition using the
  original, unmasked six-class output. Correct if this is greater than
  1e-12, reversed if below -1e-12, and otherwise a tie (not a success).
  The target label is used only to score the outputs.
- Report all positive, reversed and tied pairs; compare fusion vs SSL
  (primary descriptive contrast), acoustic vs SSL and fusion vs acoustic.
  A correction is non-success to success; a new error is success to
  non-success. Preserve all four correctness-transition cells, signed
  score differences, singer/technique breakdowns and branch disagreement.
  Check that net corrections equal the difference in correct pair counts.
- Report descriptive results only. There are three singer IDs, not 24
  independent singers. A paired target-score ordering is not the
  original multi-class conflict test, generalization across all six
  labels, or evidence for improved classification. Keep unfavorable
  results and do not alter the manuscript based on a favorable subset.

Audio is for local non-commercial research under the dataset terms:
https://huggingface.co/datasets/GTSinger/GTSinger/blob/main/dataset_license.md .
No audio, code or manuscript will be uploaded.
