"""Paths and create-once records for this pilot only."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REV = HERE.parent
ROOT = REV.parent
ANCHOR = REV / "anchor_multiseed_20261111"
RESULTS = ANCHOR / "results_v3"
DATA_HOME = Path("local_inputs")
DATA = DATA_HOME / "final_release_archive_20260824/vocalset_data"
PYTHON = DATA_HOME / "gpu_smoke_venv/Scripts/python.exe"
AUDIO_PYTHON = DATA_HOME / "isolated_test_env_20260824/Scripts/python.exe"
PROTOCOL = HERE / "protocol.json"
PAIRS = HERE / "locked_pairs.json"
META = HERE / "english_annotation.json"
AUDIODIR = HERE / "audio"
RUN = HERE / "execution"
HEADS = HERE / "heads"
METHODS = ("acoustic", "ssl", "fusion")
CONTRASTS = (("fusion", "ssl"), ("acoustic", "ssl"), ("fusion", "acoustic"))


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def read(path):
    return Path(path).read_text(encoding="utf-8-sig")


def load(path):
    return json.loads(read(path))


def file_hash(path):
    h = sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=True, indent=2, allow_nan=False) + "\n").encode("ascii")


def write_new(path, contents):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(contents)


def save_new(path, value):
    write_new(path, encoded(value))


def bound_files():
    return {p.name: file_hash(p) for p in (PROTOCOL, HERE / "PROTOCOL.md", *sorted(HERE.glob("*.py")))}


def pairs_locked():
    seal = load(HERE / "protocol_lock.json")
    if seal["files"] != bound_files() or seal["pairs_sha256"] != file_hash(PAIRS):
        raise ValueError("Locked scientific code, protocol or selected pairs changed")
    return load(PAIRS)["pairs"]
