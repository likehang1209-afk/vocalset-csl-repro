"""Select without scores; then fetch only the sealed utterances."""
from collections import Counter, defaultdict
from hashlib import sha256
from io import BytesIO
import json
from math import fsum, isfinite
from pathlib import PurePosixPath
import re
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
import wave

from common import (AUDIODIR, HERE, META, PAIRS, PROTOCOL, bound_files,
                    file_hash, load, pairs_locked, save_new, stamp, write_new)


def source_url(protocol, path):
    return (f"https://huggingface.co/datasets/{protocol['dataset']}/resolve/"
            f"{protocol['dataset_revision']}/{quote(path, safe='/')}")


def fetch(url, limit):
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={"User-Agent": "CSL-local-research-pilot/1.0"}), timeout=25) as response:
                size = response.headers.get("Content-Length")
                if size is not None and int(size) > limit:
                    raise ValueError(f"Declared response too large: {url}")
                data = response.read(limit + 1)
                if not data or len(data) > limit or (size is not None and len(data) != int(size)):
                    raise ValueError(f"Invalid response size: {url}")
                return data
        except HTTPError as exc:
            if exc.code not in (408, 429, 500, 502, 503, 504) or attempt == 2:
                raise
        except (URLError, TimeoutError):
            if attempt == 2:
                raise
        time.sleep(1 + attempt)
    raise AssertionError("Fetch attempts exhausted")


def lexical(tokens):
    return tuple(s.strip().casefold() for s in tokens if s.strip() and not s.startswith("<"))


def annotation(row, technique):
    flags = row[technique + "_tech"]
    ph = row["ph"]
    durations = row["ph_durs"]
    if len(flags) != len(ph) or len(ph) != len(durations) or not ph:
        raise ValueError("Inconsistent phoneme annotation")
    if any(x not in (0, 1) for x in flags) or any(
        not isinstance(x, (int, float)) or not isfinite(x) or x < 0 for x in durations
    ):
        raise ValueError("Malformed phoneme annotation")
    return {"annotated_seconds": fsum(durations),
            "target_seconds": fsum(d for flag, token, d in zip(flags, ph, durations)
                                  if flag and not token.startswith("<")),
            "target_flag_count": sum(flags)}


def select_pairs(metadata, protocol):
    eligible = defaultdict(list)
    candidates = defaultdict(dict)
    reasons = defaultdict(Counter)
    for row in metadata:
        if row.get("language") != protocol["language"] or row.get("singer") not in protocol["singers"]:
            continue
        path = row["wav_fn"]
        parts = PurePosixPath(path).parts
        if (len(parts) != 6 or parts[:2] != (protocol["language"], row["singer"])
                or any(p in (".", "..") for p in parts) or "\\" in path
                or not re.fullmatch(r"[0-9]{4}\.wav", parts[-1])):
            raise ValueError(f"Unexpected English singing path: {path}")
        _, singer, folder, song, group, file = parts
        technique = folder.lower()
        if technique not in protocol["techniques"] or group not in ("Control_Group", folder + "_Group"):
            continue
        segment = file[:-4]
        if row.get("item_name") != "#".join((*parts[:-1], segment)):
            raise ValueError(f"Item name and path differ: {path}")
        role = "control" if group == "Control_Group" else "technique"
        pair = candidates[singer, technique, song, segment]
        if role in pair:
            raise ValueError(f"Duplicate item in official metadata: {path}")
        pair[role] = row
    lo, hi = protocol["annotated_duration_seconds"]
    for (singer, technique, song, segment), rows in candidates.items():
        reason = reasons[singer, technique]
        if set(rows) != {"technique", "control"}:
            reason["no_aligned_counterpart"] += 1
            continue
        try:
            tokens = lexical(rows["technique"]["txt"])
            if not tokens or tokens != lexical(rows["control"]["txt"]):
                reason["different_lyrics"] += 1
                continue
            att = {role: annotation(row, technique) for role, row in rows.items()}
        except (ValueError, KeyError, TypeError):
            reason["malformed_annotation"] += 1
            continue
        if not all(lo <= a["annotated_seconds"] <= hi for a in att.values()):
            reason["duration_out_of_bounds"] += 1
        elif att["technique"]["target_seconds"] < protocol["minimum_tagged_phoneme_seconds"]:
            reason["insufficient_target_annotation"] += 1
        elif att["control"]["target_flag_count"] != 0:
            reason["target_annotated_in_control"] += 1
        else:
            reason["eligible"] += 1
            key = "|".join((protocol["id"], singer, technique, song, segment))
            eligible[singer, technique].append({
                "singer": singer, "technique": technique, "song": song, "segment": segment,
                "rank_key": sha256(key.encode("utf-8")).hexdigest(),
                "clips": {role: {"path": r["wav_fn"], **att[role]} for role, r in rows.items()},
            })
    selected = []
    counts = []
    for singer in protocol["singers"]:
        for technique in protocol["techniques"]:
            used_songs = set()
            for c in sorted(eligible[singer, technique], key=lambda x: (x["rank_key"], x["song"], x["segment"])):
                if c["song"] in used_songs:
                    continue
                used_songs.add(c["song"])
                selected.append({"pair_id": f"P{len(selected) + 1:02d}", **c})
                if len(used_songs) == protocol["max_pairs_per_singer_technique"]:
                    break
            counts.append({"singer": singer, "technique": technique,
                           "selected": len(used_songs), **dict(reasons[singer, technique])})
    return selected, counts


def lock():
    protocol = load(PROTOCOL)
    url = source_url(protocol, protocol["metadata_path"])
    raw = fetch(url, 48 * 1024**2)
    selected, counts = select_pairs(json.loads(raw), protocol)
    if not selected or len(selected) > protocol["max_total_pairs"] or any(not c["selected"] for c in counts):
        raise ValueError(f"Locked eligibility does not cover all six cells: {counts}")
    files = [x["path"] for pair in selected for x in pair["clips"].values()]
    if len(set(files)) != 2 * len(selected):
        raise ValueError("Selected source WAVs repeat")
    write_new(META, raw)
    save_new(PAIRS, {"locked_at_utc": stamp(), "official_metadata": url,
                     "metadata_sha256": file_hash(META), "counts": counts, "pairs": selected})
    save_new(HERE / "protocol_lock.json", {"locked_at_utc": stamp(),
                                          "files": bound_files(), "pairs_sha256": file_hash(PAIRS)})
    print(json.dumps({"pairs_locked": len(selected), "wav_limit": len(files), "cells": counts}), flush=True)


def clip_name(pair, role):
    return f"{pair['pair_id']}_{role}.wav"


def check_wave(data, clip, protocol):
    with wave.open(BytesIO(data), "rb") as wav:
        n, sr, channels, width = wav.getnframes(), wav.getframerate(), wav.getnchannels(), wav.getsampwidth()
        pcm = wav.readframes(n)
    duration = n / sr
    if len(pcm) != n * channels * width or (sr, width) != (48000, 3) or not 1 <= channels <= 2:
        raise ValueError("WAV is not a complete official 48 kHz 24-bit PCM recording")
    if abs(duration - clip["annotated_seconds"]) > protocol["max_wav_duration_discrepancy_seconds"]:
        raise ValueError(f"Audio does not match annotation duration: {clip['path']} ({duration})")
    return {"frames": n, "sample_rate": sr, "channels": channels, "seconds": duration,
            "pcm_sha256": sha256(pcm).hexdigest()}


def download():
    pairs = pairs_locked()
    protocol = load(PROTOCOL)
    downloads = []
    seen = set()
    for pair in pairs:
        for role in ("technique", "control"):
            clip = pair["clips"][role]
            url = source_url(protocol, clip["path"])
            data = fetch(url, 8 * 1024**2)
            audio = check_wave(data, clip, protocol)
            if audio["pcm_sha256"] in seen:
                raise ValueError(f"Duplicate WAV signal: {clip['path']}")
            seen.add(audio["pcm_sha256"])
            path = AUDIODIR / clip_name(pair, role)
            write_new(path, data)
            downloads.append({"file": path.name, "pair_id": pair["pair_id"], "role": role,
                              "source": url, "sha256": file_hash(path), "bytes": len(data), **audio})
            print(f"Fetched {len(downloads)}/{2 * len(pairs)} {path.name} ({len(data)} bytes)", flush=True)
    save_new(HERE / "audio_receipt.json", {"completed_at_utc": stamp(),
                                         "pairs_sha256": file_hash(PAIRS), "clips": downloads})
