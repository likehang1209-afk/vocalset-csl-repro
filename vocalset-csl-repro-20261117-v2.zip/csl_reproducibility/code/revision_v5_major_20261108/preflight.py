"""Read-only readiness and workload checks; no training or cloud access."""
from __future__ import annotations

import argparse
import math
from pathlib import Path

from common import (ROOT, environment, file_hash, load_plan, load_segments, read_json,
                    segment_indices, source_hashes, write_json)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("plan", "audio", "models", "output"):
        parser.add_argument("--"+name, type=Path, required=True)
    args = parser.parse_args()
    plan = load_plan(args.plan)
    segments = load_segments(args.audio, plan)
    report = {"plan_fingerprint":plan["fingerprint"], "clips":len(plan["clips"]),
              "segments":len(segments["segments"]), "outer_folds":len(plan["folds"]),
              "audio_checks":{}, "model_checks":{}, "environment":environment(),
              "source_hashes":source_hashes(), "cloud_contacted":False,
              "formal_experiments_completed":False}
    for name, expected in segments["files"].items():
        report["audio_checks"][name] = file_hash(args.audio/name) == expected
    for name, config in plan["protocol"]["models"].items():
        folder = args.models/name
        lock = folder/"revision_lock.json"
        if not lock.exists():
            report["model_checks"][name] = {"ready":False,"reason":"pinned checkpoint not yet prepared"}
            continue
        metadata = read_json(lock)
        hashes = {f:(folder/f).is_file() and file_hash(folder/f)==expected
                  for f,expected in metadata.get("files",{}).items()}
        has_weights = any(f.endswith((".bin",".safetensors",".pt")) for f in hashes)
        report["model_checks"][name] = {"ready":metadata["config"]==config and has_weights and all(hashes.values()),
                                       "revision":config["revision"],"file_checks":hashes}
    p = plan["protocol"]
    z = p["zhou"]
    n_folds = len(plan["folds"])
    n_candidates = (len(z["layers"])+1)*len(z["learning_rates"])
    training_segments = [len(segment_indices(segments,f["train"])) for f in plan["folds"]]
    report["workload"] = {
        "yamamoto_backbone_training_jobs":n_folds*len(p["yamamoto"]["models"]),
        "yamamoto_logical_batch_updates":sum(math.ceil(n/p["yamamoto"]["effective_batch_size"])
              for n in training_segments)*p["yamamoto"]["epochs"]*len(p["yamamoto"]["models"]),
        "zhou_inner_mlp_fits":n_folds*p["inner_splits"]*n_candidates*len(z["models"]),
        "zhou_final_mlp_fits":n_folds*len(z["modes"])*len(z["models"]),
        "zhou_max_epochs_per_fit":z["max_epochs"],
        "gpu_hours":None,
        "timing_requirement":"Measure full one-singer run, not just a single forward pass, before scheduling the remaining folds."
    }
    report["local_assets_ready"] = all(report["audio_checks"].values()) and all(
        r["ready"] for r in report["model_checks"].values())
    report["next_gate"] = "GPU smoke tests and one-fold time/memory measurement; do not launch all folds at once"
    write_json(args.output,report)
    print(f"Audio verified: {all(report['audio_checks'].values())}; pinned models: "
          f"{sum(r['ready'] for r in report['model_checks'].values())}/4")
    print(report["workload"])


if __name__ == "__main__":
    main()
