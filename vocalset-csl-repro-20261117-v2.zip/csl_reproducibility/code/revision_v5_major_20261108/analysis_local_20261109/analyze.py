"""Align validated saved predictions and perform the declared twelve contrasts."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

HERE = Path(__file__).resolve().parent
REVISION = HERE.parent
sys.path.insert(0, str(REVISION))
from common import digest, environment, file_hash, load_plan, read_json, write_json
from collect_results import collect
from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue
from vocalset_csl.metrics import classification_metrics

RECOVERY = Path(__file__).resolve().parents[3] / "data/individual_training_records_not_bundled"
ORIGINAL = Path(__file__).resolve().parents[3] / "data/original_predictions.csv"
NEW_METHODS = (
    "yamamoto_music2vec", "yamamoto_wavlm", "zhou_muq_weighted",
    "zhou_muq_scan", "zhou_musicfm_weighted", "zhou_musicfm_scan",
)
OLD_METHODS = ("acoustic", "ssl", "early_fusion", "late_fusion_calibrated")
NAMES = {
    "acoustic": "Acoustic descriptors", "ssl": "Selected SSL",
    "early_fusion": "Early fusion", "late_fusion_calibrated": "Calibrated late fusion",
    "yamamoto_music2vec": "Music2Vec + fine-tuning [19]",
    "yamamoto_wavlm": "WavLM + fine-tuning [19]",
    "zhou_muq_weighted": "MuQ + weighted layers [20]",
    "zhou_muq_scan": "MuQ + layer scan [20]",
    "zhou_musicfm_weighted": "MusicFM + weighted layers [20]",
    "zhou_musicfm_scan": "MusicFM + layer scan [20]",
}


def holm(pvalues):
    p = np.asarray(pvalues, dtype=float)
    if p.ndim != 1 or not len(p) or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("Invalid p values")
    order = np.argsort(p, kind="stable")
    result = np.empty_like(p)
    result[order] = np.minimum(1, np.maximum.accumulate(p[order] * np.arange(len(p), 0, -1)))
    return result


def validate_probabilities(values, count, classes):
    p = np.asarray(values, dtype=float)
    if (p.shape != (count, classes) or not np.isfinite(p).all() or (p < 0).any()
            or not np.allclose(p.sum(axis=1), 1, atol=1e-5, rtol=0)):
        raise ValueError("Invalid probability matrix")
    return p


def align_original(rows, clips, classes):
    ids = clips.clip_id.tolist()
    if not rows.clip_id.is_unique or set(rows.clip_id) != set(ids):
        raise ValueError("Duplicate or missing original clip IDs")
    aligned = rows.set_index("clip_id").loc[ids]
    if not np.array_equal(aligned.true_label.to_numpy(), clips.target.to_numpy()):
        raise ValueError("Original targets differ")
    if not np.array_equal(aligned.singer_id.astype(str), clips.singer_id.astype(str)):
        raise ValueError("Original singer identities differ")
    if not np.array_equal(aligned.outer_split.astype(str), "loso_" + clips.singer_id.astype(str)):
        raise ValueError("Original held-singer assignments differ")
    p = validate_probabilities([json.loads(v) for v in aligned.probabilities], len(ids), classes)
    if not np.array_equal(p.argmax(1), aligned.predicted_label.to_numpy()):
        raise ValueError("Stored original argmax labels differ")
    return p


def markdown_table(headers, rows):
    return "\n".join([
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
        *("| " + " | ".join(map(str, row)) + " |" for row in rows),
    ]) + "\n"


def run(output):
    if output.exists():
        raise FileExistsError("Use a fresh output directory; no result overwrite")
    plan = load_plan(REVISION / "artifacts/plan.json")
    receipt = read_json(RECOVERY / "verified_recovery.json")
    if not all(receipt[k] for k in ("backup_verified", "all_fold_metrics_replayed", "aggregate_exact_replay", "scientific_source_hashes_verified")):
        raise ValueError("Input recovery is not verified")
    if receipt["completed"] != 120 or receipt["seed_count"] != 1 or receipt["plan_fingerprint"] != plan["fingerprint"]:
        raise ValueError("Incomplete or incompatible result block")
    source = RECOVERY / "unpacked/csl_r2_20261108"
    results = source / "data/results_v2_rngcomplete"
    paths = sorted(p for group in ("yamamoto", "zhou") for p in (results / group).rglob("result.json"))
    if len(paths) != 120:
        raise ValueError("Expected all 120 results")
    for path in paths:
        record = read_json(path)
        if record["details"].get("seed") != plan["protocol"]["training_seed"] + 1000 * record["fold"]:
            raise ValueError("Training seed differs")
    collected = collect(plan, paths)
    if digest(collected) != digest(read_json(RECOVERY / "complete_results_replayed.json")):
        raise ValueError("New pooled/singer metrics no longer reproduce audit")
    if set(collected["methods"]) != set(NEW_METHODS):
        raise ValueError("Wrong method inventory")
    clips = pd.DataFrame(plan["clips"])
    ids, y = clips.clip_id.tolist(), clips.target.to_numpy(dtype=int)
    singers = sorted(clips.singer_id.unique())
    if len(clips) != 1206 or len(singers) != 20 or len(plan["labels"]) != 6:
        raise ValueError("Wrong cohort")
    old = pd.read_csv(ORIGINAL)
    probabilities = {}
    for name in OLD_METHODS:
        probabilities[name] = align_original(old.loc[old.method.eq(name)], clips, 6)
    calibrated_ssl = align_original(old.loc[old.method.eq("ssl_calibrated")], clips, 6)
    if not np.array_equal(probabilities["ssl"].argmax(1), calibrated_ssl.argmax(1)):
        raise ValueError("SSL calibration changed class predictions")
    for name in NEW_METHODS:
        method = collected["methods"][name]
        if method["clip_ids"] != ids:
            raise ValueError("New clip ordering differs")
        probabilities[name] = validate_probabilities(method["probabilities"], len(ids), 6)

    pooled, per_singer, per_class = [], [], []
    for name, p in probabilities.items():
        metrics = classification_metrics(y, p, 6)
        values = []
        for singer in singers:
            mask = clips.singer_id.eq(singer).to_numpy()
            item = classification_metrics(y[mask], p[mask], 6)
            if item["present_class_count"] != 6:
                raise ValueError("All six labels must be represented for every singer")
            values.append(item["macro_f1_global"])
            per_singer.append({"method": name, "singer": singer, "clips": int(mask.sum()),
                               "macro_f1": item["macro_f1_global"], "uar": item["uar_global"],
                               "accuracy": item["accuracy"]})
        pooled.append({"method": name, "display": NAMES[name], "pooled_f1": metrics["macro_f1_global"],
                       "uar": metrics["uar_global"], "accuracy": metrics["accuracy"],
                       "singer_mean_f1": float(np.mean(values)), "singer_sd_f1": float(np.std(values, ddof=1)),
                       "nll": metrics["nll"], "brier": metrics["brier"], "ece": metrics["ece"],
                       "probability_status": "calibrated_branches" if name == "late_fusion_calibrated" else "raw"})
        scores = f1_score(y, p.argmax(1), labels=np.arange(6), average=None, zero_division=0)
        per_class.extend({"method": name, "label": label, "f1": float(f1)}
                         for label, f1 in zip(plan["labels"], scores))
    expected_old = dict(zip(OLD_METHODS, (0.7891, 0.8288, 0.8253, 0.8330)))
    for row in pooled[:4]:
        if round(row["pooled_f1"], 4) != expected_old[row["method"]]:
            raise ValueError("Old scores do not match the submitted manuscript")
    sf = pd.DataFrame(per_singer).pivot(index="singer", columns="method", values="macro_f1").loc[singers]
    contrasts = []
    for anchor in ("ssl", "late_fusion_calibrated"):
        for name in NEW_METHODS:
            diff = (sf[name] - sf[anchor]).to_numpy()
            if len(diff) != 20 or not np.isfinite(diff).all():
                raise ValueError("Incomplete paired differences")
            boot = paired_cluster_bootstrap(diff, replicates=10000, seed=20260825)
            omitted = (diff.sum() - diff) / 19
            contrasts.append({"method": name, "anchor": anchor, **boot,
                              "p_raw": paired_sign_flip_pvalue(diff),
                              "wins": int((diff > 0).sum()), "ties": int((diff == 0).sum()),
                              "losses": int((diff < 0).sum()),
                              "omit_one_singer_min": float(omitted.min()),
                              "omit_one_singer_max": float(omitted.max())})
    for row, corrected in zip(contrasts, holm([r["p_raw"] for r in contrasts])):
        row["p_holm_12"] = float(corrected)

    output.mkdir(parents=True)
    pd.DataFrame(pooled).to_csv(output / "pooled_and_singer.csv", index=False)
    pd.DataFrame(per_singer).to_csv(output / "per_singer.csv", index=False)
    pd.DataFrame(per_class).to_csv(output / "per_class.csv", index=False)
    pd.DataFrame(contrasts).to_csv(output / "paired_contrasts.csv", index=False)
    provenance = {str(p): file_hash(p) for p in [
        ORIGINAL, HERE / "ANALYSIS_PLAN.md", Path(__file__), REVISION / "artifacts/plan.json",
        RECOVERY / "verified_recovery.json", RECOVERY / "complete_results_replayed.json",
        *paths,
    ]}
    write_json(output / "analysis.json", {
        "status": "passed", "time_utc": datetime.now(timezone.utc).isoformat(),
        "plan_fingerprint": plan["fingerprint"], "new_folds": 120, "new_seed_count": 1,
        "singers": singers, "clips": 1206, "labels": plan["labels"], "environment": environment(),
        "alignment": "identical canonical recordings, labels and outer held-singer assignments",
        "old_ssl_calibration_preserves_argmax": True,
        "new_aggregation_replays_exactly": True, "original_pooled_values_reproduce_manuscript": True,
        "family_size": 12, "bootstrap_seed": 20260825,
        "p_convention": "all 2^20 sign flips; inherited conservative plus-one numerator and denominator",
        "pooled": pooled, "contrasts": contrasts, "input_sha256": provenance,
        "limitations": ["single training seed", "pointwise CIs", "overlapping LOSO training sets",
                        "retrospective analysis", "3s new versus 5s original pipeline",
                        "not equal-budget component ablations", "not equivalence tests"],
    })
    table8 = markdown_table(["System", "Pooled F1", "UAR", "Accuracy", "Singer mean (SD)"], [
        [row["display"], f'{row["pooled_f1"]:.4f}', f'{row["uar"]:.4f}', f'{row["accuracy"]:.4f}',
         f'{row["singer_mean_f1"]:.4f} ({row["singer_sd_f1"]:.4f})'] for row in pooled])
    table9 = markdown_table(["New system", "Comparator", "Mean difference", "95% CI", "Holm p"], [
        [NAMES[row["method"]], "SSL" if row["anchor"] == "ssl" else "Late fusion",
         f'{row["mean_difference"]:.4f}', f'[{row["ci95_low"]:.4f}, {row["ci95_high"]:.4f}]',
         f'{row["p_holm_12"]:.5f}'] for row in contrasts])
    (output / "table8.md").write_text(table8, encoding="utf-8")
    (output / "table9.md").write_text(table9, encoding="utf-8")
    print(table8 + "\n" + table9)
    print("Verified complete data; all 12 comparisons retained. No training or cloud operations.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "results_v1")
    run(parser.parse_args().output)
