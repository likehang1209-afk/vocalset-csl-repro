"""Freeze canonical clip IDs and the original sklearn-1.7.2 nested partitions."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

# The archived wheel is used only to reproduce the historical split algorithm.
VENDOR = Path(__file__).resolve().parent.parent / "revision_v4_major_20260922/replay_vendor_sklearn172"
if VENDOR.is_dir():
    sys.path.insert(0, str(VENDOR))

import numpy as np
import pandas as pd
import sklearn

from common import ROOT, PROJECT, digest, file_hash, read_json, write_json, validate_plan
from vocalset_csl.splitting import leave_one_group_out, stratified_group_folds
from vocalset_csl.tasks import select_task


def create_plan(manifest, protocol, original_config, audio_root):
    if sklearn.__version__ != protocol["split_sklearn_version"]:
        raise RuntimeError(f"Split creation requires sklearn {protocol['split_sklearn_version']}, got {sklearn.__version__}")
    frame, labels = select_task(pd.read_csv(manifest), original_config, protocol["task"])
    if len(frame) != protocol["expected_clips"] or frame.singer_id.nunique() != protocol["expected_singers"]:
        raise ValueError("Canonical cohort size changed")
    ids = frame.clip_id.astype(str).to_numpy()
    groups = frame.singer_id.astype(str).to_numpy()
    y = frame.target.to_numpy(dtype=int)
    clips = []
    for row in frame.itertuples():
        relative = Path(row.canonical_path)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Unsafe canonical path")
        audio = audio_root / relative
        if not audio.is_file():
            raise FileNotFoundError(audio)
        if file_hash(audio) != row.content_sha256:
            raise ValueError(f"Audio content changed: {row.clip_id}")
        clips.append({"clip_id": row.clip_id, "singer_id": row.singer_id,
                      "label": row.label, "target": int(row.target),
                      "context": row.context, "relative_path": relative.as_posix(),
                      "content_sha256": row.content_sha256})
    folds = []
    for index, outer in enumerate(leave_one_group_out(groups)):
        inner = stratified_group_folds(y[outer.train], groups[outer.train],
            protocol["inner_splits"], protocol["inner_seed"] + index)
        folds.append({"fold": index, "held_singer": str(groups[outer.test[0]]),
                      "train": ids[outer.train].tolist(), "test": ids[outer.test].tolist(),
                      "inner": [{"train": ids[outer.train[f.train]].tolist(),
                                 "validation": ids[outer.train[f.test]].tolist()} for f in inner]})
    plan = {"protocol": protocol, "manifest_sha256": file_hash(manifest),
            "split_sklearn_version": sklearn.__version__, "labels": labels,
            "clips": clips, "folds": folds}
    validate_plan(plan)
    plan["fingerprint"] = digest(plan)
    return plan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--audio-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("Use a new plan path; do not silently replace a locked plan")
    plan = create_plan(args.manifest, read_json(ROOT / "protocol.json"),
                       read_json(PROJECT / "configs/protocol_v2.json"), args.audio_root)
    write_json(args.output, plan)
    print(f"Verified {len(plan['clips'])} audio hashes; {len(plan['folds'])} LOSO folds; {plan['fingerprint']}")


if __name__ == "__main__":
    main()
