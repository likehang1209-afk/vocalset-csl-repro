"""Execute the locked three-schedule analysis on audited local predictions."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score

HERE = Path(__file__).resolve().parent
REVISION = HERE.parent
sys.path[:0] = [str(REVISION), str(REVISION.parent / "src")]
from common import environment, file_hash, load_plan, read_json, write_json
from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue
from vocalset_csl.metrics import classification_metrics

spec = importlib.util.spec_from_file_location("single_seed_analysis", REVISION / "analysis_local_20261109/analyze.py")
single = importlib.util.module_from_spec(spec)
spec.loader.exec_module(single)
SEEDS = (20261108, 30261108, 40261108)
METHODS = single.NEW_METHODS
SHORT = {
    "yamamoto_music2vec": "Music2Vec fine-tuning", "yamamoto_wavlm": "WavLM fine-tuning",
    "zhou_muq_weighted": "MuQ weighted layers", "zhou_muq_scan": "MuQ layer scan",
    "zhou_musicfm_weighted": "MusicFM weighted layers", "zhou_musicfm_scan": "MusicFM layer scan",
}
CAPTURE = Path(__file__).resolve().parents[3] / "data/neural"
RECEIPT = CAPTURE / "verified_three_seed_360_20261110T144147Z.json"
PRIOR_PATH = REVISION / "analysis_local_20261109/results_v1/analysis.json"


def assert_close(actual, expected, label):
    if not np.allclose(actual, expected, atol=1e-12, rtol=0):
        raise ValueError("Metric replay failed: " + label)


def within_singer_average(scores):
    """Rows are seed schedules, columns the same ordered twenty singers."""
    values = np.asarray(scores, dtype=float)
    if values.shape != (3, 20) or not np.isfinite(values).all():
        raise ValueError("Expected three complete schedules and twenty singers")
    return values.mean(axis=0)


def paired_rows(singer_scores, anchors):
    output = []
    for anchor in ("ssl", "late_fusion_calibrated"):
        for method in METHODS:
            diff = np.asarray(singer_scores[method]) - np.asarray(anchors[anchor])
            if diff.shape != (20,) or not np.isfinite(diff).all():
                raise ValueError("Expected twenty paired singer differences")
            boot = paired_cluster_bootstrap(diff, replicates=10000, seed=20260825)
            omitted = (diff.sum() - diff) / 19
            output.append({"method": method, "anchor": anchor, **boot,
                           "p_raw": paired_sign_flip_pvalue(diff),
                           "wins": int((diff > 0).sum()), "ties": int((diff == 0).sum()),
                           "losses": int((diff < 0).sum()),
                           "omit_one_singer_min": float(omitted.min()),
                           "omit_one_singer_max": float(omitted.max())})
    return output


def multiplicity(prior, current):
    keys = lambda rows: [(r["method"], r["anchor"]) for r in rows]
    if len(prior) != 12 or len(current) != 12 or keys(prior) != keys(current) or len(set(keys(prior))) != 12:
        raise ValueError("Expected the same twelve unique contrasts in both stages")
    for rows in (prior, current):
        for row, p in zip(rows, single.holm([r["p_raw"] for r in rows])):
            row["p_holm_12"] = float(p)
    for row, p in zip(prior + current, single.holm([r["p_raw"] for r in prior + current])):
        row["p_holm_joint_24"] = float(p)


def run(output):
    if output.exists():
        raise FileExistsError("Use a fresh output path")
    receipt = read_json(RECEIPT)
    if (receipt.get("superseded") or receipt["completed_results"] != 360 or
            not receipt["three_seed_coverage_verified"] or
            not receipt["all_fold_metrics_independently_replayed"] or
            receipt["seed_schedules"] != list(SEEDS) or
            receipt["completed_by_seed"] != {str(s): 120 for s in SEEDS} or
            receipt["completed_by_method"] != {m: 60 for m in METHODS}):
        raise ValueError("Incomplete or superseded receipt")
    aggregate_path = Path(receipt["aggregate_path"])
    if file_hash(aggregate_path) != receipt["aggregate_sha256"]:
        raise ValueError("Audited aggregate changed")
    data, plan, prior = read_json(aggregate_path), load_plan(REVISION / "artifacts/plan.json"), read_json(PRIOR_PATH)
    if set(data) != {str(s) for s in SEEDS}:
        raise ValueError("Seed coverage differs")
    if file_hash(single.ORIGINAL) != prior["original_predictions_sha256"]:
        raise ValueError("Historical predictions changed")
    clips = pd.DataFrame(plan["clips"])
    ids, y = clips.clip_id.tolist(), clips.target.to_numpy(int)
    singers = sorted(clips.singer_id.unique())
    if len(clips) != 1206 or len(singers) != 20 or len(plan["labels"]) != 6:
        raise ValueError("Cohort differs")
    old = pd.read_csv(single.ORIGINAL)
    anchors, original, seed_rows, singer_rows, class_rows = {}, [], [], [], []
    for name in single.OLD_METHODS:
        p = single.align_original(old.loc[old.method.eq(name)], clips, 6)
        metrics = classification_metrics(y, p, 6)
        values = np.array([classification_metrics(y[clips.singer_id.eq(s)], p[clips.singer_id.eq(s)], 6)["macro_f1_global"] for s in singers])
        anchors[name] = values
        row = {"method": name, "display": single.NAMES[name], "pooled_f1": metrics["macro_f1_global"],
               "uar": metrics["uar_global"], "accuracy": metrics["accuracy"],
               "singer_mean_f1": float(values.mean()), "singer_sd_f1": float(values.std(ddof=1))}
        earlier = next(r for r in prior["pooled"] if r["method"] == name)
        for key in ("pooled_f1", "uar", "accuracy", "singer_mean_f1", "singer_sd_f1"):
            assert_close(row[key], earlier[key], "original " + name + " " + key)
        original.append(row)
    matrices = {m: [] for m in METHODS}
    for seed in SEEDS:
        candidate_plan = plan if seed == SEEDS[0] else load_plan(REVISION / f"seed_extension_20261109/plans/seed_{seed}.json")
        group = data[str(seed)]
        if group["plan_fingerprint"] != candidate_plan["fingerprint"] or set(group["methods"]) != set(METHODS):
            raise ValueError("Aggregate plan or method mismatch")
        for method in METHODS:
            record = group["methods"][method]
            if record["clip_ids"] != ids or set(record["singer_metrics"]) != set(singers):
                raise ValueError("Recording or singer alignment differs")
            p = single.validate_probabilities(record["probabilities"], 1206, 6)
            metrics = classification_metrics(y, p, 6)
            for key in ("macro_f1_global", "uar_global", "accuracy", "nll", "brier", "ece"):
                assert_close(metrics[key], record["pooled"][key], str(seed) + method + key)
            values = []
            for singer in singers:
                mask = clips.singer_id.eq(singer).to_numpy()
                score = classification_metrics(y[mask], p[mask], 6)
                if score["present_class_count"] != 6:
                    raise ValueError("Missing class for singer")
                for key in ("macro_f1_global", "uar_global", "accuracy"):
                    assert_close(score[key], record["singer_metrics"][singer][key], method + singer + key)
                values.append(score["macro_f1_global"])
                singer_rows.append({"seed": seed, "method": method, "singer": singer, "clips": int(mask.sum()),
                                    "macro_f1": score["macro_f1_global"], "uar": score["uar_global"], "accuracy": score["accuracy"]})
            matrices[method].append(values)
            seed_rows.append({"seed": seed, "method": method, "display": SHORT[method],
                              "pooled_f1": metrics["macro_f1_global"], "uar": metrics["uar_global"],
                              "accuracy": metrics["accuracy"], "singer_mean_f1": float(np.mean(values)),
                              "singer_sd_f1": float(np.std(values, ddof=1))})
            class_rows.extend({"seed": seed, "method": method, "label": label, "f1": float(score)}
                              for label, score in zip(plan["labels"], f1_score(y, p.argmax(1), labels=np.arange(6), average=None, zero_division=0)))
    averaged = {m: within_singer_average(matrices[m]) for m in METHODS}
    summary = []
    for method in METHODS:
        rows = [r for r in seed_rows if r["method"] == method]
        row = {"method": method, "display": SHORT[method], "singer_mean_f1": float(averaged[method].mean()),
               "singer_sd_of_seed_means": float(averaged[method].std(ddof=1))}
        for key in ("pooled_f1", "uar", "accuracy"):
            values = [r[key] for r in rows]
            row[key + "_mean"] = float(np.mean(values))
            row[key + "_seed_sd"] = float(np.std(values, ddof=1))
            row[key + "_seeds"] = values
        summary.append(row)
    historical = paired_rows({m: np.array(matrices[m][0]) for m in METHODS}, anchors)
    for replay, earlier in zip(historical, prior["contrasts"]):
        if (replay["method"], replay["anchor"]) != (earlier["method"], earlier["anchor"]):
            raise ValueError("Historical contrast ordering changed")
        for key in ("mean_difference", "ci95_low", "ci95_high", "p_raw"):
            assert_close(replay[key], earlier[key], "historical inference " + key)
    contrasts = paired_rows(averaged, anchors)
    multiplicity(historical, contrasts)
    for a, b in zip(historical, prior["contrasts"]):
        assert_close(a["p_holm_12"], b["p_holm_12"], "historical Holm")
    output.mkdir(parents=True)
    averaged_rows = [{"method": m, "singer": s, "mean_f1_over_seeds": float(averaged[m][i]),
                      "original_ssl_f1": float(anchors["ssl"][i]), "original_fusion_f1": float(anchors["late_fusion_calibrated"][i])}
                     for m in METHODS for i, s in enumerate(singers)]
    for name, rows in (("per_seed", seed_rows), ("per_singer_seed", singer_rows), ("per_class_seed", class_rows),
                       ("seed_summary", summary), ("original_anchors", original), ("seed_averaged_singers", averaged_rows),
                       ("paired_extension", contrasts), ("paired_historical_joint", historical)):
        pd.DataFrame(rows).to_csv(output / (name + ".csv"), index=False)
    inputs = [RECEIPT, aggregate_path, single.ORIGINAL, PRIOR_PATH, Path(__file__), Path(single.__file__),
              HERE / "ANALYSIS_EXECUTION.md", REVISION / "seed_extension_20261109/PLAN.md",
              REVISION / "artifacts/plan.json", REVISION.parent / "src/vocalset_csl/inference.py",
              REVISION.parent / "src/vocalset_csl/metrics.py"]
    report = {"status": "passed", "time_utc": datetime.now(timezone.utc).isoformat(), "environment": environment(),
              "completed_folds": 360, "seed_schedules": list(SEEDS), "singers": singers, "clips": 1206, "labels": plan["labels"],
              "original_anchors": original, "per_seed": seed_rows, "summary": summary,
              "contrasts": contrasts, "historical_contrasts_with_joint_correction": historical,
              "family_sizes": [12, 24], "bootstrap_replicates": 10000, "bootstrap_rng": 20260825,
              "inference_unit": "20 singer means across the same three schedules, not60 independent singers",
              "sign_test": "2^20 assignments, inherited conservative plus-one convention",
              "historical_inference_exact_replay": True, "pooled_and_singer_metrics_replayed": True,
              "input_sha256": {str(p): file_hash(p) for p in inputs},
              "boundary": "Conditional three-schedule stability, fixed historical comparators, pointwise CIs; not equivalence, causality or external validation."}
    write_json(output / "analysis.json", report)
    table8 = single.markdown_table(["System", "Pooled F1 (seed SD)", "Mean UAR", "Mean accuracy", "Singer mean (SD)"],
        [[r["display"], f'{r["pooled_f1"]:.4f} (NA)', f'{r["uar"]:.4f}', f'{r["accuracy"]:.4f}',
          f'{r["singer_mean_f1"]:.4f} ({r["singer_sd_f1"]:.4f})'] for r in original] +
        [[r["display"], f'{r["pooled_f1_mean"]:.4f} ({r["pooled_f1_seed_sd"]:.4f})', f'{r["uar_mean"]:.4f}',
          f'{r["accuracy_mean"]:.4f}', f'{r["singer_mean_f1"]:.4f} ({r["singer_sd_of_seed_means"]:.4f})'] for r in summary])
    table9 = single.markdown_table(["New system", "Anchor", "Mean delta", "95% CI", "Holm 12", "Joint Holm 24"],
        [[SHORT[r["method"]], "SSL" if r["anchor"] == "ssl" else "Late fusion", f'{r["mean_difference"]:.4f}',
          f'[{r["ci95_low"]:.4f}, {r["ci95_high"]:.4f}]', f'{r["p_holm_12"]:.5f}', f'{r["p_holm_joint_24"]:.5f}'] for r in contrasts])
    (output / "table8.md").write_text(table8, encoding="utf-8")
    (output / "table9.md").write_text(table9, encoding="utf-8")
    print(table8 + "\n" + table9)
    print("All360 metrics replayed. Historical12 replayed. No model refitting or cloud operation.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "results_v1")
    run(parser.parse_args().output)
