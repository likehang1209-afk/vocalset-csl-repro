import unittest
import numpy as np
import analyze as a


class MultiseedTests(unittest.TestCase):
    def test_average_within_singer_not_flatten(self):
        data = np.arange(60).reshape(3, 20)
        np.testing.assert_array_equal(a.within_singer_average(data), np.arange(20) + 20)

    def test_missing_or_nonfinite_rejected(self):
        for data in (np.zeros((2, 20)), np.zeros((3, 19)), np.full((3, 20), np.nan)):
            with self.assertRaises(ValueError):
                a.within_singer_average(data)

    def test_joint_adjustment_not_less_conservative(self):
        prior, current = [], []
        for anchor in ("ssl", "late_fusion_calibrated"):
            for i, method in enumerate(a.METHODS):
                prior.append({"method": method, "anchor": anchor, "p_raw": .1 + .1 * i})
                current.append({"method": method, "anchor": anchor, "p_raw": .001 + .01 * i})
        a.multiplicity(prior, current)
        self.assertTrue(all(r["p_holm_joint_24"] >= r["p_holm_12"] for r in prior + current))
        self.assertAlmostEqual(current[0]["p_holm_joint_24"], .024)

    def test_changed_contrast_family_rejected(self):
        with self.assertRaises(ValueError):
            a.multiplicity([], [])

    def test_holm_reference(self):
        np.testing.assert_allclose(a.single.holm([.01, .04, .03]), [.03, .06, .06])


if __name__ == "__main__":
    unittest.main()
