"""Extract frozen three-second layer means with the pinned official backbones."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import time

import numpy as np
import torch

from common import ROOT, digest, environment, file_hash, load_plan, load_segments, source_hashes, verify_model_folder, write_json


def load_backbone(name, cfg, model_root, device):
    folder = model_root / name
    verify_model_folder(folder, cfg)
    if name == "muq":
        from muq import MuQ
        model = MuQ.from_pretrained(str(folder))
    else:
        sys.path.insert(0, str(ROOT / "upstream"))
        from musicfm.model.musicfm_25hz import MusicFM25Hz
        model = MusicFM25Hz(is_flash=False, stat_path=str(folder / "msd_stats.json"),
                           model_path=str(folder / "pretrained_msd.pt"),
                           config_path=str(folder / "conformer_config"))
    return model.float().eval().requires_grad_(False).to(device)


def get_means(model, name, audio):
    if name == "muq":
        hidden = model(audio, output_hidden_states=True).hidden_states
    else:
        _, hidden = model.get_predictions(audio)
    if len(hidden) != 13:
        raise ValueError(f"Expected input state plus 12 encoder states, got {len(hidden)}")
    means = torch.stack([hidden[i].float().mean(dim=1) for i in range(1, 13)], dim=1)
    if means.shape[-1] != 1024 or not torch.isfinite(means).all():
        raise ValueError("Invalid backbone output")
    return means


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--audio", type=Path, required=True)
    parser.add_argument("--models", type=Path, required=True)
    parser.add_argument("--model", choices=["muq", "musicfm"], required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--smoke", action="store_true", help="Training clips only; output is NOT a usable feature cache")
    args = parser.parse_args()
    torch.set_num_threads(4)
    plan = load_plan(args.plan)
    meta = load_segments(args.audio, plan)
    if args.output.exists():
        raise FileExistsError("Use a new extraction output")
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")
    cfg = plan["protocol"]["models"][args.model]
    input_path = args.audio / "waveforms_24000.npy"
    if file_hash(input_path) != meta["files"][input_path.name]:
        raise ValueError("Audio cache hash mismatch")
    wave = np.load(input_path, mmap_mode="r", allow_pickle=False)
    indices = np.arange(len(wave))
    if args.smoke:
        train = set(plan["folds"][0]["train"])
        indices = np.array([i for i, r in enumerate(meta["segments"]) if r["clip_id"] in train][:8])
    args.output.mkdir(parents=True)
    model = load_backbone(args.model, cfg, args.models, args.device)
    destination = args.output / "layer_means.npy"
    out = np.lib.format.open_memmap(destination, mode="w+", dtype="float32",
                                  shape=(len(indices), 12, cfg["dimension"]))
    start = time.perf_counter()
    if args.device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats()
    with torch.inference_mode():
        for begin in range(0, len(indices), args.batch_size):
            batch_indices = indices[begin:begin+args.batch_size]
            audio = torch.tensor(np.asarray(wave[batch_indices]), device=args.device)
            out[begin:begin+len(batch_indices)] = get_means(model, args.model, audio).cpu().numpy()
            if begin % (args.batch_size * 25) == 0:
                print(f"{args.model}: {begin}/{len(indices)} segments", flush=True)
    out.flush()
    info = {"model": args.model, "config": cfg, "plan_fingerprint": plan["fingerprint"],
            "segments_fingerprint": meta["fingerprint"], "smoke_only": args.smoke,
            "segment_ids": [meta["segments"][i]["segment_id"] for i in indices],
            "layer_indices": list(range(1, 13)), "shape": list(out.shape),
            "sha256": file_hash(destination), "seconds": time.perf_counter()-start,
            "peak_cuda_bytes": torch.cuda.max_memory_allocated() if args.device.startswith("cuda") else None,
            "environment": environment(), "source_hashes": source_hashes()}
    info["fingerprint"] = digest(info)
    write_json(args.output / "features.json", info)
    print(f"Extraction finished; smoke_only={args.smoke}; seconds={info['seconds']:.1f}", flush=True)


if __name__ == "__main__":
    main()
