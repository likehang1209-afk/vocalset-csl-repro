# Locked lightweight risk-sensitive fusion experiment

Date: 2026-11-16, Asia/Shanghai. The user authorized local CPU training of a
small decision layer from saved inner OOF probabilities. This is an exploratory
follow-up motivated by already inspected outer-test results, NOT preregistration,
fresh confirmation, a new dataset, or a claim of a novel gating algorithm.

## Scope and no leakage

Use all 60 original outer folds: 20 singers, 1,206 recordings, six classes and
three fixed schedules (20260824, 30260824, 40260824). Reuse only the 120 selected
acoustic/SSL candidate OOF caches and saved outer predictions. No base-model
refit, feature extraction, model download, GPU, cloud, recalibration, candidate
reranking, manuscript edit, code upload or submission. All previous results,
failure markers and the latest paper remain unchanged.

For each outer fold, a training bundle contains ONLY that fold's training clip
IDs, singer groups, labels and its selected candidate raw OOF probabilities.
Verify original inner group isolation and exactly-once validation coverage.
Do not pool outer predictions from other folds as meta-training examples.
The selected candidates were chosen using outer-training labels: their OOF
records are not an independently held-out meta-validation set. No gate tuning,
meta-CV estimate or calibrated-risk guarantee is claimed. Gate settings below
are fixed, and no additional validation split or hyperparameter search is made.

Use raw OOF probabilities for gate features, not probabilities temperature-fitted
on those same labels. Standardization sees all OOF rows of that outer-training
set only. The archived branch temperatures remain unchanged and are used only
through the archived outer calibrated probabilities when a branch is selected.

Train and seal ALL gate coefficients before loading outer-input bundles. Create
and seal ALL outer predictions before loading evaluation labels or retrospective
conflict annotations. The fitting function has no test input or file access.
Mutation tests must show that changing outer labels cannot affect fitted gates
or unlabelled predictions. This guards operational leakage, not the historical
test-set reuse that motivated the hypothesis.

## One fixed candidate and its matched ablation

Both learned gates use seven observable, class-identity-free features:
acoustic/SSL maximum probability (2), top-two probability margin (2), entropy
divided by log(6) (2), and Jensen-Shannon divergence divided by log(2) (1).
No true-class margin, retrospective conflict flag, singer ID, contextual label,
duration, hand-selected class or raw acoustic feature enters the predictor.
Clip entropy terms use 0*log(0)=0 and a numerical log floor of 1e-12.

The learned rule is a HARD gate (acoustic weight 0 or 1), not a learned continuous
fusion family. On branch agreement, retain SSL. On disagreement, choose acoustic
only when the gate's logistic score is strictly greater than 0.5; equality keeps
SSL. This limited rule cannot recover examples on which BOTH branch top-1 labels
are wrong, including third-class successes of the original probability fusion.

Train only examples on which exactly one branch is correct: acoustic-only=1,
SSL-only=0. Agreeing or both-wrong rows have zero routing utility and are omitted
from the binary loss, not from evaluation or scaler estimation. The utility is
corrections minus lambda times new SSL errors, not macro-F1.

Ordinary gate: lambda=1. Risk-sensitive gate: lambda=2, fixed as a simple
two-to-one harm cost BEFORE new outcomes. No other penalties, thresholds or
seeds will be tried. Weight each eligible example by inverse total training
clip count of its singer; multiply SSL-only examples by lambda, then normalize
the eligible weights to sum to the eligible sample count for each fit. This
keeps the L2 weight scale comparable while changing the specified relative cost.
It is not class balancing. The same all-OOF StandardScaler is used by both gates.

Use scikit-learn LogisticRegression, L2 (l1_ratio=0), C=1.0, lbfgs,
fit_intercept=True, max_iter=2000, tol=1e-8, random_state=20261116; one CPU
thread. Seven coefficients and one intercept per gate. If either target class
is absent, use a documented SSL-only fallback rather than a new fitting recipe.
Convergence warnings or nonfinite outputs stop the experiment, preserving files.

## Comparators and reporting

Report all six methods: saved calibrated acoustic, saved calibrated SSL, saved
static late fusion, a simple maximum-calibrated-confidence gate (ties to SSL),
ordinary learned gate and risk-sensitive learned gate. Confidence gating is a
fixed baseline with no training. Learned gate probabilities are the selected
branch's existing calibrated probabilities, not a newly calibrated gate score.

Report all schedules, all singers and all true classes: pooled macro-F1/accuracy,
singer macro-F1/accuracy, SSL corrections, introduced SSL errors, net correctness,
override rate, acoustic-only opportunity capture, and both-wrong corrections.
Keep zero and undefined denominators. Report NLL/Brier descriptively, not as an
additional optimized endpoint. Preserve each gate's coefficients and every
clip-level decision, including losses and adverse true-class changes.

After prediction sealing only, descriptively count which of the previous
24/21/19 blocked missed opportunities are recovered by each method. This is
retrospective stratification, not evidence of a causal mechanism or a training
feature. Also report all 43/39/36 previously missed opportunities and harmed
SSL-only cases; no favorable subgroup is selected for inference.

## Fixed inference family and decision criteria

Average the three schedules WITHIN singer for each metric, then compare 20
paired singer means. Schedules, clips and conflict pairs are not independent
replicates. Use 10,000 singer bootstrap draws (seed 2026111601), pointwise 95%
percentile intervals, and the existing two-sided exact sign-flip test with its
conservative (tail+1)/(2^20+1) convention. Apply Holm to these SIX contrasts:

1. Risk-sensitive minus ordinary gate macro-F1 (primary performance contrast).
2. Risk-sensitive minus ordinary gate new-error rate per all singer clips
   (primary safety contrast; negative means fewer introduced errors).
3. Risk-sensitive minus saved SSL macro-F1.
4. Risk-sensitive minus saved static fusion macro-F1.
5. Risk-sensitive minus confidence gate macro-F1.
6. Ordinary gate minus saved SSL macro-F1.

The old 13/37-test families remain untouched. This new six-test correction does
not erase adaptive research history or dependence from overlapping training
sets. Other metric/class/singer contrasts are descriptive; no extra subgroup
p-values, favorable-seed selection, post-hoc penalty sweep or equivalence claim.

Only characterize the penalty as an established improvement over ordinary
gating if macro-F1 increases AND new-error rate decreases, with both primary
Holm-adjusted tests <0.05. Claim improvement beyond SSL/static/confidence only
for a positive corrected contrast against that comparator. A harm reduction
with macro-F1 loss is a trade-off, not a superior recognizer; no significance
is not equivalence. All outcomes are retained and the paper-inclusion decision
is made afterward, without changing this protocol or current manuscript.

## Execution and verification

Create a new exclusive output directory, lock protocol, implementation, tests,
runtime versions and input hashes before fitting. Only 120 small logistic fits,
sequentially in one scientific worker, are authorized. Use a Windows Job owner,
below-normal priority, a 30-minute hard cap, 5-minute no-log-progress cap,
1GiB available-memory hard stop and 4GiB free-disk minimum. Require 2GiB free
memory before launch and before each fold; wait at most five minutes, then stop.
No automatic restart, extension, closing applications or power changes.

Test feature invariance, no-test-label interface, cost direction, weight scaling,
tie behavior, fallback, split isolation, no overwrite, and Job child termination
on synthetic data. A separate read-only auditor replays gate decisions from
coefficients, original probabilities and scalar feature formulas, independently
recomputes confusion counts and macro-F1, and verifies all hashes and coverage.
Check the actual worker processes have ended. Deliver complete CSVs, a concise
Chinese assessment and any proposed wording separately; do not revise the paper
or public package automatically, regardless of favorable or unfavorable results.
