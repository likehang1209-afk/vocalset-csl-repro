"""A fixed seven-feature logistic routing layer; no file or test-label input."""
from collections import Counter
import warnings

import numpy as np
from scipy.special import expit
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits


def probabilities(raw):
    p = np.asarray(raw, dtype=np.float64)
    if p.ndim != 2 or p.shape[1] != 6 or not np.isfinite(p).all() or (p < 0).any() or (p > 1).any():
        raise ValueError("Invalid six-class probabilities")
    if not np.allclose(p.sum(1), 1.0, atol=1e-9, rtol=0):
        raise ValueError("Probability sums differ")
    return p


def features(a, s):
    a, s = probabilities(a), probabilities(s)
    if a.shape != s.shape:
        raise ValueError("Unaligned branches")
    ap, sp = np.sort(a, axis=1), np.sort(s, axis=1)
    la, ls = np.log(np.maximum(a, 1e-12)), np.log(np.maximum(s, 1e-12))
    midpoint = (a + s) / 2
    lm = np.log(np.maximum(midpoint, 1e-12))
    entropy_a = -(a * la).sum(1) / np.log(6)
    entropy_s = -(s * ls).sum(1) / np.log(6)
    js = ((a * (la - lm)).sum(1) + (s * (ls - lm)).sum(1)) / (2 * np.log(2))
    return np.column_stack((ap[:, -1], sp[:, -1], ap[:, -1] - ap[:, -2],
                            sp[:, -1] - sp[:, -2], entropy_a, entropy_s, js))


def sample_weights(groups, eligible, targets, cost):
    counts = Counter(groups)
    weights = np.array([1.0 / counts[g] for g in groups], dtype=float)[eligible]
    weights *= np.where(targets == 0, cost, 1.0)
    if not len(weights):
        return weights
    return weights * (len(weights) / weights.sum())


def fit_gates(training, protocol):
    allowed = {"seed", "fold", "held_singer", "clip_ids", "singers", "y", "acoustic_oof", "ssl_oof"}
    if set(training) != allowed:
        raise ValueError("Training interface includes unexpected fields")
    a, s = probabilities(training["acoustic_oof"]), probabilities(training["ssl_oof"])
    y = np.asarray(training["y"], dtype=int)
    groups = training["singers"]
    n = len(y)
    if a.shape != s.shape or len(a) != n or len(groups) != n or len(training["clip_ids"]) != n:
        raise ValueError("Training alignment differs")
    if training["held_singer"] in groups or len(set(training["clip_ids"])) != n:
        raise ValueError("Held-out singer or duplicate ID in training")
    if not np.isin(y, np.arange(6)).all():
        raise ValueError("Invalid training target")
    x = features(a, s)
    scaler = StandardScaler().fit(x)
    z = scaler.transform(x)
    ca, cs = a.argmax(1) == y, s.argmax(1) == y
    eligible = ca != cs
    target = ca[eligible].astype(int)
    result = {"seed": training["seed"], "fold": training["fold"], "held_singer": training["held_singer"],
              "training_rows": n, "eligible_rows": int(eligible.sum()),
              "acoustic_only_training": int(target.sum()), "ssl_only_training": int((target == 0).sum()),
              "scaler_mean": scaler.mean_.tolist(), "scaler_scale": scaler.scale_.tolist(), "models": {}}
    for name, cost in protocol["gate_costs"].items():
        weights = sample_weights(groups, eligible, target, cost)
        if len(np.unique(target)) < 2:
            record = {"fallback": "ssl_only_missing_target_class", "coefficients": [0.0] * 7,
                      "intercept": 0.0, "iterations": 0, "cost": cost, "sample_weight_sum": float(weights.sum())}
        else:
            with warnings.catch_warnings(record=True) as caught, threadpool_limits(limits=1):
                warnings.simplefilter("always")
                model = LogisticRegression(**protocol["logistic"])
                model.fit(z[eligible], target, sample_weight=weights)
            if any(issubclass(w.category, ConvergenceWarning) for w in caught):
                raise RuntimeError("Gate convergence warning; no alternative fit is allowed")
            if caught:
                raise RuntimeError("Unexpected estimator warning: " + "; ".join(str(w.message) for w in caught))
            if model.coef_.shape != (1, 7) or model.classes_.tolist() != [0, 1]:
                raise ValueError("Unexpected fitted gate shape")
            if not np.isfinite(model.coef_).all() or not np.isfinite(model.intercept_).all():
                raise ValueError("Nonfinite fitted coefficients")
            record = {"fallback": None, "coefficients": model.coef_[0].tolist(),
                      "intercept": float(model.intercept_[0]), "iterations": int(model.n_iter_[0]),
                      "cost": cost, "sample_weight_sum": float(weights.sum())}
        result["models"][name] = record
    return result


def predict_gates(fitted, outer, protocol):
    expected = {"seed", "fold", "held_singer", "clip_ids", "singers", "acoustic", "ssl",
                "acoustic_calibrated", "ssl_calibrated", "static_fusion"}
    if set(outer) != expected:
        raise ValueError("Outer inference interface includes labels or unexpected fields")
    if any(fitted[k] != outer[k] for k in ("seed", "fold", "held_singer")):
        raise ValueError("Wrong fold model")
    a, s = probabilities(outer["acoustic"]), probabilities(outer["ssl"])
    ac, sc = probabilities(outer["acoustic_calibrated"]), probabilities(outer["ssl_calibrated"])
    static = probabilities(outer["static_fusion"])
    if not (a.shape == s.shape == ac.shape == sc.shape == static.shape):
        raise ValueError("Outer shapes differ")
    if set(outer["singers"]) != {outer["held_singer"]} or len(outer["clip_ids"]) != len(a):
        raise ValueError("Outer singer or row alignment differs")
    if not np.array_equal(a.argmax(1), ac.argmax(1)) or not np.array_equal(s.argmax(1), sc.argmax(1)):
        raise ValueError("Archived calibration changed top-1")
    z = (features(a, s) - np.array(fitted["scaler_mean"])) / np.array(fitted["scaler_scale"])
    disagree = a.argmax(1) != s.argmax(1)
    probabilities_out = {"acoustic": ac.tolist(), "ssl": sc.tolist(), "static_fusion": static.tolist()}
    selected, scores = {}, {}
    selected["confidence_gate"] = disagree & (ac.max(1) > sc.max(1))
    for name, model in fitted["models"].items():
        q = expit(z @ np.array(model["coefficients"]) + model["intercept"])
        route = disagree & (q > protocol["threshold"])
        if model["fallback"] is not None:
            route[:] = False
        scores[name] = q.tolist()
        selected[name] = route
    for name, route in selected.items():
        probabilities_out[name] = np.where(route[:, None], ac, sc).tolist()
    return {"seed": outer["seed"], "fold": outer["fold"], "held_singer": outer["held_singer"],
            "clip_ids": outer["clip_ids"], "probabilities": probabilities_out,
            "route_acoustic": {k: v.tolist() for k, v in selected.items()}, "gate_scores": scores}
