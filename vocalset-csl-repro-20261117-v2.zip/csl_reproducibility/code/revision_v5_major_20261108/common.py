"""Shared, fail-closed I/O and clip-level evaluation for the R2 comparisons."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import random
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / "src"))


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def environment():
    versions = {}
    for name in ("numpy", "scipy", "pandas", "scikit-learn", "torch", "transformers",
                 "librosa", "soundfile", "soxr", "muq", "huggingface-hub"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    return {"python": platform.python_version(), "platform": platform.platform(),
            "versions": versions}


def source_hashes():
    paths = list(ROOT.glob("*.py"))
    paths += list((ROOT/"upstream/musicfm").rglob("*.py"))
    paths += list((PROJECT/"src/vocalset_csl").glob("*.py"))
    return {p.relative_to(PROJECT).as_posix(): file_hash(p) for p in sorted(paths)}


def verify_model_folder(folder, cfg):
    lock = read_json(Path(folder)/"revision_lock.json")
    if lock["config"] != cfg or not lock.get("files"):
        raise ValueError("Checkpoint revision is not locked")
    for name, expected in lock["files"].items():
        if file_hash(Path(folder)/name) != expected:
            raise ValueError(f"Checkpoint file changed: {name}")


def load_plan(path):
    plan = read_json(path)
    fingerprint = plan.pop("fingerprint")
    if digest(plan) != fingerprint:
        raise ValueError("Plan fingerprint mismatch")
    plan["fingerprint"] = fingerprint
    validate_plan(plan)
    return plan


def validate_plan(plan):
    rows = plan["clips"]
    ids = [r["clip_id"] for r in rows]
    hashes = [r["content_sha256"] for r in rows]
    if len(ids) != len(set(ids)) or len(hashes) != len(set(hashes)):
        raise ValueError("Duplicate recording identity/content")
    all_ids = set(ids)
    groups = {r["clip_id"]: r["singer_id"] for r in rows}
    labels = {r["clip_id"]: r["target"] for r in rows}
    expected_labels = set(range(len(plan["labels"])))
    seen = []
    for outer in plan["folds"]:
        train, test = set(outer["train"]), set(outer["test"])
        _check_split(train, test, all_ids, groups)
        if {groups[i] for i in test} != {outer["held_singer"]}:
            raise ValueError("Outer singer mismatch")
        seen.extend(outer["test"])
        inner_seen = []
        for inner in outer["inner"]:
            tr, va = set(inner["train"]), set(inner["validation"])
            _check_split(tr, va, train, groups)
            if {labels[i] for i in tr} != expected_labels:
                raise ValueError("A training fold lacks a class")
            inner_seen.extend(inner["validation"])
        if sorted(inner_seen) != sorted(train):
            raise ValueError("Inner validation does not cover training clips exactly once")
    if sorted(seen) != sorted(ids):
        raise ValueError("Outer test coverage must be exactly once")


def _check_split(train, test, universe, groups):
    if not train or not test or train & test or train | test != universe:
        raise ValueError("Invalid clip partition")
    if {groups[i] for i in train} & {groups[i] for i in test}:
        raise ValueError("Singer leakage")


def load_segments(directory, plan):
    directory = Path(directory)
    meta = read_json(directory / "segments.json")
    signed = dict(meta)
    fingerprint = signed.pop("fingerprint")
    if digest(signed) != fingerprint:
        raise ValueError("Segment metadata fingerprint mismatch")
    if meta["plan_fingerprint"] != plan["fingerprint"]:
        raise ValueError("Segment cache uses a different plan")
    if meta["protocol_hash"] != digest(plan["protocol"]):
        raise ValueError("Segment cache uses a different protocol")
    if set(r["clip_id"] for r in meta["segments"]) != set(r["clip_id"] for r in plan["clips"]):
        raise ValueError("Segment cache does not cover the canonical clips")
    return meta


def segment_indices(meta, clip_ids):
    wanted = set(clip_ids)
    return np.array([i for i, r in enumerate(meta["segments"]) if r["clip_id"] in wanted], dtype=int)


def clip_probabilities(probabilities, segment_clip_ids, clip_order):
    probabilities = np.asarray(probabilities, dtype=np.float64)
    if probabilities.ndim != 2 or len(probabilities) != len(segment_clip_ids):
        raise ValueError("Probability/segment shape mismatch")
    if not np.isfinite(probabilities).all() or (probabilities < 0).any():
        raise ValueError("Invalid probabilities")
    if not np.allclose(probabilities.sum(1), 1, atol=1e-5):
        raise ValueError("Probabilities must sum to one")
    if len(set(clip_order)) != len(clip_order) or set(segment_clip_ids) != set(clip_order):
        raise ValueError("Clip coverage mismatch")
    return np.stack([probabilities[np.asarray(segment_clip_ids) == clip].mean(0)
                     for clip in clip_order])


def seed_everything(seed):
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def report_record(plan, fold, method, clip_ids, probabilities, details, seconds):
    from vocalset_csl.metrics import classification_metrics
    targets = {r["clip_id"]: r["target"] for r in plan["clips"]}
    y = np.array([targets[i] for i in clip_ids])
    return {"plan_fingerprint": plan["fingerprint"], "source_hashes": source_hashes(),
            "environment": environment(), "fold": fold["fold"], "method": method,
            "held_singer": fold["held_singer"], "clip_ids": clip_ids,
            "labels": plan["labels"], "y_true": y.tolist(),
            "probabilities": np.asarray(probabilities).tolist(),
            "metrics": classification_metrics(y, probabilities, len(plan["labels"])),
            "details": details, "seconds": seconds}
