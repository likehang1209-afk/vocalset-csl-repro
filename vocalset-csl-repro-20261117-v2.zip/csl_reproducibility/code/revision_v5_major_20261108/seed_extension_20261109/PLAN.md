# Three training schedules

Seeds20261108,30261108,40261108; six complete recipes, twenty singers each.
Inner/outer assignments, candidates and recipes fixed. Repeat all inner selection, not just a historical winner.
Two added schedules were fixed after initial outcomes were known. Not preregistration or external confirmation.
Average scores within singer; twenty units, not sixty. Report all outcomes.
