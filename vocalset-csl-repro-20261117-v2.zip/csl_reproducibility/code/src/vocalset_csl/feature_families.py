"""Auditable grouping of named acoustic descriptors for permutation tests."""

from __future__ import annotations

from collections import defaultdict


def feature_family(name: str) -> str:
    value = name.lower()
    if "duration" in value or "voiced_fraction" in value:
        return "temporal_voicing"
    if any(token in value for token in ("f0", "pitch", "vibrato", "jitter")):
        return "pitch_modulation"
    if any(token in value for token in ("loudness", "rms", "shimmer", "energy")):
        return "energy_dynamics"
    if any(token in value for token in ("formant", "f1frequency", "f2frequency", "f3frequency")):
        return "formant_resonance"
    if any(token in value for token in ("hnr", "harmonic", "hammarberg", "zcr", "flatness")):
        return "voice_quality_noise"
    if any(token in value for token in ("mfcc", "alpharatio", "spectralslope")):
        return "spectral_envelope_cepstral"
    if any(
        token in value
        for token in ("spectral", "rolloff", "centroid", "bandwidth", "flux", "contrast")
    ):
        return "spectral_shape"
    return "other_descriptors"


def group_feature_indices(feature_names: list[str]) -> dict[str, list[int]]:
    groups: dict[str, list[int]] = defaultdict(list)
    for index, name in enumerate(feature_names):
        groups[feature_family(name)].append(index)
    return dict(sorted(groups.items()))

