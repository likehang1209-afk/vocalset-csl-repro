"""Singer-clustered paired uncertainty for LOSO comparisons."""

from __future__ import annotations

import numpy as np


def paired_cluster_bootstrap(
    differences: np.ndarray,
    replicates: int = 10000,
    seed: int = 20260825,
) -> dict[str, float | int]:
    values = np.asarray(differences, dtype=np.float64)
    if values.ndim != 1 or len(values) < 2:
        raise ValueError("differences must contain at least two singer-level values")
    rng = np.random.default_rng(seed)
    samples = rng.choice(values, size=(replicates, len(values)), replace=True).mean(axis=1)
    return {
        "cluster_count": len(values),
        "mean_difference": float(values.mean()),
        "ci95_low": float(np.percentile(samples, 2.5)),
        "ci95_high": float(np.percentile(samples, 97.5)),
        "bootstrap_probability_positive": float(np.mean(samples > 0)),
        "replicates": int(replicates),
    }


def paired_sign_flip_pvalue(
    differences: np.ndarray,
    seed: int = 20260826,
    monte_carlo_replicates: int = 200000,
) -> float:
    values = np.asarray(differences, dtype=np.float64)
    observed = abs(float(values.mean()))
    n = len(values)
    if n <= 20:
        means = np.empty(2**n, dtype=np.float64)
        bit_positions = np.arange(n, dtype=np.uint64)
        chunk_size = 65536
        for start in range(0, 2**n, chunk_size):
            stop = min(start + chunk_size, 2**n)
            integers = np.arange(start, stop, dtype=np.uint64)[:, None]
            signs = 2.0 * ((integers >> bit_positions) & 1).astype(np.float64) - 1.0
            means[start:stop] = (signs * values).mean(axis=1)
    else:
        rng = np.random.default_rng(seed)
        signs = rng.choice((-1.0, 1.0), size=(monte_carlo_replicates, n))
        means = (signs * values).mean(axis=1)
    return float((np.count_nonzero(np.abs(means) >= observed) + 1) / (len(means) + 1))
