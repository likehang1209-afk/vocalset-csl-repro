"""Fixed-label classification and calibration metrics."""

from __future__ import annotations

from itertools import pairwise

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score


def normalize_probabilities(probability: np.ndarray) -> np.ndarray:
    probability = np.asarray(probability, dtype=np.float64)
    if probability.ndim != 2:
        raise ValueError("probability must be a two-dimensional array")
    probability = np.clip(probability, 1e-12, None)
    return probability / probability.sum(axis=1, keepdims=True)


def multiclass_brier(y_true: np.ndarray, probability: np.ndarray, class_count: int) -> float:
    target = np.eye(class_count, dtype=np.float64)[np.asarray(y_true, dtype=int)]
    return float(np.mean(np.sum((probability - target) ** 2, axis=1)))


def expected_calibration_error(
    y_true: np.ndarray, probability: np.ndarray, bins: int = 15
) -> float:
    y_true = np.asarray(y_true, dtype=int)
    prediction = probability.argmax(axis=1)
    confidence = probability.max(axis=1)
    correct = prediction == y_true
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for index, (lower, upper) in enumerate(pairwise(edges)):
        include_upper = index == bins - 1
        mask = (confidence >= lower) & (
            (confidence <= upper) if include_upper else (confidence < upper)
        )
        if mask.any():
            ece += mask.mean() * abs(float(correct[mask].mean()) - float(confidence[mask].mean()))
    return float(ece)


def classification_metrics(
    y_true: np.ndarray,
    probability: np.ndarray,
    class_count: int,
    ece_bins: int = 15,
) -> dict[str, object]:
    y_true = np.asarray(y_true, dtype=int)
    probability = normalize_probabilities(probability)
    if probability.shape != (len(y_true), class_count):
        raise ValueError(
            f"Expected probability shape {(len(y_true), class_count)}, got {probability.shape}"
        )
    labels = np.arange(class_count)
    prediction = probability.argmax(axis=1)
    support = np.bincount(y_true, minlength=class_count)
    present = labels[support > 0]
    confusion = confusion_matrix(y_true, prediction, labels=labels)
    return {
        "sample_count": len(y_true),
        "present_class_count": len(present),
        "accuracy": float(accuracy_score(y_true, prediction)),
        "macro_f1_present": float(
            f1_score(y_true, prediction, labels=present, average="macro", zero_division=0)
        ),
        "macro_f1_global": float(
            f1_score(y_true, prediction, labels=labels, average="macro", zero_division=0)
        ),
        "uar_present": float(
            recall_score(y_true, prediction, labels=present, average="macro", zero_division=0)
        ),
        "uar_global": float(
            recall_score(y_true, prediction, labels=labels, average="macro", zero_division=0)
        ),
        "nll": float(
            -np.log(np.clip(probability[np.arange(len(y_true)), y_true], 1e-12, 1.0)).mean()
        ),
        "brier": multiclass_brier(y_true, probability, class_count),
        "ece": expected_calibration_error(y_true, probability, bins=ece_bins),
        "class_support": support.tolist(),
        "confusion": confusion.tolist(),
    }


def selection_utility(metrics: dict[str, object]) -> float:
    return 0.5 * (float(metrics["macro_f1_present"]) + float(metrics["uar_present"]))
