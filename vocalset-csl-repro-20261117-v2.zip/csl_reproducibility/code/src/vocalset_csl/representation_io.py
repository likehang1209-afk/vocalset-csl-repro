"""Load fingerprinted embedding stores at predeclared normalized depths."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .feature_io import align_feature_rows, manifest_fingerprint


def depth_to_layer(depth: float, layer_count: int) -> int:
    if not 0.0 < depth <= 1.0:
        raise ValueError("Normalized depth must be in (0, 1]")
    if layer_count < 2:
        return 0
    return max(1, min(layer_count - 1, round(depth * (layer_count - 1))))


def load_embedding_store(
    root: str | Path,
    target_clip_ids: np.ndarray,
    normalized_depths: list[float],
) -> tuple[dict[str, np.ndarray], dict[str, object]]:
    root = Path(root)
    metadata = json.loads((root / "metadata.json").read_text(encoding="utf-8"))
    if not metadata.get("model_revision"):
        raise ValueError(f"Embedding store does not record a model revision: {root}")
    source_ids = np.load(root / "clip_ids.npy", allow_pickle=False).astype(str)
    if metadata.get("manifest_fingerprint") != manifest_fingerprint(source_ids):
        raise ValueError(f"Stored manifest fingerprint is invalid: {root}")
    status = np.load(root / "status.npy", allow_pickle=False)
    if not status.all():
        raise ValueError(f"Embedding store is incomplete: {int(status.sum())}/{len(status)}")
    layers = metadata["layers"]
    selected = {}
    selected_metadata = []
    for depth in normalized_depths:
        layer_index = depth_to_layer(float(depth), len(layers))
        layer = layers[layer_index]
        values = np.load(root / layer["file"], mmap_mode="r")
        aligned = align_feature_rows(target_clip_ids, source_ids, values)
        name = f"depth_{depth:.2f}_layer_{layer_index:02d}"
        selected[name] = np.asarray(aligned, dtype=np.float32)
        selected_metadata.append(
            {"normalized_depth": float(depth), "layer_index": layer_index, "dimension": values.shape[1]}
        )
    return selected, {**metadata, "selected_layers": selected_metadata}


def load_multiple_embedding_stores(
    embedding_root: str | Path,
    model_keys: list[str],
    target_clip_ids: np.ndarray,
    normalized_depths: list[float],
) -> tuple[dict[str, np.ndarray], dict[str, object]]:
    representations = {}
    metadata = {}
    for model_key in model_keys:
        values, model_metadata = load_embedding_store(
            Path(embedding_root) / model_key,
            target_clip_ids,
            normalized_depths,
        )
        for layer_name, matrix in values.items():
            representations[f"{model_key}__{layer_name}"] = matrix
        metadata[model_key] = model_metadata
    return representations, metadata
