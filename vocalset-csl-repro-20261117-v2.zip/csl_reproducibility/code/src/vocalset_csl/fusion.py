"""Calibrated probability pooling and inner-only configuration selection."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .metrics import classification_metrics, normalize_probabilities, selection_utility


@dataclass(frozen=True)
class FusionChoice:
    family: str
    acoustic_weight: float
    inner_utility: float
    inner_nll: float


def fuse_probabilities(
    acoustic: np.ndarray,
    ssl: np.ndarray,
    acoustic_weight: float,
    family: str = "arithmetic",
) -> np.ndarray:
    if not 0.0 <= acoustic_weight <= 1.0:
        raise ValueError("acoustic_weight must be in [0, 1]")
    acoustic = normalize_probabilities(acoustic)
    ssl = normalize_probabilities(ssl)
    if acoustic.shape != ssl.shape:
        raise ValueError(f"Probability shapes differ: {acoustic.shape} and {ssl.shape}")
    if family == "arithmetic":
        fused = acoustic_weight * acoustic + (1.0 - acoustic_weight) * ssl
    elif family == "geometric":
        log_fused = acoustic_weight * np.log(np.clip(acoustic, 1e-12, 1.0))
        log_fused += (1.0 - acoustic_weight) * np.log(np.clip(ssl, 1e-12, 1.0))
        log_fused -= log_fused.max(axis=1, keepdims=True)
        fused = np.exp(log_fused)
    else:
        raise ValueError(f"Unknown fusion family: {family}")
    return normalize_probabilities(fused)


def select_fusion(
    y_true: np.ndarray,
    acoustic: np.ndarray,
    ssl: np.ndarray,
    class_count: int,
    families: tuple[str, ...] = ("arithmetic", "geometric"),
    weights: tuple[float, ...] = tuple(np.linspace(0.0, 1.0, 11)),
) -> FusionChoice:
    candidates = []
    for family in families:
        for weight in weights:
            probability = fuse_probabilities(acoustic, ssl, float(weight), family)
            metrics = classification_metrics(y_true, probability, class_count)
            utility = selection_utility(metrics)
            candidates.append(
                FusionChoice(
                    family=family,
                    acoustic_weight=float(weight),
                    inner_utility=utility,
                    inner_nll=float(metrics["nll"]),
                )
            )
    return min(
        candidates,
        key=lambda item: (
            -item.inner_utility,
            item.inner_nll,
            abs(item.acoustic_weight - 0.5),
            item.family,
        ),
    )
