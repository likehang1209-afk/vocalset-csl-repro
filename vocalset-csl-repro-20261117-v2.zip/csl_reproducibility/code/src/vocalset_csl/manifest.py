"""Parse VocalSet paths into an auditable canonical manifest."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable
from pathlib import Path, PurePosixPath

import pandas as pd

TECHNIQUES = (
    "fast_forte",
    "fast_piano",
    "slow_forte",
    "slow_piano",
    "vocal_fry",
    "lip_trill",
    "messa_di_voce",
    "pianissimo",
    "breathy",
    "inhaled",
    "straight",
    "vibrado",
    "vibrato",
    "trillo",
    "trill",
    "spoken",
    "forte",
    "messa",
    "belt",
    "pp",
)

LABEL_ALIASES = {
    "vibrado": "vibrato",
    "pianissimo": "pp",
    "messa_di_voce": "messa",
}

PRODUCTION_TECHNIQUES = {
    "belt",
    "breathy",
    "inhaled",
    "lip_trill",
    "spoken",
    "straight",
    "trill",
    "trillo",
    "vibrato",
    "vocal_fry",
}

EXERCISE_CONDITIONS = {
    "fast_forte",
    "fast_piano",
    "forte",
    "messa",
    "pp",
    "slow_forte",
    "slow_piano",
}

CONTEXT_PATTERNS = {
    "arpeggio": ("arpeggio", "arpeggios"),
    "scale": ("scale", "scales"),
    "long_tone": ("long_tone", "long_tones", "longtone", "long"),
    "excerpt": ("excerpt", "excerpts", "caro", "row"),
}


def _normalise(value: str) -> str:
    value = value.lower().replace("\\", "/")
    value = re.sub(r"[^a-z0-9/]+", "_", value)
    return re.sub(r"_+", "_", value).strip("_")


def _token_present(text: str, token: str) -> bool:
    # Metadata may occur either in the official directory hierarchy or in the
    # filename. Treat path separators as token boundaries as well as underscores.
    return re.search(rf"(?:^|[/_]){re.escape(token)}(?:[/_]|$)", text) is not None


def _find_singer(text: str) -> str | None:
    match = re.search(r"(?:^|[/_])(female|male|f|m)0?(\d{1,2})(?:[/_]|$)", text)
    if not match:
        return None
    prefix = "f" if match.group(1).startswith("f") else "m"
    return f"{prefix}{int(match.group(2))}"


def _find_context(text: str) -> str | None:
    for context, aliases in CONTEXT_PATTERNS.items():
        if any(_token_present(text, alias) for alias in aliases):
            return context
    return None


def _find_label(text: str) -> tuple[str | None, str | None]:
    for raw in TECHNIQUES:
        if _token_present(text, raw):
            return raw, LABEL_ALIASES.get(raw, raw)
    return None, None


def _find_vowel(stem: str) -> str | None:
    tokens = [token for token in _normalise(stem).split("_") if token]
    for token in reversed(tokens):
        if token in {"a", "e", "i", "o", "u"}:
            return token
    return None


def _canonical_path(path: PurePosixPath) -> str:
    """Strip machine-specific prefixes while retaining the official singer tree."""

    singer_directory = re.compile(r"(?:female|male|f|m)0?\d{1,2}", re.IGNORECASE)
    for index, part in enumerate(path.parts):
        if singer_directory.fullmatch(part):
            return PurePosixPath(*path.parts[index:]).as_posix()
    return path.as_posix()


def classify_label(label: str | None) -> str:
    if label in PRODUCTION_TECHNIQUES:
        return "production_technique"
    if label in EXERCISE_CONDITIONS:
        return "exercise_condition"
    return "unresolved"


def parse_vocalset_path(path: str | Path) -> dict[str, object]:
    """Parse metadata encoded by a VocalSet path or filename.

    The parser accepts Windows paths and archive paths. It does not silently
    discard unresolved fields; callers should audit `parse_ok` and
    `raw_label != label` before modeling.
    """

    raw = str(path).replace("\\", "/")
    pure = PurePosixPath(raw)
    canonical_path = _canonical_path(pure)
    normalised = _normalise(raw)
    singer = _find_singer(normalised)
    raw_label, label = _find_label(normalised)
    context = _find_context(normalised)
    vowel = _find_vowel(pure.stem)
    key_match = re.search(r"(?:^|_)([cf])(?:_|$)", _normalise(pure.stem))

    return {
        "path": raw,
        "canonical_path": canonical_path,
        "file_name": pure.name,
        "clip_id": hashlib.sha1(canonical_path.encode("utf-8")).hexdigest()[:16],
        "singer_id": singer,
        "raw_label": raw_label,
        "label": label,
        "label_family": classify_label(label),
        "context": context,
        "vowel": vowel,
        "key": key_match.group(1).upper() if key_match else None,
        "parse_ok": singer is not None and label is not None and context is not None,
    }


def build_manifest(paths: Iterable[str | Path]) -> pd.DataFrame:
    frame = pd.DataFrame(parse_vocalset_path(path) for path in paths)
    if frame.empty:
        return frame
    return frame.sort_values(["singer_id", "label", "context", "path"], na_position="last").reset_index(
        drop=True
    )


def content_md5(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.md5()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()
