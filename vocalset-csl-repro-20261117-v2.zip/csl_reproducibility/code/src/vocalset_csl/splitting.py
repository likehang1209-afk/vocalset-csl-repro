"""Singer-disjoint outer and inner split utilities."""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold


@dataclass(frozen=True)
class Split:
    split_id: str
    train: np.ndarray
    test: np.ndarray


def assert_group_disjoint(train: np.ndarray, test: np.ndarray, groups: np.ndarray) -> None:
    overlap = set(groups[train]).intersection(groups[test])
    if overlap:
        raise ValueError(f"Group leakage detected: {sorted(overlap)}")


def leave_one_group_out(groups: np.ndarray) -> Iterator[Split]:
    groups = np.asarray(groups)
    for group in sorted(np.unique(groups).tolist()):
        test = np.flatnonzero(groups == group)
        train = np.flatnonzero(groups != group)
        assert_group_disjoint(train, test, groups)
        yield Split(split_id=f"loso_{group}", train=train, test=test)


def stratified_group_folds(
    y: np.ndarray,
    groups: np.ndarray,
    n_splits: int,
    seed: int,
    prefix: str = "inner",
) -> list[Split]:
    y = np.asarray(y)
    groups = np.asarray(groups)
    unique_groups = np.unique(groups)
    if len(unique_groups) < n_splits:
        raise ValueError(f"Need at least {n_splits} groups, got {len(unique_groups)}")
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    folds = []
    dummy = np.zeros((len(y), 1), dtype=np.float32)
    for fold, (train, test) in enumerate(splitter.split(dummy, y, groups)):
        train = np.asarray(train, dtype=int)
        test = np.asarray(test, dtype=int)
        assert_group_disjoint(train, test, groups)
        folds.append(Split(f"{prefix}_{fold}", train, test))
    return folds


def repeated_stratified_group_folds(
    y: np.ndarray,
    groups: np.ndarray,
    n_splits: int,
    repeats: int,
    seed: int,
) -> list[Split]:
    output = []
    for repeat in range(repeats):
        output.extend(
            stratified_group_folds(
                y,
                groups,
                n_splits=n_splits,
                seed=seed + repeat,
                prefix=f"r{repeat}",
            )
        )
    return output


def count_test_occurrences(splits: list[Split], sample_count: int) -> np.ndarray:
    counts = np.zeros(sample_count, dtype=int)
    for split in splits:
        counts[split.test] += 1
    return counts
