"""Resume-safe all-layer extraction for audio and music foundation models."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from .feature_io import manifest_fingerprint


def window_audio(
    audio: np.ndarray,
    sample_rate: int,
    window_seconds: float,
    hop_seconds: float,
) -> tuple[np.ndarray, np.ndarray]:
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    window = round(window_seconds * sample_rate)
    hop = round(hop_seconds * sample_rate)
    if window <= 0 or hop <= 0:
        raise ValueError("Window and hop lengths must be positive")
    if len(audio) == 0:
        raise ValueError("Cannot extract an empty audio clip")
    starts = list(range(0, max(1, len(audio) - window + 1), hop))
    final_start = max(0, len(audio) - window)
    if starts[-1] != final_start:
        starts.append(final_start)
    windows = np.zeros((len(starts), window), dtype=np.float32)
    lengths = np.zeros(len(starts), dtype=np.int64)
    for index, start in enumerate(starts):
        chunk = audio[start : start + window]
        windows[index, : len(chunk)] = chunk
        lengths[index] = len(chunk)
    return windows, lengths


def pool_hidden_frames(frames: list[np.ndarray]) -> np.ndarray:
    if not frames:
        raise ValueError("No hidden frames were supplied")
    values = np.concatenate(frames, axis=0).astype(np.float64)
    return np.concatenate([values.mean(axis=0), values.std(axis=0)]).astype(np.float32)


def valid_hidden_frames(
    hidden: np.ndarray, valid_samples: np.ndarray, window_samples: int
) -> list[np.ndarray]:
    hidden = np.asarray(hidden)
    output = []
    for sequence, samples in zip(hidden, valid_samples):
        valid_steps = max(1, math.ceil(sequence.shape[0] * int(samples) / window_samples))
        output.append(sequence[:valid_steps])
    return output


class MockBackend:
    """CPU-only deterministic backend used to test orchestration without torch."""

    def __init__(self, sample_rate: int = 16000):
        self.sample_rate = sample_rate
        self.model_id = "mock/deterministic"

    def extract(
        self,
        windows: np.ndarray,
        valid_lengths: np.ndarray,
        batch_size: int,
    ) -> list[np.ndarray]:
        del batch_size
        frame_count = 20
        frame_width = windows.shape[1] // frame_count
        trimmed = windows[:, : frame_count * frame_width]
        frames = trimmed.reshape(len(windows), frame_count, frame_width)
        base = np.stack(
            [
                frames.mean(axis=2),
                frames.std(axis=2),
                np.max(frames, axis=2),
                np.min(frames, axis=2),
            ],
            axis=2,
        )
        layers = [base, np.tanh(2.0 * base), np.square(base)]
        return [
            pool_hidden_frames(valid_hidden_frames(layer, valid_lengths, windows.shape[1]))
            for layer in layers
        ]


class TransformersBackend:
    def __init__(
        self,
        model_id: str,
        model_revision: str,
        sample_rate: int,
        device: str,
        precision: str,
    ):
        import torch
        from transformers import AutoFeatureExtractor, AutoModel

        self.torch = torch
        self.sample_rate = sample_rate
        self.model_id = model_id
        self.model_revision = model_revision
        self.device = device
        self.precision = precision
        self.processor = AutoFeatureExtractor.from_pretrained(
            model_id,
            revision=model_revision,
            trust_remote_code=True,
        )
        self.model = AutoModel.from_pretrained(
            model_id,
            revision=model_revision,
            trust_remote_code=True,
            output_hidden_states=True,
        ).to(device)
        self.model.eval()

    def extract(
        self,
        windows: np.ndarray,
        valid_lengths: np.ndarray,
        batch_size: int,
    ) -> list[np.ndarray]:
        torch = self.torch
        layer_frames: list[list[np.ndarray]] | None = None
        for start in range(0, len(windows), batch_size):
            stop = min(start + batch_size, len(windows))
            batch = windows[start:stop]
            lengths = valid_lengths[start:stop]
            unpadded = [item[: int(length)] for item, length in zip(batch, lengths)]
            inputs = self.processor(
                unpadded,
                sampling_rate=self.sample_rate,
                return_tensors="pt",
                padding=True,
            )
            padded_samples = int(inputs["input_values"].shape[-1])
            if "attention_mask" in inputs and np.all(lengths == padded_samples):
                # WavLM warns when a redundant all-valid mask is supplied.
                inputs.pop("attention_mask")
            inputs = {key: value.to(self.device) for key, value in inputs.items()}
            use_fp16 = self.precision == "fp16" and self.device.startswith("cuda")
            with torch.inference_mode(), torch.autocast(
                device_type="cuda" if self.device.startswith("cuda") else "cpu",
                dtype=torch.float16,
                enabled=use_fp16,
            ):
                output = self.model(**inputs, output_hidden_states=True)
            hidden_states = output.hidden_states
            if layer_frames is None:
                layer_frames = [[] for _ in hidden_states]
            if len(hidden_states) != len(layer_frames):
                raise RuntimeError("Model hidden-state count changed during extraction")
            for layer_index, hidden in enumerate(hidden_states):
                array = hidden.detach().float().cpu().numpy()
                layer_frames[layer_index].extend(
                    valid_hidden_frames(array, lengths, padded_samples)
                )
        assert layer_frames is not None
        return [pool_hidden_frames(frames) for frames in layer_frames]


class MuQBackend:
    def __init__(
        self,
        model_id: str,
        model_revision: str,
        sample_rate: int,
        device: str,
    ):
        import torch
        from muq import MuQ

        self.torch = torch
        self.sample_rate = sample_rate
        self.model_id = model_id
        self.model_revision = model_revision
        self.device = device
        self.model = MuQ.from_pretrained(model_id, revision=model_revision).to(device).eval()

    def extract(
        self,
        windows: np.ndarray,
        valid_lengths: np.ndarray,
        batch_size: int,
    ) -> list[np.ndarray]:
        torch = self.torch
        layer_frames: list[list[np.ndarray]] | None = None
        for start in range(0, len(windows), batch_size):
            stop = min(start + batch_size, len(windows))
            batch = windows[start:stop]
            lengths = valid_lengths[start:stop]
            # Extraction is clip-wise, so all windows are full-length except a
            # single short-clip window. Avoid exposing that model to zero padding.
            valid_samples = int(lengths.max())
            tensor = torch.from_numpy(batch[:, :valid_samples]).to(self.device)
            with torch.inference_mode():
                output = self.model(tensor, output_hidden_states=True)
            hidden_states = output.hidden_states
            if layer_frames is None:
                layer_frames = [[] for _ in hidden_states]
            for layer_index, hidden in enumerate(hidden_states):
                array = hidden.detach().float().cpu().numpy()
                layer_frames[layer_index].extend(
                    valid_hidden_frames(array, lengths, valid_samples)
                )
        assert layer_frames is not None
        return [pool_hidden_frames(frames) for frames in layer_frames]


def build_backend(
    backend: str,
    model_id: str,
    model_revision: str,
    sample_rate: int,
    device: str,
    precision: str,
):
    if backend == "mock":
        return MockBackend(sample_rate=sample_rate)
    if backend == "transformers":
        return TransformersBackend(
            model_id,
            model_revision,
            sample_rate,
            device,
            precision,
        )
    if backend == "muq":
        if precision != "fp32":
            raise ValueError("MuQ extraction is locked to fp32 because its authors warn about fp16 NaNs")
        return MuQBackend(model_id, model_revision, sample_rate, device)
    raise ValueError(f"Unknown extraction backend: {backend}")


class EmbeddingStore:
    def __init__(
        self,
        root: str | Path,
        clip_ids: np.ndarray,
        model_id: str,
        model_revision: str,
        sample_rate: int,
        window_seconds: float,
        hop_seconds: float,
    ):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.clip_ids = np.asarray(clip_ids).astype(str)
        self.fingerprint = manifest_fingerprint(self.clip_ids)
        self.expected = {
            "model_id": model_id,
            "model_revision": model_revision,
            "sample_rate": int(sample_rate),
            "window_seconds": float(window_seconds),
            "hop_seconds": float(hop_seconds),
            "manifest_fingerprint": self.fingerprint,
            "sample_count": len(self.clip_ids),
            "pooling": "global_valid_frame_mean_and_std",
        }
        self.metadata_path = self.root / "metadata.json"
        self.status_path = self.root / "status.npy"
        self.layers: list[np.memmap] = []
        if self.metadata_path.exists():
            self._open_existing()

    def _open_existing(self) -> None:
        metadata = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        for key, value in self.expected.items():
            if metadata.get(key) != value:
                raise ValueError(f"Embedding store metadata mismatch for {key}")
        stored_ids = np.load(self.root / "clip_ids.npy", allow_pickle=False).astype(str)
        if not np.array_equal(stored_ids, self.clip_ids):
            raise ValueError("Embedding store clip order differs from the manifest")
        self.status = np.load(self.status_path, mmap_mode="r+")
        self.layers = [
            np.load(self.root / layer["file"], mmap_mode="r+") for layer in metadata["layers"]
        ]

    def initialise(self, vectors: list[np.ndarray]) -> None:
        if self.layers:
            return
        layer_metadata = []
        for index, vector in enumerate(vectors):
            file_name = f"layer_{index:02d}.npy"
            array = np.lib.format.open_memmap(
                self.root / file_name,
                mode="w+",
                dtype=np.float32,
                shape=(len(self.clip_ids), len(vector)),
            )
            array[:] = np.nan
            array.flush()
            self.layers.append(array)
            layer_metadata.append({"index": index, "file": file_name, "dimension": len(vector)})
        self.status = np.lib.format.open_memmap(
            self.status_path, mode="w+", dtype=np.bool_, shape=(len(self.clip_ids),)
        )
        self.status[:] = False
        self.status.flush()
        np.save(self.root / "clip_ids.npy", self.clip_ids)
        metadata = {**self.expected, "layers": layer_metadata}
        self.metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    def write(self, index: int, vectors: list[np.ndarray]) -> None:
        if len(vectors) != len(self.layers):
            raise ValueError("Layer count differs from the initialized embedding store")
        for target, vector in zip(self.layers, vectors):
            if target.shape[1] != len(vector):
                raise ValueError("Embedding dimension changed during extraction")
            if not np.isfinite(vector).all():
                raise ValueError(f"Embedding contains non-finite values at clip index {index}")
            target[index] = vector
            target.flush()
        self.status[index] = True
        self.status.flush()

    def complete_count(self) -> int:
        return int(np.asarray(self.status).sum()) if hasattr(self, "status") else 0
