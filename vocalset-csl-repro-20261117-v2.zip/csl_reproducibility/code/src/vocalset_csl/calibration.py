"""Temperature scaling fitted strictly on training-side probabilities."""

from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar

from .metrics import normalize_probabilities


def apply_temperature(probability: np.ndarray, temperature: float) -> np.ndarray:
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    probability = normalize_probabilities(probability)
    logits = np.log(np.clip(probability, 1e-12, 1.0)) / temperature
    logits -= logits.max(axis=1, keepdims=True)
    scaled = np.exp(logits)
    return scaled / scaled.sum(axis=1, keepdims=True)


def fit_temperature(
    y_true: np.ndarray,
    probability: np.ndarray,
    bounds: tuple[float, float] = (0.25, 4.0),
) -> float:
    y_true = np.asarray(y_true, dtype=int)
    probability = normalize_probabilities(probability)

    def objective(temperature: float) -> float:
        scaled = apply_temperature(probability, temperature)
        return float(
            -np.log(np.clip(scaled[np.arange(len(y_true)), y_true], 1e-12, 1.0)).mean()
        )

    result = minimize_scalar(objective, bounds=bounds, method="bounded")
    if not result.success:
        raise RuntimeError(f"Temperature optimization failed: {result.message}")
    return float(result.x)

