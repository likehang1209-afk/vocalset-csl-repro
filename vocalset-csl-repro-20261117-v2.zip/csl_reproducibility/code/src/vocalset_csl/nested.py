"""Strict nested LOSO evaluation for acoustic, SSL, early, and late fusion."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .calibration import apply_temperature, fit_temperature
from .fusion import fuse_probabilities, select_fusion
from .metrics import classification_metrics, selection_utility
from .modeling import (
    ModelSpec,
    aligned_probability,
    build_model,
    default_specs,
    oof_probability,
)
from .splitting import (
    Split,
    assert_group_disjoint,
    leave_one_group_out,
    stratified_group_folds,
)


def _select_candidate(
    x_by_representation: dict[str, np.ndarray],
    y: np.ndarray,
    inner_splits,
    specs: tuple[ModelSpec, ...],
    class_count: int,
    random_state: int,
) -> tuple[str, ModelSpec, np.ndarray, float]:
    ranked = []
    for representation, x in x_by_representation.items():
        for spec_index, spec in enumerate(specs):
            probability = oof_probability(
                spec,
                x,
                y,
                inner_splits,
                class_count,
                random_state + 1000 * spec_index,
            )
            metrics = classification_metrics(y, probability, class_count)
            ranked.append(
                (
                    -selection_utility(metrics),
                    representation,
                    spec.name,
                    spec,
                    probability,
                )
            )
    _, representation, _, spec, probability = min(ranked, key=lambda row: row[:3])
    utility = selection_utility(classification_metrics(y, probability, class_count))
    return representation, spec, probability, utility


def _prediction_rows(
    clip_ids: np.ndarray,
    groups: np.ndarray,
    y_true: np.ndarray,
    probability: np.ndarray,
    outer_id: str,
    method: str,
) -> list[dict[str, object]]:
    rows = []
    for clip_id, group, truth, prob in zip(clip_ids, groups, y_true, probability):
        rows.append(
            {
                "clip_id": str(clip_id),
                "singer_id": str(group),
                "outer_split": outer_id,
                "method": method,
                "true_label": int(truth),
                "predicted_label": int(np.argmax(prob)),
                "probabilities": prob.tolist(),
            }
        )
    return rows


def run_nested_loso(
    acoustic: np.ndarray,
    ssl_representations: dict[str, np.ndarray],
    y: np.ndarray,
    groups: np.ndarray,
    clip_ids: np.ndarray,
    class_count: int,
    inner_splits: int = 4,
    seed: int = 20260824,
    acoustic_specs: tuple[ModelSpec, ...] | None = None,
    ssl_specs: tuple[ModelSpec, ...] | None = None,
    early_specs: tuple[ModelSpec, ...] | None = None,
    outer_splits: list[Split] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Run strictly nested LOSO and return predictions, metrics, selections.

    All choices are made from inner OOF predictions of the outer-training
    singers. Outer-test labels are touched only after every choice is frozen.
    """

    y = np.asarray(y, dtype=int)
    groups = np.asarray(groups)
    clip_ids = np.asarray(clip_ids)
    acoustic = np.asarray(acoustic, dtype=np.float64)
    ssl_representations = {
        name: np.asarray(values, dtype=np.float64) for name, values in ssl_representations.items()
    }
    if not ssl_representations:
        raise ValueError("At least one SSL representation is required")
    sample_count = len(y)
    arrays = [acoustic, groups, clip_ids, *ssl_representations.values()]
    if any(len(array) != sample_count for array in arrays):
        raise ValueError("Inputs do not share the same sample count")
    acoustic_specs = acoustic_specs or default_specs("acoustic")
    ssl_specs = ssl_specs or default_specs("ssl")
    early_specs = early_specs or default_specs("early")

    prediction_rows = []
    metric_rows = []
    selection_rows = []
    chosen_outer_splits = outer_splits if outer_splits is not None else list(leave_one_group_out(groups))
    for outer_index, outer in enumerate(chosen_outer_splits):
        train = outer.train
        test = outer.test
        assert_group_disjoint(train, test, groups)
        if not len(train) or not len(test):
            raise ValueError(f"Outer split {outer.split_id} has an empty train or test partition")
        inner = stratified_group_folds(
            y[train],
            groups[train],
            n_splits=inner_splits,
            seed=seed + outer_index,
            prefix=f"{outer.split_id}_inner",
        )

        _, acoustic_spec, acoustic_oof, acoustic_utility = _select_candidate(
            {"acoustic": acoustic[train]},
            y[train],
            inner,
            acoustic_specs,
            class_count,
            seed + 10000 * outer_index,
        )
        ssl_name, ssl_spec, ssl_oof, ssl_utility = _select_candidate(
            {name: values[train] for name, values in ssl_representations.items()},
            y[train],
            inner,
            ssl_specs,
            class_count,
            seed + 20000 * outer_index,
        )
        early_name, early_spec, _early_oof, early_utility = _select_candidate(
            {
                name: np.column_stack([acoustic[train], values[train]])
                for name, values in ssl_representations.items()
            },
            y[train],
            inner,
            early_specs,
            class_count,
            seed + 30000 * outer_index,
        )

        acoustic_temperature = fit_temperature(y[train], acoustic_oof)
        ssl_temperature = fit_temperature(y[train], ssl_oof)
        acoustic_calibrated_oof = apply_temperature(acoustic_oof, acoustic_temperature)
        ssl_calibrated_oof = apply_temperature(ssl_oof, ssl_temperature)
        fusion_choice = select_fusion(
            y[train], acoustic_calibrated_oof, ssl_calibrated_oof, class_count
        )

        acoustic_model = build_model(acoustic_spec, seed + 40000 * outer_index)
        acoustic_model.fit(acoustic[train], y[train])
        acoustic_probability = aligned_probability(acoustic_model, acoustic[test], class_count)
        acoustic_calibrated = apply_temperature(acoustic_probability, acoustic_temperature)

        ssl_model = build_model(ssl_spec, seed + 50000 * outer_index)
        ssl_model.fit(ssl_representations[ssl_name][train], y[train])
        ssl_probability = aligned_probability(
            ssl_model, ssl_representations[ssl_name][test], class_count
        )
        ssl_calibrated = apply_temperature(ssl_probability, ssl_temperature)

        early_model = build_model(early_spec, seed + 60000 * outer_index)
        early_train = np.column_stack([acoustic[train], ssl_representations[early_name][train]])
        early_test = np.column_stack([acoustic[test], ssl_representations[early_name][test]])
        early_model.fit(early_train, y[train])
        early_probability = aligned_probability(early_model, early_test, class_count)

        fused_probability = fuse_probabilities(
            acoustic_calibrated,
            ssl_calibrated,
            fusion_choice.acoustic_weight,
            fusion_choice.family,
        )
        methods = {
            "acoustic": acoustic_probability,
            "acoustic_calibrated": acoustic_calibrated,
            "ssl": ssl_probability,
            "ssl_calibrated": ssl_calibrated,
            "early_fusion": early_probability,
            "late_fusion_calibrated": fused_probability,
        }
        for method, probability in methods.items():
            prediction_rows.extend(
                _prediction_rows(
                    clip_ids[test], groups[test], y[test], probability, outer.split_id, method
                )
            )
            metric_rows.append(
                {
                    "outer_split": outer.split_id,
                    "held_out_singer": str(groups[test][0]),
                    "method": method,
                    **classification_metrics(y[test], probability, class_count),
                }
            )
        selection_rows.append(
            {
                "outer_split": outer.split_id,
                "held_out_singer": str(groups[test][0]),
                "acoustic_model": acoustic_spec.name,
                "acoustic_inner_utility": acoustic_utility,
                "acoustic_temperature": acoustic_temperature,
                "ssl_representation": ssl_name,
                "ssl_model": ssl_spec.name,
                "ssl_inner_utility": ssl_utility,
                "ssl_temperature": ssl_temperature,
                "early_representation": early_name,
                "early_model": early_spec.name,
                "early_inner_utility": early_utility,
                "fusion_family": fusion_choice.family,
                "fusion_acoustic_weight": fusion_choice.acoustic_weight,
                "fusion_inner_utility": fusion_choice.inner_utility,
                "fusion_inner_nll": fusion_choice.inner_nll,
            }
        )

    return pd.DataFrame(prediction_rows), pd.DataFrame(metric_rows), pd.DataFrame(selection_rows)


def run_nested_single_branch(
    features: np.ndarray,
    y: np.ndarray,
    groups: np.ndarray,
    clip_ids: np.ndarray,
    class_count: int,
    branch: str = "acoustic",
    inner_splits: int = 4,
    seed: int = 20260824,
    specs: tuple[ModelSpec, ...] | None = None,
    outer_splits: list[Split] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Nested singer-disjoint evaluation for a branch available before GPU extraction."""

    features = np.asarray(features, dtype=np.float64)
    y = np.asarray(y, dtype=int)
    groups = np.asarray(groups)
    clip_ids = np.asarray(clip_ids)
    if any(len(item) != len(y) for item in (features, groups, clip_ids)):
        raise ValueError("Inputs do not share the same sample count")
    specs = specs or default_specs(branch)
    predictions = []
    metrics = []
    selections = []
    chosen_outer_splits = outer_splits if outer_splits is not None else list(leave_one_group_out(groups))
    for outer_index, outer in enumerate(chosen_outer_splits):
        assert_group_disjoint(outer.train, outer.test, groups)
        inner = stratified_group_folds(
            y[outer.train],
            groups[outer.train],
            n_splits=inner_splits,
            seed=seed + outer_index,
            prefix=f"{outer.split_id}_inner",
        )
        _, spec, oof, utility = _select_candidate(
            {branch: features[outer.train]},
            y[outer.train],
            inner,
            specs,
            class_count,
            seed + 10000 * outer_index,
        )
        temperature = fit_temperature(y[outer.train], oof)
        model = build_model(spec, seed + 20000 * outer_index)
        model.fit(features[outer.train], y[outer.train])
        raw_probability = aligned_probability(model, features[outer.test], class_count)
        calibrated_probability = apply_temperature(raw_probability, temperature)
        for method, probability in {
            branch: raw_probability,
            f"{branch}_calibrated": calibrated_probability,
        }.items():
            predictions.extend(
                _prediction_rows(
                    clip_ids[outer.test],
                    groups[outer.test],
                    y[outer.test],
                    probability,
                    outer.split_id,
                    method,
                )
            )
            metrics.append(
                {
                    "outer_split": outer.split_id,
                    "held_out_singer": str(groups[outer.test][0]),
                    "method": method,
                    **classification_metrics(y[outer.test], probability, class_count),
                }
            )
        selections.append(
            {
                "outer_split": outer.split_id,
                "held_out_singer": str(groups[outer.test][0]),
                "branch": branch,
                "model": spec.name,
                "inner_utility": utility,
                "temperature": temperature,
            }
        )
    return pd.DataFrame(predictions), pd.DataFrame(metrics), pd.DataFrame(selections)
