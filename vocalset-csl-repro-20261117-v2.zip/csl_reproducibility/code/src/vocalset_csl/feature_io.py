"""Feature file integrity and manifest alignment helpers."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


def manifest_fingerprint(clip_ids: np.ndarray) -> str:
    values = np.asarray(clip_ids).astype(str)
    digest = hashlib.sha256()
    for value in values:
        digest.update(value.encode("utf-8"))
        digest.update(b"\0")
    return digest.hexdigest()


def save_feature_npz(
    path: str | Path,
    clip_ids: np.ndarray,
    values: np.ndarray,
    feature_names: list[str],
    metadata: dict[str, object] | None = None,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    clip_ids = np.asarray(clip_ids).astype(str)
    values = np.asarray(values, dtype=np.float32)
    if values.ndim != 2 or len(values) != len(clip_ids):
        raise ValueError("Feature values must have shape (clips, features)")
    if values.shape[1] != len(feature_names):
        raise ValueError("Feature name count does not match the matrix width")
    payload = dict(metadata or {})
    payload["manifest_fingerprint"] = manifest_fingerprint(clip_ids)
    payload["sample_count"] = len(clip_ids)
    payload["feature_count"] = int(values.shape[1])
    np.savez_compressed(
        path,
        clip_ids=clip_ids,
        values=values,
        feature_names=np.asarray(feature_names).astype(str),
        metadata_json=np.asarray(json.dumps(payload, sort_keys=True)),
    )


def load_feature_npz(path: str | Path) -> dict[str, object]:
    with np.load(path, allow_pickle=False) as archive:
        result = {
            "clip_ids": archive["clip_ids"].astype(str),
            "values": archive["values"].astype(np.float32),
            "feature_names": archive["feature_names"].astype(str).tolist(),
            "metadata": json.loads(str(archive["metadata_json"])),
        }
    expected = result["metadata"].get("manifest_fingerprint")
    observed = manifest_fingerprint(result["clip_ids"])
    if expected != observed:
        raise ValueError(f"Feature manifest fingerprint mismatch: {path}")
    return result


def align_feature_rows(
    target_clip_ids: np.ndarray, feature_clip_ids: np.ndarray, values: np.ndarray
) -> np.ndarray:
    target = np.asarray(target_clip_ids).astype(str)
    source = np.asarray(feature_clip_ids).astype(str)
    if len(np.unique(source)) != len(source):
        raise ValueError("Feature file contains duplicate clip IDs")
    position = {clip_id: index for index, clip_id in enumerate(source)}
    missing = [clip_id for clip_id in target if clip_id not in position]
    if missing:
        raise ValueError(f"Feature file is missing {len(missing)} target clips")
    return np.asarray(values)[[position[clip_id] for clip_id in target]]


def exclude_named_features(
    values: np.ndarray,
    feature_names: list[str],
    excluded: list[str] | tuple[str, ...],
) -> tuple[np.ndarray, list[str]]:
    """Remove explicitly named columns and fail if the schema does not contain them."""

    missing = sorted(set(excluded).difference(feature_names))
    if missing:
        raise ValueError(f"Requested exclusions are absent from the feature schema: {missing}")
    keep = [index for index, name in enumerate(feature_names) if name not in excluded]
    return np.asarray(values)[:, keep], [feature_names[index] for index in keep]
