"""Central task ontology and corpus filters."""

from __future__ import annotations

import pandas as pd


def select_task(
    frame: pd.DataFrame, config: dict[str, object], task: str
) -> tuple[pd.DataFrame, list[str]]:
    tasks = config.get("tasks", {})
    if task not in tasks:
        raise KeyError(f"Unknown task {task!r}; available tasks: {sorted(tasks)}")
    labels = list(tasks[task])
    selected = frame[frame.label.isin(labels)].copy()
    task_filters = config.get("task_filters", {}).get(task, {})
    contexts = task_filters.get("contexts")
    if contexts:
        selected = selected[selected.context.isin(contexts)].copy()
    selected = selected.reset_index(drop=True)
    observed = set(selected.label.dropna().astype(str))
    missing_labels = sorted(set(labels).difference(observed))
    if missing_labels:
        raise ValueError(f"Task {task!r} has no observations for labels: {missing_labels}")
    selected["target"] = pd.Categorical(selected.label, categories=labels).codes
    if selected.target.lt(0).any():
        raise ValueError(f"Task {task!r} label encoding failed")
    return selected, labels
