"""Interpretable eGeMAPS and singing-specific acoustic descriptors."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class AudioFeatures:
    names: list[str]
    values: np.ndarray


def _summary(prefix: str, values: np.ndarray) -> tuple[list[str], list[float]]:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    statistics = ("mean", "std", "p10", "median", "p90", "iqr")
    if not len(values):
        return [f"{prefix}_{name}" for name in statistics], [float("nan")] * len(statistics)
    numbers = [
        float(np.mean(values)),
        float(np.std(values)),
        float(np.percentile(values, 10)),
        float(np.median(values)),
        float(np.percentile(values, 90)),
        float(np.percentile(values, 75) - np.percentile(values, 25)),
    ]
    return [f"{prefix}_{name}" for name in statistics], numbers


def _vibrato_descriptors(f0: np.ndarray, times: np.ndarray) -> tuple[list[str], list[float]]:
    mask = np.isfinite(f0) & (f0 > 0)
    if mask.sum() < 16:
        return ["vibrato_rate_hz", "vibrato_extent_cents", "vibrato_band_strength"], [
            float("nan"),
            float("nan"),
            float("nan"),
        ]
    cents = 1200.0 * np.log2(f0[mask] / np.median(f0[mask]))
    cents -= np.polyval(np.polyfit(times[mask], cents, deg=1), times[mask])
    spacing = float(np.median(np.diff(times[mask])))
    if not np.isfinite(spacing) or spacing <= 0:
        return ["vibrato_rate_hz", "vibrato_extent_cents", "vibrato_band_strength"], [
            float("nan"),
            float("nan"),
            float("nan"),
        ]
    frequency = np.fft.rfftfreq(len(cents), d=spacing)
    power = np.abs(np.fft.rfft(cents * np.hanning(len(cents)))) ** 2
    band = (frequency >= 4.0) & (frequency <= 9.0)
    if not band.any() or power[band].sum() == 0:
        return ["vibrato_rate_hz", "vibrato_extent_cents", "vibrato_band_strength"], [
            float("nan"),
            float(np.std(cents)),
            0.0,
        ]
    peak = np.flatnonzero(band)[np.argmax(power[band])]
    strength = float(power[band].sum() / np.clip(power[frequency <= 12.0].sum(), 1e-12, None))
    return ["vibrato_rate_hz", "vibrato_extent_cents", "vibrato_band_strength"], [
        float(frequency[peak]),
        float(np.std(cents)),
        strength,
    ]


def singing_specific_features(audio: np.ndarray, sample_rate: int) -> AudioFeatures:
    import librosa

    audio = np.asarray(audio, dtype=np.float32)
    hop = 256
    frame = 1024
    duration = len(audio) / sample_rate
    f0, voiced_flag, voiced_probability = librosa.pyin(
        audio,
        fmin=librosa.note_to_hz("C2"),
        fmax=librosa.note_to_hz("C7"),
        sr=sample_rate,
        frame_length=frame,
        hop_length=hop,
    )
    times = librosa.times_like(f0, sr=sample_rate, hop_length=hop)
    names = ["duration_seconds", "voiced_fraction", "mean_voicing_probability"]
    values = [
        float(duration),
        float(np.mean(voiced_flag)) if voiced_flag is not None else float("nan"),
        float(np.nanmean(voiced_probability)),
    ]
    f0_names, f0_values = _summary("f0_hz", f0)
    names.extend(f0_names)
    values.extend(f0_values)
    valid_f0 = f0[np.isfinite(f0) & (f0 > 0)]
    cents = 1200.0 * np.log2(valid_f0 / np.median(valid_f0)) if len(valid_f0) else valid_f0
    cents_names, cents_values = _summary("f0_cents_centered", cents)
    names.extend(cents_names)
    values.extend(cents_values)
    vibrato_names, vibrato_values = _vibrato_descriptors(f0, times)
    names.extend(vibrato_names)
    values.extend(vibrato_values)

    descriptors = {
        "rms": librosa.feature.rms(y=audio, frame_length=frame, hop_length=hop),
        "zcr": librosa.feature.zero_crossing_rate(audio, frame_length=frame, hop_length=hop),
        "spectral_centroid": librosa.feature.spectral_centroid(y=audio, sr=sample_rate),
        "spectral_bandwidth": librosa.feature.spectral_bandwidth(y=audio, sr=sample_rate),
        "spectral_rolloff": librosa.feature.spectral_rolloff(y=audio, sr=sample_rate),
        "spectral_flatness": librosa.feature.spectral_flatness(y=audio),
    }
    contrast = librosa.feature.spectral_contrast(y=audio, sr=sample_rate)
    for index, band in enumerate(contrast):
        descriptors[f"spectral_contrast_band{index}"] = band
    for descriptor, observation in descriptors.items():
        descriptor_names, descriptor_values = _summary(descriptor, observation.ravel())
        names.extend(descriptor_names)
        values.extend(descriptor_values)
    return AudioFeatures(names=names, values=np.asarray(values, dtype=np.float32))


@lru_cache(maxsize=2)
def _smile_extractor():
    import opensmile

    return opensmile.Smile(
        feature_set=opensmile.FeatureSet.eGeMAPSv02,
        feature_level=opensmile.FeatureLevel.Functionals,
    )


def extract_interpretable_features(path: str | Path, target_rate: int = 22050) -> AudioFeatures:
    import librosa

    audio, sample_rate = librosa.load(path, sr=target_rate, mono=True)
    frame = _smile_extractor().process_signal(audio, sample_rate)
    egemaps_names = [f"egemaps_{name}" for name in frame.columns]
    egemaps_values = frame.iloc[0].to_numpy(dtype=np.float32)
    singing = singing_specific_features(audio, sample_rate)
    return AudioFeatures(
        names=egemaps_names + singing.names,
        values=np.concatenate([egemaps_values, singing.values]).astype(np.float32),
    )
