"""Fair, reproducible classifier candidates for each representation branch."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

from .metrics import normalize_probabilities
from .splitting import Split


@dataclass(frozen=True)
class ModelSpec:
    name: str
    family: str
    parameters: tuple[tuple[str, object], ...]

    @classmethod
    def create(cls, name: str, family: str, **parameters: object) -> ModelSpec:
        return cls(name=name, family=family, parameters=tuple(sorted(parameters.items())))

    def as_dict(self) -> dict[str, object]:
        return dict(self.parameters)


def default_specs(branch: str) -> tuple[ModelSpec, ...]:
    if branch not in {"acoustic", "ssl", "early"}:
        raise ValueError(f"Unknown branch: {branch}")
    logistic = tuple(
        ModelSpec.create(f"lr_c{c:g}", "logistic", c=c) for c in (0.1, 1.0, 10.0)
    )
    if branch in {"ssl", "early"}:
        linear_svm = tuple(
            ModelSpec.create(f"linear_svm_c{c:g}", "linear_svm", c=c)
            for c in (0.1, 1.0, 10.0)
        )
        return logistic + linear_svm
    trees = tuple(
        ModelSpec.create(
            f"extra_trees_leaf{leaf}_mf{max_features}",
            "extra_trees",
            min_samples_leaf=leaf,
            max_features=max_features,
        )
        for leaf in (1, 3)
        for max_features in ("sqrt", 0.5)
    )
    return logistic + trees


def find_default_spec(branch: str, name: str) -> ModelSpec:
    matches = [spec for spec in default_specs(branch) if spec.name == name]
    if len(matches) != 1:
        raise KeyError(f"Could not uniquely resolve {branch} model spec: {name}")
    return matches[0]


def build_model(spec: ModelSpec, random_state: int):
    parameters = spec.as_dict()
    if spec.family == "logistic":
        return Pipeline(
            [
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
                (
                    "model",
                    LogisticRegression(
                        C=float(parameters["c"]),
                        class_weight="balanced",
                        max_iter=5000,
                        solver="lbfgs",
                        random_state=random_state,
                    ),
                ),
            ]
        )
    if spec.family == "linear_svm":
        return Pipeline(
            [
                ("impute", SimpleImputer(strategy="median")),
                ("scale", StandardScaler()),
                (
                    "model",
                    LinearSVC(
                        C=float(parameters["c"]),
                        class_weight="balanced",
                        dual="auto",
                        max_iter=10000,
                        random_state=random_state,
                    ),
                ),
            ]
        )
    if spec.family == "extra_trees":
        return Pipeline(
            [
                ("impute", SimpleImputer(strategy="median")),
                (
                    "model",
                    ExtraTreesClassifier(
                        n_estimators=500,
                        min_samples_leaf=int(parameters["min_samples_leaf"]),
                        max_features=parameters["max_features"],
                        class_weight="balanced",
                        n_jobs=-1,
                        random_state=random_state,
                    ),
                ),
            ]
        )
    raise ValueError(f"Unknown model family: {spec.family}")


def _softmax(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=np.float64)
    if values.ndim == 1:
        values = np.column_stack([-values, values])
    values -= values.max(axis=1, keepdims=True)
    output = np.exp(values)
    return output / output.sum(axis=1, keepdims=True)


def aligned_probability(model, x: np.ndarray, class_count: int) -> np.ndarray:
    if hasattr(model, "predict_proba"):
        try:
            local = model.predict_proba(x)
        except AttributeError:
            local = _softmax(model.decision_function(x))
    elif hasattr(model, "decision_function"):
        local = _softmax(model.decision_function(x))
    else:
        raise TypeError("Model exposes neither predict_proba nor decision_function")
    classes = np.asarray(model.classes_, dtype=int)
    output = np.full((len(x), class_count), 1e-12, dtype=np.float64)
    output[:, classes] = local
    return normalize_probabilities(output)


def oof_probability(
    spec: ModelSpec,
    x: np.ndarray,
    y: np.ndarray,
    splits: list[Split],
    class_count: int,
    random_state: int,
) -> np.ndarray:
    output = np.full((len(y), class_count), np.nan, dtype=np.float64)
    for fold_index, split in enumerate(splits):
        model = build_model(spec, random_state + fold_index)
        model.fit(x[split.train], y[split.train])
        output[split.test] = aligned_probability(model, x[split.test], class_count)
    if np.isnan(output).any():
        missing = np.flatnonzero(np.isnan(output).any(axis=1))
        raise ValueError(f"OOF predictions missing for {len(missing)} samples")
    return output
