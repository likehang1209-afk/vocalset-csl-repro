"""Dataset ontology, coverage, and shortcut diagnostics."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import mutual_info_score


def normalized_mutual_information(frame: pd.DataFrame, target: str, attribute: str) -> float:
    clean = frame[[target, attribute]].dropna().astype(str)
    if clean.empty or clean[target].nunique() <= 1 or clean[attribute].nunique() <= 1:
        return float("nan")
    information = mutual_info_score(clean[target], clean[attribute])
    target_probability = clean[target].value_counts(normalize=True).to_numpy(dtype=float)
    target_entropy = -float(np.sum(target_probability * np.log(target_probability)))
    return float(information / target_entropy) if target_entropy > 0 else float("nan")


def manifest_audit(frame: pd.DataFrame) -> dict[str, object]:
    critical = {
        "path",
        "canonical_path",
        "singer_id",
        "raw_label",
        "label",
        "label_family",
        "context",
    }
    optional = {"vowel", "key"}
    required = critical | optional
    missing_columns = required.difference(frame.columns)
    if missing_columns:
        raise ValueError(f"Manifest is missing columns: {sorted(missing_columns)}")
    unresolved = frame[frame[list(critical - {"path"})].isna().any(axis=1)]
    optional_missing = {column: int(frame[column].isna().sum()) for column in sorted(optional)}
    label_counts = frame["label"].value_counts(dropna=False).to_dict()
    singer_counts = frame["singer_id"].value_counts(dropna=False).to_dict()
    coverage = pd.crosstab(frame["label"], frame["singer_id"])
    aliases = frame.loc[frame["raw_label"].ne(frame["label"]), ["raw_label", "label"]]
    alias_counts = (
        aliases.value_counts().rename("count").reset_index().to_dict(orient="records")
        if not aliases.empty
        else []
    )
    warnings = []
    if len(unresolved):
        warnings.append(f"{len(unresolved)} paths have unresolved critical metadata")
    low_singer_labels = coverage.index[(coverage > 0).sum(axis=1) < 5].tolist()
    if low_singer_labels:
        warnings.append(f"Labels represented by fewer than five singers: {low_singer_labels}")
    if any(item["raw_label"] == "vibrado" for item in alias_counts):
        warnings.append("The non-official label 'vibrado' was mapped to 'vibrato'; inspect source paths")
    return {
        "sample_count": len(frame),
        "singer_count": int(frame["singer_id"].nunique(dropna=True)),
        "raw_label_count": int(frame["raw_label"].nunique(dropna=True)),
        "clean_label_count": int(frame["label"].nunique(dropna=True)),
        "context_count": int(frame["context"].nunique(dropna=True)),
        "unresolved_count": len(unresolved),
        "critical_unresolved_count": len(unresolved),
        "optional_missing_counts": optional_missing,
        "label_counts": {str(key): int(value) for key, value in label_counts.items()},
        "singer_counts": {str(key): int(value) for key, value in singer_counts.items()},
        "alias_counts": alias_counts,
        "nmi_label_context": normalized_mutual_information(frame, "label", "context"),
        "nmi_label_vowel": normalized_mutual_information(frame, "label", "vowel"),
        "nmi_label_singer": normalized_mutual_information(frame, "label", "singer_id"),
        "warnings": warnings,
    }


def coverage_tables(frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
    return {
        "label_by_singer": pd.crosstab(frame["label"], frame["singer_id"]),
        "label_by_context": pd.crosstab(frame["label"], frame["context"]),
        "label_by_vowel": pd.crosstab(frame["label"], frame["vowel"]),
        "family_by_context": pd.crosstab(frame["label_family"], frame["context"]),
    }
