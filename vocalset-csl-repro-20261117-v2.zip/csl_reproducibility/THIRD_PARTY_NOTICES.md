# Third-party sources

- VocalSet: Wilkins, Seetharaman, Wahl, and Pardo (2018).
  [VocalSet v1.2](https://doi.org/10.5281/zenodo.1442513).
- GTSinger: [source dataset](https://doi.org/10.57967/hf/3160).
  Its [dataset license](https://huggingface.co/datasets/GTSinger/GTSinger/blob/4426c862beed558b7e1cb8a4dce7e8c0c83bb208/dataset_license.md)
  remains applicable. No GTSinger recordings or annotations are redistributed.
- Prior-system recipe references: [Yamamoto (2023)](https://arxiv.org/abs/2306.12714)
  and [Zhou, Zhu, and Chen (2025)](https://arxiv.org/abs/2505.16306).
- The vendored [MusicFM source notice](code/revision_v5_major_20261108/upstream/musicfm/LICENSE)
  is reproduced unchanged. Model identifiers and pins are in the protocol
  JSON files. No pretrained model weights are included.

Third-party notices and dataset or checkpoint terms are not superseded by
publication of these research sources. Dependencies listed in requirements
files are not vendored.
