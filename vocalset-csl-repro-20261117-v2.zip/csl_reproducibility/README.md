# Singer-independent singing-technique recognition

Research code and experimental recipes for the VocalSet study. This snapshot
includes core Python sources, fixed partitions, model configurations, analysis
code, and tests. It does not include the manuscript, audio, weights, derived
feature stores, individual predictions, or experiment checkpoints.

## Start here

- **Original evaluation:** `historical/configs/protocol_v2.json` records the
  archive checksum, feature selection, models, calibration, and fusion settings.
  The numbered scripts in `historical/scripts/` cover corpus preparation,
  extraction, and singer-disjoint nested evaluation. Use the matching
  `historical/src/` package on the Python path and explicit input/output paths.
- **Six prior-system adaptations:** Under `code/revision_v5_major_20261108/`,
  use `protocol.json`, `artifacts/plan.json`, the two extra seed plans,
  `prepare_audio.py`, `extract_zhou.py`, `train_yamamoto.py`, and
  `train_zhou.py`. The fitting and analysis scripts accept or document their
  input locations. Neural-fitting requirements are separate from the CPU
  analysis requirements.
- **Original-pipeline seed sensitivity:** `anchor_multiseed_20261111/PLAN.md`
  records the three fixed schedules (20260824, 30260824, 40260824) and the
  unchanged twenty outer singers. The analysis averages schedules within singer
  and retains both the thirteen-test and joint thirty-seven-test Holm families.
- **Diagnostic and follow-up analyses:** `error_complementarity_20261114/` and
  `fusion_conditions_20261115/` implement the archived-prediction diagnostics,
  including all-class correctness intervals for a shared fusion weight.
  `risk_gated_fusion_20261116/` and `class_probability_correction_20261116/`
  contain the fixed decision-layer methods and recipes. These exploratory
  comparisons do not establish a stable improvement over the original branch.
- **GTSinger paired pilot:** `external_gtsinger_paired_20261117/PROTOCOL.md`,
  `protocol.json`, `paired_data.py`, and `pilot.py` describe fixed pair
  selection and target-score ranking. This is a two-technique exploratory
  transfer probe, not external validation of the six-class task. Both corrected
  and newly introduced ranking errors are counted.

## Inputs and validation boundary

Obtain [VocalSet v1.2](https://doi.org/10.5281/zenodo.1442513), the pinned
[GTSinger source](https://doi.org/10.57967/hf/3160), and any pretrained
checkpoints from their providers under the applicable terms. Dataset references
and partition recipes do not redistribute any recordings.

For CPU analysis, see `requirements-analysis.txt`. The original training
partition compatibility check used scikit-learn 1.7.2; see
`requirements-historical-fit.txt`. Do not substitute a different partition
generator or treat this as a bit-for-bit recreation of the historical training
environment. `SOURCE_PROVENANCE.json` records original and packaged hashes.
Local input roots were made relative in selected archived source files.

These sources describe and implement the recorded methods. Some retrospective
analysis entry points require the separately retained non-audio archive
(including feature or prediction arrays, original result manifests, and
fingerprints). Those inputs are not bundled; a fresh clone alone cannot
regenerate the paper's tables. Access to retained inputs may be requested from
the corresponding author, subject to permissions. `SHA256SUMS.json` records
the exact packaged contents. Tests use small fixtures without downloading data
or refitting the study models.

## Notices

No new redistribution license is granted for author-owned code in this
snapshot. Third-party materials retain their respective terms; see
[`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).
