"""Run strict nested LOSO from acoustic and all-layer embedding stores."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.feature_io import (
    align_feature_rows,
    exclude_named_features,
    load_feature_npz,
)
from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue
from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import ModelSpec
from vocalset_csl.nested import run_nested_loso
from vocalset_csl.representation_io import load_multiple_embedding_stores
from vocalset_csl.splitting import leave_one_group_out
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--acoustic",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument(
        "--embedding-root", default='data/embeddings'
    )
    parser.add_argument("--models", default="mert95m,wavlm_base_plus,hubert_base,muq_large")
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument("--output-dir", default='data/results/nested_loso')
    parser.add_argument("--inner-splits", type=int, default=4)
    parser.add_argument("--fast-smoke", action="store_true")
    parser.add_argument(
        "--fixed-linear-probe",
        action="store_true",
        help="Use a pre-specified LR(C=1) classifier grid while retaining nested representation selection.",
    )
    parser.add_argument(
        "--ssl-parallel-jobs",
        type=int,
        default=1,
        help="Parallel candidate evaluations for the SSL branch (default: 1).",
    )
    parser.add_argument(
        "--early-parallel-jobs",
        type=int,
        default=1,
        help="Parallel candidate evaluations for the early-fusion branch (default: 1).",
    )
    parser.add_argument(
        "--max-outer-splits",
        type=int,
        default=0,
        help="Run only the first N deterministic LOSO folds (0 means all folds).",
    )
    parser.add_argument(
        "--checkpoint",
        action="store_true",
        help="Persist every completed outer singer fold and resume valid fold checkpoints.",
    )
    return parser.parse_args()


def pooled_metrics(predictions: pd.DataFrame, class_count: int) -> list[dict[str, object]]:
    rows = []
    for method, frame in predictions.groupby("method", sort=False):
        probability = np.stack(frame["probabilities"].to_numpy())
        rows.append(
            {
                "method": method,
                **classification_metrics(frame.true_label.to_numpy(dtype=int), probability, class_count),
            }
        )
    return rows


def paired_inference(metrics: pd.DataFrame) -> list[dict[str, object]]:
    if metrics["outer_split"].nunique() < 2:
        # A one-fold smoke run can verify the nested pipeline but cannot support
        # singer-clustered uncertainty estimates.
        return []
    rows = []
    anchor = "late_fusion_calibrated"
    for metric in ("macro_f1_present", "uar_present", "accuracy"):
        pivot = metrics.pivot(index="outer_split", columns="method", values=metric)
        for baseline in [column for column in pivot.columns if column != anchor]:
            differences = pivot[anchor].sub(pivot[baseline]).dropna().to_numpy()
            rows.append(
                {
                    "anchor": anchor,
                    "baseline": baseline,
                    "metric": metric,
                    **paired_cluster_bootstrap(differences),
                    "paired_sign_flip_p": paired_sign_flip_pvalue(differences),
                }
            )
    return rows


def checkpoint_paths(checkpoint_dir: Path, split_id: str) -> tuple[Path, Path, Path]:
    stem = checkpoint_dir / split_id
    return (
        stem.with_name(f"{stem.name}_predictions.csv"),
        stem.with_name(f"{stem.name}_metrics.csv"),
        stem.with_name(f"{stem.name}_selections.csv"),
    )


def write_csv_atomic(frame: pd.DataFrame, destination: Path) -> None:
    temporary = destination.with_suffix(f"{destination.suffix}.tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(destination)


def write_fold_checkpoint(
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    selections: pd.DataFrame,
    paths: tuple[Path, Path, Path],
) -> None:
    serializable_predictions = predictions.copy()
    serializable_predictions["probabilities"] = serializable_predictions["probabilities"].map(json.dumps)
    write_csv_atomic(serializable_predictions, paths[0])
    write_csv_atomic(metrics, paths[1])
    write_csv_atomic(selections, paths[2])


def read_fold_checkpoint(paths: tuple[Path, Path, Path]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    predictions = pd.read_csv(paths[0])
    predictions["probabilities"] = predictions["probabilities"].map(json.loads)
    return predictions, pd.read_csv(paths[1]), pd.read_csv(paths[2])


def main() -> None:
    args = parse_args()
    if args.ssl_parallel_jobs < 1 or args.early_parallel_jobs < 1:
        raise ValueError("parallel job counts must be at least 1")
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    manifest = pd.read_csv(args.manifest)
    manifest, labels = select_task(manifest, config, args.task)
    clip_ids = manifest.clip_id.astype(str).to_numpy()

    acoustic_file = load_feature_npz(args.acoustic)
    acoustic = align_feature_rows(clip_ids, acoustic_file["clip_ids"], acoustic_file["values"])
    acoustic_excluded = config["acoustic_features"]["main_exclude"]
    acoustic, acoustic_names = exclude_named_features(
        acoustic, acoustic_file["feature_names"], acoustic_excluded
    )
    model_keys = [item.strip() for item in args.models.split(",") if item.strip()]
    ssl, ssl_metadata = load_multiple_embedding_stores(
        args.embedding_root,
        model_keys,
        clip_ids,
        config["layer_probe"]["normalized_depths"],
    )
    kwargs = {}
    if args.fast_smoke or args.fixed_linear_probe:
        only_lr = (ModelSpec.create("lr_c1", "logistic", c=1.0),)
        kwargs = {"acoustic_specs": only_lr, "ssl_specs": only_lr, "early_specs": only_lr}
    outer_splits = list(leave_one_group_out(manifest.singer_id.astype(str).to_numpy()))
    if args.max_outer_splits:
        if args.max_outer_splits < 1:
            raise ValueError("--max-outer-splits must be positive when specified")
        outer_splits = outer_splits[: args.max_outer_splits]
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    run_inputs = {
        "acoustic": acoustic,
        "ssl_representations": ssl,
        "y": manifest.target.to_numpy(dtype=int),
        "groups": manifest.singer_id.astype(str).to_numpy(),
        "clip_ids": clip_ids,
        "class_count": len(labels),
        "inner_splits": args.inner_splits,
        "seed": int(config["evaluation"]["inner_seed"]),
        "ssl_parallel_jobs": args.ssl_parallel_jobs,
        "early_parallel_jobs": args.early_parallel_jobs,
        **kwargs,
    }
    if args.checkpoint:
        checkpoint_dir = output / "fold_checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        prediction_parts = []
        metric_parts = []
        selection_parts = []
        for outer_index, outer in enumerate(outer_splits):
            paths = checkpoint_paths(checkpoint_dir, outer.split_id)
            if all(path.exists() and path.stat().st_size > 0 for path in paths):
                fold_predictions, fold_metrics, fold_selections = read_fold_checkpoint(paths)
                print(json.dumps({"fold": outer.split_id, "status": "resumed"}), flush=True)
            else:
                print(json.dumps({"fold": outer.split_id, "status": "running"}), flush=True)
                fold_predictions, fold_metrics, fold_selections = run_nested_loso(
                    **run_inputs,
                    outer_splits=[outer],
                    outer_index_offset=outer_index,
                )
                write_fold_checkpoint(fold_predictions, fold_metrics, fold_selections, paths)
                print(json.dumps({"fold": outer.split_id, "status": "completed"}), flush=True)
            prediction_parts.append(fold_predictions)
            metric_parts.append(fold_metrics)
            selection_parts.append(fold_selections)
        predictions = pd.concat(prediction_parts, ignore_index=True)
        metrics = pd.concat(metric_parts, ignore_index=True)
        selections = pd.concat(selection_parts, ignore_index=True)
    else:
        predictions, metrics, selections = run_nested_loso(
            **run_inputs,
            outer_splits=outer_splits,
        )
    serializable_predictions = predictions.copy()
    serializable_predictions["probabilities"] = serializable_predictions["probabilities"].map(json.dumps)
    write_csv_atomic(serializable_predictions, output / "outer_predictions.csv")
    write_csv_atomic(metrics, output / "singer_fold_metrics.csv")
    write_csv_atomic(selections, output / "inner_selections.csv")
    summary = {
        "protocol_id": config["protocol_id"],
        "task": args.task,
        "labels": labels,
        "clip_count": len(manifest),
        "singer_count": int(manifest.singer_id.nunique()),
        "evaluated_outer_splits": [split.split_id for split in outer_splits],
        "checkpoint_enabled": args.checkpoint,
        "fixed_linear_probe": args.fixed_linear_probe,
        "models": model_keys,
        "acoustic_feature_count": len(acoustic_names),
        "acoustic_features_excluded": acoustic_excluded,
        "ssl_metadata": ssl_metadata,
        "pooled_metrics": pooled_metrics(predictions, len(labels)),
        "paired_singer_clustered_inference": paired_inference(metrics),
    }
    summary_temporary = output / "summary.json.tmp"
    summary_temporary.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    summary_temporary.replace(output / "summary.json")
    print(json.dumps({"output": str(output), "clips": len(manifest), "methods": 6}, indent=2))


if __name__ == "__main__":
    main()
