"""Isolate training-context effects while holding the selected classifier fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.calibration import apply_temperature
from vocalset_csl.feature_io import (
    align_feature_rows,
    exclude_named_features,
    load_feature_npz,
)
from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue
from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import aligned_probability, build_model, find_default_spec
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--acoustic",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument(
        "--selections",
        default=(
            'data/results/acoustic_only_loso/'
            "production_shared_6\\inner_selections.csv"
        ),
    )
    parser.add_argument(
        "--output-dir",
        default='data/results/context_training_ablation',
    )
    parser.add_argument("--seed", type=int, default=20260829)
    return parser.parse_args()


def metric_block(frame: pd.DataFrame, class_count: int) -> dict[str, object]:
    return classification_metrics(
        frame.true_label.to_numpy(dtype=int),
        np.stack(frame.probability.to_numpy()),
        class_count,
    )


def acoustic_selection_columns(selections: pd.DataFrame) -> tuple[str, str]:
    if {"acoustic_model", "acoustic_temperature"}.issubset(selections.columns):
        return "acoustic_model", "acoustic_temperature"
    if {"model", "temperature"}.issubset(selections.columns):
        return "model", "temperature"
    raise ValueError(
        "Selections must contain either acoustic_model/acoustic_temperature or model/temperature"
    )


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    clip_ids = frame.clip_id.astype(str).to_numpy()
    item = load_feature_npz(args.acoustic)
    features = align_feature_rows(clip_ids, item["clip_ids"], item["values"])
    features, names = exclude_named_features(
        features,
        item["feature_names"],
        config["acoustic_features"]["main_exclude"],
    )
    y = frame.target.to_numpy(dtype=int)
    selections = pd.read_csv(args.selections).set_index("outer_split")
    model_column, temperature_column = acoustic_selection_columns(selections)
    prediction_rows = []
    for direction_index, (source, target) in enumerate(
        (("scale", "arpeggio"), ("arpeggio", "scale"))
    ):
        direction = f"{source}_to_{target}"
        for singer_index, singer in enumerate(sorted(frame.singer_id.unique())):
            selection = selections.loc[f"loso_{singer}"]
            spec = find_default_spec("acoustic", str(selection[model_column]))
            temperature = float(selection[temperature_column])
            mixed_train = np.flatnonzero(frame.singer_id.ne(singer))
            source_train = np.flatnonzero(
                frame.singer_id.ne(singer) & frame.context.eq(source)
            )
            test = np.flatnonzero(frame.singer_id.eq(singer) & frame.context.eq(target))
            if set(np.unique(y[source_train])) != set(range(len(labels))):
                raise ValueError(f"Source training classes are incomplete for {direction}, {singer}")
            for condition_index, (condition, train) in enumerate(
                (("mixed_context_training", mixed_train), ("source_only_training", source_train))
            ):
                model = build_model(
                    spec,
                    args.seed
                    + 1000 * direction_index
                    + 10 * singer_index
                    + condition_index,
                )
                model.fit(features[train], y[train])
                probability = aligned_probability(model, features[test], len(labels))
                probability = apply_temperature(probability, temperature)
                for row_index, row_probability in zip(test, probability):
                    prediction_rows.append(
                        {
                            "direction": direction,
                            "source_context": source,
                            "target_context": target,
                            "held_out_singer": singer,
                            "condition": condition,
                            "selected_model": spec.name,
                            "clip_id": str(frame.iloc[row_index].clip_id),
                            "true_label": int(y[row_index]),
                            "predicted_label": int(row_probability.argmax()),
                            "probability": row_probability,
                        }
                    )
    predictions = pd.DataFrame(prediction_rows)
    pooled = []
    singer_metrics = []
    for (direction, condition), group in predictions.groupby(["direction", "condition"]):
        pooled.append(
            {
                "direction": direction,
                "condition": condition,
                **metric_block(group, len(labels)),
            }
        )
        for singer, singer_group in group.groupby("held_out_singer"):
            singer_metrics.append(
                {
                    "direction": direction,
                    "condition": condition,
                    "held_out_singer": singer,
                    **metric_block(singer_group, len(labels)),
                }
            )
    singer_frame = pd.DataFrame(singer_metrics)
    inference = []
    for direction, direction_frame in singer_frame.groupby("direction"):
        for metric in ("macro_f1_present", "uar_present", "accuracy"):
            pivot = direction_frame.pivot(
                index="held_out_singer", columns="condition", values=metric
            )
            differences = (
                pivot.source_only_training - pivot.mixed_context_training
            ).to_numpy()
            inference.append(
                {
                    "direction": direction,
                    "metric": metric,
                    "difference_definition": "source-only minus mixed-context training",
                    **paired_cluster_bootstrap(differences),
                    "paired_sign_flip_p": paired_sign_flip_pvalue(differences),
                }
            )
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    serialized = predictions.copy()
    serialized["probability"] = serialized.probability.map(lambda value: json.dumps(value.tolist()))
    serialized.to_csv(output / "predictions.csv", index=False)
    singer_frame.to_csv(output / "singer_metrics.csv", index=False)
    report = {
        "task": args.task,
        "labels": labels,
        "acoustic_feature_count": len(names),
        "classifier_control": (
            "Both training conditions use the acoustic model and temperature selected from "
            "mixed-context inner OOF data for the same held-out singer."
        ),
        "selection_columns": {"model": model_column, "temperature": temperature_column},
        "pooled_metrics": pooled,
        "paired_singer_inference": inference,
    }
    (output / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
