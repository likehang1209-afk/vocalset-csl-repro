"""Resume-safe CPU extraction of named interpretable acoustic descriptors."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.audio_features import extract_interpretable_features
from vocalset_csl.feature_io import save_feature_npz


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest", default='data/manifests/canonical/manifest.csv'
    )
    parser.add_argument(
        "--checkpoint-dir",
        default='data/features/acoustic_checkpoints',
    )
    parser.add_argument(
        "--output",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--workers", type=int, default=1)
    return parser.parse_args()


def extract_one(item: tuple[str, str]) -> tuple[str, list[str] | None, np.ndarray | None, str | None]:
    clip_id, path = item
    try:
        features = extract_interpretable_features(path)
        return clip_id, features.names, features.values, None
    except Exception as error:  # noqa: BLE001 - return every corpus failure to the parent
        return clip_id, None, None, repr(error)


def checkpoint_is_valid(path: Path, clip_id: str) -> bool:
    try:
        with np.load(path, allow_pickle=False) as item:
            return (
                str(item["clip_id"]) == clip_id
                and item["values"].ndim == 1
                and len(item["names"]) == len(item["values"])
            )
    except Exception:  # noqa: BLE001 - an interrupted checkpoint must be recomputed
        return False


def save_checkpoint(path: Path, clip_id: str, names: list[str], values: np.ndarray) -> None:
    temporary = path.with_suffix(".tmp.npz")
    np.savez_compressed(
        temporary,
        clip_id=np.asarray(clip_id),
        names=np.asarray(names),
        values=values,
    )
    temporary.replace(path)


def main() -> None:
    args = parse_args()
    manifest = pd.read_csv(args.manifest)
    if args.limit:
        manifest = manifest.head(args.limit)
    checkpoints = Path(args.checkpoint_dir)
    checkpoints.mkdir(parents=True, exist_ok=True)
    failures = []
    pending = []
    completed = 0
    for row in manifest.itertuples(index=False):
        clip_id = str(row.clip_id)
        target = checkpoints / f"{clip_id}.npz"
        if target.exists() and checkpoint_is_valid(target, clip_id):
            completed += 1
        else:
            pending.append((clip_id, str(row.absolute_path)))
    print(
        json.dumps(
            {
                "clips": len(manifest),
                "valid_checkpoints": completed,
                "pending": len(pending),
                "workers": args.workers,
            }
        ),
        flush=True,
    )
    start = time.perf_counter()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as executor:
        for processed, (clip_id, names, values, error) in enumerate(
            executor.map(extract_one, pending), start=1
        ):
            source_path = pending[processed - 1][1]
            if error is not None or names is None or values is None:
                failure = {"clip_id": clip_id, "path": source_path, "error": error}
                failures.append(failure)
                print(json.dumps(failure), flush=True)
            else:
                save_checkpoint(checkpoints / f"{clip_id}.npz", clip_id, names, values)
            if processed == 1 or processed % 25 == 0 or processed == len(pending):
                elapsed = time.perf_counter() - start
                rate = processed / elapsed if elapsed > 0 else 0.0
                remaining = (len(pending) - processed) / rate if rate > 0 else None
                print(
                    json.dumps(
                        {
                            "processed_this_run": processed,
                            "pending_this_run": len(pending),
                            "total_complete": completed + processed - len(failures),
                            "failures": len(failures),
                            "clips_per_minute": round(rate * 60.0, 2),
                            "eta_minutes": round(remaining / 60.0, 1)
                            if remaining is not None
                            else None,
                        }
                    ),
                    flush=True,
                )
    if failures:
        (checkpoints / "failures.json").write_text(json.dumps(failures, indent=2), encoding="utf-8")
        raise SystemExit(f"Feature extraction failed for {len(failures)} clips")

    names = None
    rows = []
    for clip_id in manifest["clip_id"].astype(str):
        with np.load(checkpoints / f"{clip_id}.npz", allow_pickle=False) as item:
            current_names = item["names"].astype(str).tolist()
            if names is None:
                names = current_names
            elif names != current_names:
                raise ValueError(f"Feature schema changed at clip {clip_id}")
            rows.append(item["values"].astype(np.float32))
    values = np.stack(rows)
    save_feature_npz(
        args.output,
        manifest["clip_id"].astype(str).to_numpy(),
        values,
        names or [],
        metadata={"extractor": "eGeMAPSv02_plus_singing_specific_v1"},
    )
    print(json.dumps({"output": args.output, "clips": len(values), "features": values.shape[1]}, indent=2))


if __name__ == "__main__":
    main()
