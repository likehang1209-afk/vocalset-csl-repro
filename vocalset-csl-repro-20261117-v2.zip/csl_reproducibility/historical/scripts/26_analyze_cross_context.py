"""Compute singer-clustered comparisons for completed cross-context results."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue


METHODS = (
    "acoustic_calibrated",
    "ssl_calibrated",
    "early_fusion",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--metrics", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    metrics = pd.read_csv(args.metrics)
    metrics["direction"] = metrics.outer_split.str.split("__").str[0]
    rows = []
    for direction, frame in metrics.groupby("direction", sort=True):
        for metric in ("macro_f1_present", "uar_present", "accuracy", "nll", "ece"):
            pivot = frame.pivot(index="held_out_singer", columns="method", values=metric)
            for baseline in METHODS:
                if baseline not in pivot or "late_fusion_calibrated" not in pivot:
                    continue
                difference = (
                    pivot["late_fusion_calibrated"].sub(pivot[baseline]).dropna().to_numpy()
                )
                rows.append(
                    {
                        "direction": direction,
                        "anchor": "late_fusion_calibrated",
                        "baseline": baseline,
                        "metric": metric,
                        **paired_cluster_bootstrap(difference),
                        "paired_sign_flip_p": paired_sign_flip_pvalue(difference),
                    }
                )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    print({"output": str(output), "comparisons": len(rows)})


if __name__ == "__main__":
    main()
