"""Build a deterministic content-deduplicated manifest for all model experiments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from vocalset_csl.audit import coverage_tables, manifest_audit


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest", default='data/manifests/canonical/manifest.csv'
    )
    parser.add_argument(
        "--integrity",
        default='data/manifests/integrity/audio_integrity.csv',
    )
    parser.add_argument(
        "--output-dir", default='data/manifests/modeling'
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = pd.read_csv(args.manifest, dtype={"clip_id": str})
    integrity = pd.read_csv(args.integrity, dtype={"clip_id": str})
    if integrity.sha256.isna().any() or integrity.error.notna().any():
        raise ValueError("Integrity receipt contains unhashed or unreadable audio")
    frame = manifest.merge(
        integrity[["clip_id", "sha256"]], on="clip_id", how="left", validate="one_to_one"
    ).rename(columns={"sha256": "content_sha256"})
    if frame.content_sha256.isna().any():
        raise ValueError("Not every manifest row has an integrity hash")
    frame["duplicate_group_size"] = frame.groupby("content_sha256")["clip_id"].transform(
        "size"
    )
    duplicate_rows = frame[frame.duplicate_group_size.gt(1)]
    metadata_columns = ["singer_id", "label", "context", "vowel", "key"]
    conflicts = []
    for content_hash, group in duplicate_rows.groupby("content_sha256"):
        for column in metadata_columns:
            if group[column].fillna("not_encoded").nunique() > 1:
                conflicts.append({"content_sha256": content_hash, "column": column})
    if conflicts:
        raise ValueError(f"Duplicate audio has conflicting metadata: {conflicts}")
    frame["copy_suffix"] = frame.file_name.str.contains(r"\(\d+\)", regex=True)
    ranked = frame.sort_values(
        ["content_sha256", "copy_suffix", "relative_path"], kind="stable"
    )
    retained_ids = set(ranked.drop_duplicates("content_sha256", keep="first").clip_id)
    frame["retained_for_modeling"] = frame.clip_id.isin(retained_ids)
    frame["exclusion_reason"] = frame.retained_for_modeling.map(
        {True: "", False: "duplicate_content_copy"}
    )
    model_manifest = frame[frame.retained_for_modeling].drop(
        columns=["copy_suffix", "retained_for_modeling", "exclusion_reason"]
    )
    model_manifest = model_manifest.sort_values(
        ["singer_id", "label", "context", "relative_path"], kind="stable"
    ).reset_index(drop=True)
    if model_manifest.content_sha256.duplicated().any():
        raise AssertionError("Content deduplication did not produce unique hashes")
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    model_manifest.to_csv(output / "manifest.csv", index=False)
    frame.drop(columns=["copy_suffix"]).to_csv(
        output / "deduplication_adjudication.csv", index=False
    )
    audit = manifest_audit(model_manifest)
    audit.update(
        {
            "source_sample_count": len(frame),
            "model_sample_count": len(model_manifest),
            "excluded_duplicate_rows": int((~frame.retained_for_modeling).sum()),
            "unique_content_hashes": int(model_manifest.content_sha256.nunique()),
            "deduplication_rule": (
                "Within exact SHA-256 groups with identical metadata, retain the lexicographically "
                "first path after preferring filenames without a '(number)' copy suffix."
            ),
        }
    )
    (output / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    for name, table in coverage_tables(model_manifest).items():
        table.to_csv(output / f"coverage_{name}.csv")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
