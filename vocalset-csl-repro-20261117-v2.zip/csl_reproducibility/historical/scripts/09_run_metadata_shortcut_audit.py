"""Measure how well non-acoustic metadata alone predicts the labels."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import aligned_probability
from vocalset_csl.splitting import leave_one_group_out
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument("--task", default="all_17")
    parser.add_argument(
        "--output-dir", default='data/results/metadata_shortcuts'
    )
    return parser.parse_args()


def make_model(categorical: list[str], numeric: list[str]) -> Pipeline:
    transformers = []
    if categorical:
        transformers.append(
            (
                "categorical",
                Pipeline(
                    [
                        # Missing filename metadata is itself a potential corpus
                        # shortcut, so preserve it as an explicit category.
                        (
                            "impute",
                            SimpleImputer(
                                strategy="constant",
                                fill_value="not_encoded",
                                keep_empty_features=True,
                            ),
                        ),
                        ("onehot", OneHotEncoder(handle_unknown="ignore")),
                    ]
                ),
                categorical,
            )
        )
    if numeric:
        transformers.append(
            (
                "numeric",
                Pipeline(
                    [("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]
                ),
                numeric,
            )
        )
    return Pipeline(
        [
            ("features", ColumnTransformer(transformers)),
            (
                "model",
                LogisticRegression(class_weight="balanced", max_iter=5000, C=1.0),
            ),
        ]
    )


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    y = frame.target.to_numpy(dtype=int)
    groups = frame.singer_id.astype(str).to_numpy()
    variants = {
        "context_only": (["context"], []),
        "vowel_only": (["vowel"], []),
        "context_vowel_key": (["context", "vowel", "key"], []),
        "duration_only": ([], ["duration_seconds"]),
        "all_metadata": (["context", "vowel", "key"], ["duration_seconds"]),
    }
    predictions = []
    fold_metrics = []
    for variant, (categorical, numeric) in variants.items():
        columns = categorical + numeric
        for split in leave_one_group_out(groups):
            model = make_model(categorical, numeric)
            model.fit(frame.iloc[split.train][columns], y[split.train])
            probability = aligned_probability(model, frame.iloc[split.test][columns], len(labels))
            fold_metrics.append(
                {
                    "variant": variant,
                    "outer_split": split.split_id,
                    "held_out_singer": groups[split.test][0],
                    **classification_metrics(y[split.test], probability, len(labels)),
                }
            )
            for row_index, prob in zip(split.test, probability):
                predictions.append(
                    {
                        "variant": variant,
                        "clip_id": str(frame.iloc[row_index].clip_id),
                        "outer_split": split.split_id,
                        "true_label": int(y[row_index]),
                        "predicted_label": int(prob.argmax()),
                        "probabilities": json.dumps(prob.tolist()),
                    }
                )
    prediction_frame = pd.DataFrame(predictions)
    pooled = []
    for variant, group in prediction_frame.groupby("variant"):
        probability = np.stack(group.probabilities.map(json.loads))
        pooled.append(
            {
                "variant": variant,
                **classification_metrics(group.true_label.to_numpy(dtype=int), probability, len(labels)),
            }
        )
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    prediction_frame.to_csv(output / "predictions.csv", index=False)
    pd.DataFrame(fold_metrics).to_csv(output / "singer_fold_metrics.csv", index=False)
    (output / "summary.json").write_text(
        json.dumps({"task": args.task, "labels": labels, "pooled_metrics": pooled}, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({"output": str(output), "variants": list(variants)}, indent=2))


if __name__ == "__main__":
    main()
