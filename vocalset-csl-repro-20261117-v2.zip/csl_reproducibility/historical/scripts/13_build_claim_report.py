"""Translate completed results into constrained, outcome-dependent claim routes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--main-summary", required=True)
    parser.add_argument("--cross-context-summary", required=True)
    parser.add_argument("--metadata-summary", required=True)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def method_map(summary: dict) -> dict[str, dict]:
    return {row["method"]: row for row in summary["pooled_metrics"]}


def main() -> None:
    args = parse_args()
    main_summary = json.loads(Path(args.main_summary).read_text(encoding="utf-8"))
    cross = json.loads(Path(args.cross_context_summary).read_text(encoding="utf-8"))
    metadata = json.loads(Path(args.metadata_summary).read_text(encoding="utf-8"))
    methods = method_map(main_summary)
    fused = methods["late_fusion_calibrated"]
    ssl = methods["ssl_calibrated"]
    gain = float(fused["macro_f1_present"] - ssl["macro_f1_present"])
    comparison = next(
        row
        for row in main_summary["paired_singer_clustered_inference"]
        if row["baseline"] == "ssl_calibrated" and row["metric"] == "macro_f1_present"
    )
    cross_fused = [
        row
        for row in cross["pooled_metrics_by_direction"]
        if row["method"] == "late_fusion_calibrated"
    ]
    mean_cross = sum(float(row["macro_f1_present"]) for row in cross_fused) / len(cross_fused)
    context_drop = float(fused["macro_f1_present"] - mean_cross)
    metadata_rows = {row["variant"]: row for row in metadata["pooled_metrics"]}
    metadata_score = float(metadata_rows["all_metadata"]["macro_f1_present"])
    chance = 1.0 / len(main_summary["labels"])
    route_a = (
        gain >= 0.01
        and float(comparison["ci95_low"]) > 0
        and float(fused["ece"]) <= float(ssl["ece"]) + 0.01
    )
    route_b = gain < 0.01
    route_c = context_drop >= 0.10
    route_d = metadata_score >= max(chance + 0.10, 0.5 * float(fused["macro_f1_present"]))
    report = {
        "fusion_macro_f1_gain_vs_calibrated_ssl": gain,
        "fusion_singer_cluster_ci95": [comparison["ci95_low"], comparison["ci95_high"]],
        "same_context_fused_macro_f1": fused["macro_f1_present"],
        "mean_cross_context_fused_macro_f1": mean_cross,
        "cross_context_drop": context_drop,
        "all_metadata_macro_f1": metadata_score,
        "chance_reference": chance,
        "routes": {
            "A_fusion_survives": route_a,
            "B_strong_ssl_removes_fusion_gain": route_b,
            "C_context_transfer_collapse": route_c,
            "D_all17_metadata_shortcut": route_d,
        },
        "claim_constraints": [
            "Do not claim fusion superiority unless Route A is true.",
            "Do not headline all-17 technique recognition if Route D is true.",
            "Report cross-context collapse regardless of direction or significance.",
            "Do not infer pedagogical effectiveness from classification metrics.",
        ],
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

