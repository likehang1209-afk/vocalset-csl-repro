"""Build the canonical audio manifest and dataset audit reports."""

from __future__ import annotations

import argparse
import json
import wave
from pathlib import Path

from vocalset_csl.audit import coverage_tables, manifest_audit
from vocalset_csl.manifest import build_manifest


def duration_seconds(path: Path) -> float:
    with wave.open(str(path), "rb") as handle:
        return handle.getnframes() / handle.getframerate()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--audio-root", default='data/extracted/canonical'
    )
    parser.add_argument(
        "--output-dir", default='data/manifests/canonical'
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = Path(args.audio_root).resolve()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    paths = sorted(
        path for path in root.rglob("*") if path.is_file() and path.suffix.lower() in {".wav", ".flac"}
    )
    manifest = build_manifest(paths)
    manifest["absolute_path"] = manifest["path"].map(lambda value: str(Path(value).resolve()))
    manifest["relative_path"] = manifest["canonical_path"]
    manifest["file_bytes"] = manifest["absolute_path"].map(lambda value: Path(value).stat().st_size)
    durations = []
    duration_errors = []
    for value in manifest["absolute_path"]:
        try:
            durations.append(duration_seconds(Path(value)))
            duration_errors.append("")
        except Exception as error:  # noqa: BLE001 - audit every unreadable corpus file
            durations.append(float("nan"))
            duration_errors.append(repr(error))
    manifest["duration_seconds"] = durations
    manifest["duration_error"] = duration_errors
    manifest.to_csv(output / "manifest.csv", index=False)
    audit = manifest_audit(manifest)
    (output / "audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    for name, table in coverage_tables(manifest).items():
        table.to_csv(output / f"coverage_{name}.csv")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
