"""Verify completion, alignment, shape, and finiteness of GPU embedding stores."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.feature_io import manifest_fingerprint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument("--embedding-root", required=True)
    parser.add_argument("--models", required=True)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    manifest = pd.read_csv(args.manifest, dtype={"clip_id": str})
    if args.limit:
        manifest = manifest.head(args.limit).copy()
    expected_ids = manifest.clip_id.astype(str).to_numpy()
    expected_fingerprint = manifest_fingerprint(expected_ids)
    reports = []
    failures = []
    for model_key in [item.strip() for item in args.models.split(",") if item.strip()]:
        root = Path(args.embedding_root) / model_key
        try:
            metadata = json.loads((root / "metadata.json").read_text(encoding="utf-8"))
            model_revision = metadata.get("model_revision")
            if not model_revision:
                raise ValueError("model revision is missing from embedding metadata")
            configured = config["ssl_models"].get(model_key)
            if metadata.get("model_id") != "mock/deterministic" and configured:
                if metadata.get("model_id") != configured["model_id"]:
                    raise ValueError("model ID differs from the protocol configuration")
                if model_revision != configured["revision"]:
                    raise ValueError("model revision differs from the protocol configuration")
            clip_ids = np.load(root / "clip_ids.npy", allow_pickle=False).astype(str)
            status = np.load(root / "status.npy", allow_pickle=False)
            if not np.array_equal(clip_ids, expected_ids):
                raise ValueError("clip IDs or order differ from the manifest")
            if metadata.get("manifest_fingerprint") != expected_fingerprint:
                raise ValueError("manifest fingerprint differs from the expected fingerprint")
            if status.shape != (len(expected_ids),) or not status.all():
                raise ValueError(f"incomplete status: {int(status.sum())}/{len(expected_ids)}")
            layer_reports = []
            for layer in metadata["layers"]:
                values = np.load(root / layer["file"], mmap_mode="r")
                expected_shape = (len(expected_ids), int(layer["dimension"]))
                if values.shape != expected_shape:
                    raise ValueError(
                        f"{layer['file']} shape {values.shape} differs from {expected_shape}"
                    )
                finite = bool(np.isfinite(values).all())
                if not finite:
                    raise ValueError(f"{layer['file']} contains NaN or infinity")
                all_zero_rows = int(np.all(values == 0, axis=1).sum())
                if all_zero_rows:
                    raise ValueError(f"{layer['file']} contains {all_zero_rows} all-zero rows")
                layer_reports.append(
                    {
                        "index": int(layer["index"]),
                        "file": layer["file"],
                        "shape": list(values.shape),
                        "minimum": float(values.min()),
                        "maximum": float(values.max()),
                        "mean": float(values.mean()),
                        "standard_deviation": float(values.std()),
                    }
                )
            reports.append(
                {
                    "model_key": model_key,
                    "model_id": metadata["model_id"],
                    "model_revision": model_revision,
                    "clip_count": len(expected_ids),
                    "layer_count": len(layer_reports),
                    "layers": layer_reports,
                    "valid": True,
                }
            )
        except Exception as error:  # noqa: BLE001 - aggregate every failed model store
            failures.append({"model_key": model_key, "error": repr(error)})
    result = {
        "manifest_fingerprint": expected_fingerprint,
        "clip_count": len(expected_ids),
        "models": reports,
        "failures": failures,
        "all_valid": not failures,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    if failures:
        raise SystemExit(f"Embedding verification failed for {len(failures)} models")


if __name__ == "__main__":
    main()
