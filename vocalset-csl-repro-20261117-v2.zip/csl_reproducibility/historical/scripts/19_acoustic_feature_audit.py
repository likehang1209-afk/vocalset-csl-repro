"""Audit the completed acoustic matrix before any classifier is fitted."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.feature_families import feature_family
from vocalset_csl.feature_io import align_feature_rows, load_feature_npz


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest", default='data/manifests/canonical/manifest.csv'
    )
    parser.add_argument(
        "--acoustic",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument(
        "--output-dir", default='data/features/acoustic_audit'
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = pd.read_csv(args.manifest, dtype={"clip_id": str})
    item = load_feature_npz(args.acoustic)
    values = align_feature_rows(
        manifest.clip_id.astype(str).to_numpy(), item["clip_ids"], item["values"]
    ).astype(np.float64)
    names = item["feature_names"]
    if len(names) != len(set(names)):
        raise ValueError("Acoustic matrix contains duplicate feature names")
    feature_rows = []
    for index, name in enumerate(names):
        column = values[:, index]
        finite = column[np.isfinite(column)]
        feature_rows.append(
            {
                "feature": name,
                "family": feature_family(name),
                "finite_count": len(finite),
                "missing_count": int(np.isnan(column).sum()),
                "infinite_count": int(np.isinf(column).sum()),
                "missing_fraction": float(np.isnan(column).mean()),
                "unique_finite_values": len(np.unique(finite)),
                "mean": float(np.mean(finite)) if len(finite) else None,
                "standard_deviation": float(np.std(finite)) if len(finite) else None,
                "minimum": float(np.min(finite)) if len(finite) else None,
                "p01": float(np.percentile(finite, 1)) if len(finite) else None,
                "median": float(np.median(finite)) if len(finite) else None,
                "p99": float(np.percentile(finite, 99)) if len(finite) else None,
                "maximum": float(np.max(finite)) if len(finite) else None,
            }
        )
    feature_audit = pd.DataFrame(feature_rows)
    clip_audit = manifest[["clip_id", "relative_path", "singer_id", "label", "context"]].copy()
    clip_audit["missing_feature_count"] = np.isnan(values).sum(axis=1)
    clip_audit["infinite_feature_count"] = np.isinf(values).sum(axis=1)
    all_missing = feature_audit[feature_audit.finite_count.eq(0)]
    near_constant = feature_audit[feature_audit.unique_finite_values.le(1)]
    high_missing = feature_audit[feature_audit.missing_fraction.gt(0.20)]
    summary = {
        "clip_count": len(values),
        "feature_count": values.shape[1],
        "extractor_metadata": item["metadata"],
        "finite_fraction": float(np.isfinite(values).mean()),
        "nan_cell_count": int(np.isnan(values).sum()),
        "infinite_cell_count": int(np.isinf(values).sum()),
        "all_missing_feature_count": len(all_missing),
        "constant_feature_count": len(near_constant),
        "features_over_20_percent_missing": len(high_missing),
        "maximum_missing_features_per_clip": int(clip_audit.missing_feature_count.max()),
        "family_feature_counts": {
            str(key): int(value)
            for key, value in feature_audit.family.value_counts().items()
        },
    }
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    feature_audit.to_csv(output / "feature_audit.csv", index=False)
    clip_audit.to_csv(output / "clip_audit.csv", index=False)
    high_missing.to_csv(output / "features_high_missingness.csv", index=False)
    near_constant.to_csv(output / "features_constant.csv", index=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if len(all_missing) or summary["infinite_cell_count"]:
        raise SystemExit("Acoustic feature audit found unusable columns or infinite values")


if __name__ == "__main__":
    main()
