"""Held-singer grouped permutation importance for the selected late-fusion system."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.calibration import apply_temperature
from vocalset_csl.feature_families import group_feature_indices
from vocalset_csl.feature_io import (
    align_feature_rows,
    exclude_named_features,
    load_feature_npz,
)
from vocalset_csl.fusion import fuse_probabilities
from vocalset_csl.inference import paired_cluster_bootstrap
from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import aligned_probability, build_model, find_default_spec
from vocalset_csl.representation_io import load_multiple_embedding_stores
from vocalset_csl.splitting import leave_one_group_out
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--acoustic",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument(
        "--embedding-root", default='data/embeddings'
    )
    parser.add_argument("--models", default="mert95m,wavlm_base_plus,hubert_base,muq_large")
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument(
        "--selections",
        default='data/results/nested_loso/production_shared_6/inner_selections.csv',
    )
    parser.add_argument("--repeats", type=int, default=30)
    parser.add_argument("--seed", type=int, default=20260827)
    parser.add_argument(
        "--output-dir", default='data/results/grouped_permutation'
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    clip_ids = frame.clip_id.astype(str).to_numpy()
    groups = frame.singer_id.astype(str).to_numpy()
    y = frame.target.to_numpy(dtype=int)
    acoustic_file = load_feature_npz(args.acoustic)
    acoustic = align_feature_rows(clip_ids, acoustic_file["clip_ids"], acoustic_file["values"])
    acoustic, acoustic_names = exclude_named_features(
        acoustic,
        acoustic_file["feature_names"],
        config["acoustic_features"]["main_exclude"],
    )
    families = group_feature_indices(acoustic_names)
    model_keys = [item.strip() for item in args.models.split(",") if item.strip()]
    ssl, _ = load_multiple_embedding_stores(
        args.embedding_root,
        model_keys,
        clip_ids,
        config["layer_probe"]["normalized_depths"],
    )
    selections = pd.read_csv(args.selections).set_index("outer_split")
    rng = np.random.default_rng(args.seed)
    rows = []
    for fold_index, split in enumerate(leave_one_group_out(groups)):
        selected = selections.loc[split.split_id]
        acoustic_spec = find_default_spec("acoustic", selected.acoustic_model)
        ssl_spec = find_default_spec("ssl", selected.ssl_model)
        acoustic_model = build_model(acoustic_spec, args.seed + fold_index)
        ssl_model = build_model(ssl_spec, args.seed + 1000 + fold_index)
        acoustic_model.fit(acoustic[split.train], y[split.train])
        selected_ssl = ssl[selected.ssl_representation]
        ssl_model.fit(selected_ssl[split.train], y[split.train])
        ssl_probability = aligned_probability(ssl_model, selected_ssl[split.test], len(labels))
        ssl_probability = apply_temperature(ssl_probability, float(selected.ssl_temperature))
        acoustic_probability = aligned_probability(acoustic_model, acoustic[split.test], len(labels))
        acoustic_probability = apply_temperature(
            acoustic_probability, float(selected.acoustic_temperature)
        )
        baseline_probability = fuse_probabilities(
            acoustic_probability,
            ssl_probability,
            float(selected.fusion_acoustic_weight),
            selected.fusion_family,
        )
        baseline = classification_metrics(y[split.test], baseline_probability, len(labels))
        for family, columns in families.items():
            for repeat in range(args.repeats):
                permuted = acoustic[split.test].copy()
                order = rng.permutation(len(split.test))
                permuted[:, columns] = permuted[order][:, columns]
                probability = aligned_probability(acoustic_model, permuted, len(labels))
                probability = apply_temperature(probability, float(selected.acoustic_temperature))
                probability = fuse_probabilities(
                    probability,
                    ssl_probability,
                    float(selected.fusion_acoustic_weight),
                    selected.fusion_family,
                )
                result = classification_metrics(y[split.test], probability, len(labels))
                rows.append(
                    {
                        "outer_split": split.split_id,
                        "held_out_singer": groups[split.test][0],
                        "feature_family": family,
                        "feature_count": len(columns),
                        "repeat": repeat,
                        "macro_f1_drop": float(
                            baseline["macro_f1_present"] - result["macro_f1_present"]
                        ),
                        "uar_drop": float(baseline["uar_present"] - result["uar_present"]),
                        "nll_increase": float(result["nll"] - baseline["nll"]),
                    }
                )
    raw = pd.DataFrame(rows)
    singer_family = (
        raw.groupby(["held_out_singer", "feature_family", "feature_count"], as_index=False)[
            ["macro_f1_drop", "uar_drop", "nll_increase"]
        ]
        .mean()
    )
    inference = []
    for family, family_frame in singer_family.groupby("feature_family"):
        for metric in ("macro_f1_drop", "uar_drop", "nll_increase"):
            inference.append(
                {
                    "feature_family": family,
                    "feature_count": int(family_frame.feature_count.iloc[0]),
                    "metric": metric,
                    **paired_cluster_bootstrap(
                        family_frame[metric].to_numpy(),
                        replicates=int(config["evaluation"]["cluster_bootstrap_replicates"]),
                        seed=int(config["evaluation"]["cluster_bootstrap_seed"]),
                    ),
                }
            )
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    raw.to_csv(output / "permutation_repeats.csv", index=False)
    singer_family.to_csv(output / "singer_family_importance.csv", index=False)
    (output / "clustered_inference.json").write_text(json.dumps(inference, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(output), "families": list(families), "rows": len(raw)}, indent=2))


if __name__ == "__main__":
    main()
