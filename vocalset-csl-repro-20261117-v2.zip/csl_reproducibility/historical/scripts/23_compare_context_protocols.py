"""Pair mixed-context LOSO and single-source context transfer on identical test clips."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.inference import paired_cluster_bootstrap, paired_sign_flip_pvalue
from vocalset_csl.metrics import classification_metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--standard-predictions",
        default='data/results/acoustic_only_loso/production_shared_6/outer_predictions.csv',
    )
    parser.add_argument(
        "--transfer-predictions",
        default='data/results/acoustic_cross_context/production_shared_6/outer_predictions.csv',
    )
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument("--method", default="acoustic_calibrated")
    parser.add_argument("--class-count", type=int, default=6)
    parser.add_argument(
        "--output",
        default='data/results/acoustic_cross_context/production_shared_6/paired_protocol_comparison.json',
    )
    return parser.parse_args()


def decode(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    output["probability_array"] = output.probabilities.map(
        lambda value: np.asarray(json.loads(value), dtype=np.float64)
    )
    return output


def metrics_for(frame: pd.DataFrame, class_count: int) -> dict[str, object]:
    return classification_metrics(
        frame.true_label.to_numpy(dtype=int),
        np.stack(frame.probability_array.to_numpy()),
        class_count,
    )


def main() -> None:
    args = parse_args()
    metadata = pd.read_csv(args.manifest, dtype={"clip_id": str})[["clip_id", "context"]]
    standard = pd.read_csv(args.standard_predictions, dtype={"clip_id": str})
    transfer = pd.read_csv(args.transfer_predictions, dtype={"clip_id": str})
    standard = decode(standard[standard.method.eq(args.method)].merge(metadata, on="clip_id"))
    transfer = decode(transfer[transfer.method.eq(args.method)])
    if "direction" not in transfer:
        transfer["direction"] = transfer.outer_split.str.split("__").str[0]
    reports = []
    for direction, transfer_group in transfer.groupby("direction"):
        target_context = direction.split("_to_")[1]
        standard_group = standard[standard.context.eq(target_context)].copy()
        if set(standard_group.clip_id) != set(transfer_group.clip_id):
            raise ValueError(f"Test clip sets differ for direction {direction}")
        standard_group = standard_group.set_index("clip_id").loc[transfer_group.clip_id].reset_index()
        singer_rows = []
        for singer, cross_singer in transfer_group.groupby("singer_id"):
            standard_singer = standard_group[standard_group.singer_id.eq(singer)]
            cross_metrics = metrics_for(cross_singer, args.class_count)
            standard_metrics = metrics_for(standard_singer, args.class_count)
            singer_rows.append(
                {
                    "singer_id": singer,
                    "macro_f1_difference_transfer_minus_mixed": float(
                        cross_metrics["macro_f1_present"]
                        - standard_metrics["macro_f1_present"]
                    ),
                    "uar_difference_transfer_minus_mixed": float(
                        cross_metrics["uar_present"] - standard_metrics["uar_present"]
                    ),
                    "accuracy_difference_transfer_minus_mixed": float(
                        cross_metrics["accuracy"] - standard_metrics["accuracy"]
                    ),
                }
            )
        singer_frame = pd.DataFrame(singer_rows)
        inference = {}
        for metric in (
            "macro_f1_difference_transfer_minus_mixed",
            "uar_difference_transfer_minus_mixed",
            "accuracy_difference_transfer_minus_mixed",
        ):
            differences = singer_frame[metric].to_numpy()
            inference[metric] = {
                **paired_cluster_bootstrap(differences),
                "paired_sign_flip_p": paired_sign_flip_pvalue(differences),
            }
        reports.append(
            {
                "direction": direction,
                "target_context": target_context,
                "clip_count": len(transfer_group),
                "mixed_context_training": metrics_for(standard_group, args.class_count),
                "single_source_transfer": metrics_for(transfer_group, args.class_count),
                "paired_singer_inference": inference,
                "singer_differences": singer_rows,
            }
        )
    result = {
        "method": args.method,
        "difference_definition": "single-source transfer minus mixed-context LOSO",
        "directions": reports,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
