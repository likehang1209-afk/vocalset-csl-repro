"""Safely extract one explicitly selected VocalSet archive prefix."""

from __future__ import annotations

import argparse
import json
import shutil
import zipfile
from pathlib import Path, PurePosixPath

from vocalset_csl.zip_repair import open_repaired


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--archive", default='data/raw/VocalSet1-2.zip'
    )
    parser.add_argument("--prefix", required=True, help="Exact archive prefix chosen from inventory")
    parser.add_argument(
        "--output", default='data/extracted/canonical'
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    prefix = args.prefix.replace("\\", "/").strip("/") + "/"
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    selected = []
    with zipfile.ZipFile(args.archive) as archive:
        for item in archive.infolist():
            name = item.filename.replace("\\", "/")
            if item.is_dir() or not name.startswith(prefix):
                continue
            relative = PurePosixPath(name[len(prefix) :])
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"Unsafe archive path: {name}")
            destination = output.joinpath(*relative.parts).resolve()
            if output not in destination.parents:
                raise ValueError(f"Extraction escaped output root: {name}")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with open_repaired(archive, item) as source, destination.open("wb") as target:
                shutil.copyfileobj(source, target, length=8 * 1024 * 1024)
            selected.append(
                {"archive_path": name, "output_path": str(destination), "bytes": item.file_size}
            )
    if not selected:
        raise ValueError(f"Prefix matched no files: {prefix}")
    manifest = output / "extraction_receipt.json"
    manifest.write_text(json.dumps(selected, indent=2), encoding="utf-8")
    print(json.dumps({"prefix": prefix, "files": len(selected), "receipt": str(manifest)}, indent=2))


if __name__ == "__main__":
    main()
