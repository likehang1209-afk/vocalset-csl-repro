"""Inventory archive paths before selecting one of VocalSet's duplicate views."""

from __future__ import annotations

import argparse
import json
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath

from vocalset_csl.manifest import build_manifest
from vocalset_csl.zip_repair import resolve_header_offset


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--archive",
        default='data/raw/VocalSet1-2.zip',
    )
    parser.add_argument(
        "--output-dir",
        default='data/manifests/archive_inventory',
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.archive) as archive:
        items = [item for item in archive.infolist() if not item.is_dir()]
        corrected_offset_count = sum(
            resolve_header_offset(archive, item) != item.header_offset for item in items
        )
    names = [item.filename for item in items]
    audio_items = [
        item for item in items if PurePosixPath(item.filename).suffix.lower() in {".wav", ".flac"}
    ]
    audio = [item.filename for item in audio_items]
    manifest = build_manifest(audio)
    info = {
        item.filename: {
            "crc32": f"{item.CRC:08x}",
            "uncompressed_bytes": item.file_size,
            "compressed_bytes": item.compress_size,
        }
        for item in audio_items
    }
    for column in ("crc32", "uncompressed_bytes", "compressed_bytes"):
        manifest[column] = manifest["path"].map(
            lambda path, field=column: info[path][field]
        )
    manifest["duplicate_content_count"] = manifest.groupby(
        ["crc32", "uncompressed_bytes"]
    )["path"].transform("size")
    manifest.to_csv(output / "all_audio_paths.csv", index=False)
    prefix_counts = {}
    for depth in (1, 2, 3, 4):
        counts = Counter("/".join(PurePosixPath(path).parts[:depth]) for path in audio)
        prefix_counts[str(depth)] = dict(counts.most_common(100))
    summary = {
        "file_count": len(names),
        "malformed_zip64_offset_count": corrected_offset_count,
        "audio_file_count": len(audio),
        "unique_audio_crc_size_count": int(
            manifest[["crc32", "uncompressed_bytes"]].drop_duplicates().shape[0]
        ),
        "duplicated_audio_path_count": int(manifest["duplicate_content_count"].gt(1).sum()),
        "parsed_audio_count": int(manifest["parse_ok"].sum()),
        "unparsed_audio_count": int((~manifest["parse_ok"]).sum()),
        "prefix_counts": prefix_counts,
    }
    (output / "archive_inventory.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
