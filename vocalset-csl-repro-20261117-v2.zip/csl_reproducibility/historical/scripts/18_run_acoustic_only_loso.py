"""Run the complete nested acoustic baseline before renting a GPU."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from vocalset_csl.feature_io import (
    align_feature_rows,
    exclude_named_features,
    load_feature_npz,
)
from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import ModelSpec
from vocalset_csl.nested import run_nested_single_branch
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--acoustic",
        default='data/features/acoustic_egemaps_singing.npz',
    )
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument(
        "--output-dir", default='data/results/acoustic_only_loso'
    )
    parser.add_argument("--inner-splits", type=int, default=4)
    parser.add_argument("--fast-smoke", action="store_true")
    return parser.parse_args()


def pooled_metrics(predictions: pd.DataFrame, class_count: int) -> list[dict[str, object]]:
    rows = []
    for method, frame in predictions.groupby("method", sort=False):
        rows.append(
            {
                "method": method,
                **classification_metrics(
                    frame.true_label.to_numpy(dtype=int),
                    np.stack(frame.probabilities.to_numpy()),
                    class_count,
                ),
            }
        )
    return rows


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    clip_ids = frame.clip_id.astype(str).to_numpy()
    acoustic_file = load_feature_npz(args.acoustic)
    acoustic = align_feature_rows(clip_ids, acoustic_file["clip_ids"], acoustic_file["values"])
    excluded = config["acoustic_features"]["main_exclude"]
    acoustic, feature_names = exclude_named_features(
        acoustic, acoustic_file["feature_names"], excluded
    )
    specs = None
    if args.fast_smoke:
        specs = (ModelSpec.create("lr_c1", "logistic", c=1.0),)
    predictions, metrics, selections = run_nested_single_branch(
        acoustic,
        frame.target.to_numpy(dtype=int),
        frame.singer_id.astype(str).to_numpy(),
        clip_ids,
        class_count=len(labels),
        branch="acoustic",
        inner_splits=args.inner_splits,
        seed=int(config["evaluation"]["inner_seed"]),
        specs=specs,
    )
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    serializable = predictions.copy()
    serializable["probabilities"] = serializable.probabilities.map(json.dumps)
    serializable.to_csv(output / "outer_predictions.csv", index=False)
    metrics.to_csv(output / "singer_fold_metrics.csv", index=False)
    selections.to_csv(output / "inner_selections.csv", index=False)
    summary = {
        "protocol_id": config["protocol_id"],
        "task": args.task,
        "labels": labels,
        "clip_count": len(frame),
        "singer_count": int(frame.singer_id.nunique()),
        "acoustic_feature_count": len(feature_names),
        "acoustic_features_excluded": excluded,
        "pooled_metrics": pooled_metrics(predictions, len(labels)),
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
