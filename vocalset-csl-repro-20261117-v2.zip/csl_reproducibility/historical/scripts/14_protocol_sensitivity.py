"""Quantify performance and test reuse under file, grouped, and LOSO protocols."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit, StratifiedShuffleSplit

from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import ModelSpec, aligned_probability, build_model
from vocalset_csl.representation_io import load_multiple_embedding_stores
from vocalset_csl.splitting import Split, leave_one_group_out
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--embedding-root", default='data/embeddings'
    )
    parser.add_argument("--model", default="mert95m")
    parser.add_argument("--depth", type=float, default=0.5)
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument("--repeated-splits", type=int, default=50)
    parser.add_argument("--test-size", type=float, default=0.3)
    parser.add_argument("--seed", type=int, default=20260828)
    parser.add_argument(
        "--output-dir", default='data/results/protocol_sensitivity'
    )
    return parser.parse_args()


def sklearn_splits(splitter, y: np.ndarray, groups: np.ndarray | None, prefix: str) -> list[Split]:
    dummy = np.zeros((len(y), 1))
    iterator = splitter.split(dummy, y, groups) if groups is not None else splitter.split(dummy, y)
    return [
        Split(f"{prefix}_{index:02d}", np.asarray(train), np.asarray(test))
        for index, (train, test) in enumerate(iterator)
    ]


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    y = frame.target.to_numpy(dtype=int)
    groups = frame.singer_id.astype(str).to_numpy()
    clip_ids = frame.clip_id.astype(str).to_numpy()
    representations, metadata = load_multiple_embedding_stores(
        args.embedding_root,
        [args.model],
        clip_ids,
        [args.depth],
    )
    representation_name, x = next(iter(representations.items()))
    protocols = {
        "random_file_50": sklearn_splits(
            StratifiedShuffleSplit(
                n_splits=args.repeated_splits,
                test_size=args.test_size,
                random_state=args.seed,
            ),
            y,
            None,
            "random_file",
        ),
        "singer_group_shuffle_50": sklearn_splits(
            GroupShuffleSplit(
                n_splits=args.repeated_splits,
                test_size=args.test_size,
                random_state=args.seed,
            ),
            y,
            groups,
            "group_shuffle",
        ),
        "exact_loso": list(leave_one_group_out(groups)),
    }
    spec = ModelSpec.create("fixed_lr_c1", "logistic", c=1.0)
    metric_rows = []
    reuse_rows = []
    for protocol_name, splits in protocols.items():
        test_counts = np.zeros(len(frame), dtype=int)
        for split_index, split in enumerate(splits):
            model = build_model(spec, args.seed + split_index)
            model.fit(x[split.train], y[split.train])
            probability = aligned_probability(model, x[split.test], len(labels))
            metric_rows.append(
                {
                    "protocol": protocol_name,
                    "split_id": split.split_id,
                    "train_singer_count": len(np.unique(groups[split.train])),
                    "test_singer_count": len(np.unique(groups[split.test])),
                    "singer_overlap_count": len(
                        set(groups[split.train]).intersection(groups[split.test])
                    ),
                    **classification_metrics(y[split.test], probability, len(labels)),
                }
            )
            test_counts[split.test] += 1
        reuse_rows.append(
            {
                "protocol": protocol_name,
                "split_count": len(splits),
                "clips_never_tested": int(np.sum(test_counts == 0)),
                "test_appearances_min": int(test_counts.min()),
                "test_appearances_median": float(np.median(test_counts)),
                "test_appearances_mean": float(test_counts.mean()),
                "test_appearances_max": int(test_counts.max()),
            }
        )
    metrics = pd.DataFrame(metric_rows)
    summary = (
        metrics.groupby("protocol")[["accuracy", "macro_f1_present", "uar_present", "nll", "ece"]]
        .agg(["mean", "std"])
        .reset_index()
    )
    output = Path(args.output_dir) / args.task
    output.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(output / "split_metrics.csv", index=False)
    summary.to_csv(output / "metric_summary.csv", index=False)
    pd.DataFrame(reuse_rows).to_csv(output / "test_reuse.csv", index=False)
    (output / "metadata.json").write_text(
        json.dumps(
            {
                "task": args.task,
                "representation": representation_name,
                "embedding_metadata": metadata,
                "warning": "Repeated-split rows are descriptive and are not independent inferential units.",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(json.dumps({"output": str(output), "protocols": list(protocols)}, indent=2))


if __name__ == "__main__":
    main()
