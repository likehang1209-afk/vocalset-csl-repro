"""Extract and checkpoint every hidden layer for one configured SSL model."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import librosa
import numpy as np
import pandas as pd
import soundfile as sf

from vocalset_csl.ssl_extraction import EmbeddingStore, build_backend, window_audio


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument("--model-key", required=True)
    parser.add_argument(
        "--output-root", default='data/embeddings'
    )
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--precision", choices=("fp32", "fp16"), default="fp16")
    parser.add_argument("--window-batch-size", type=int, default=4)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--mock", action="store_true")
    return parser.parse_args()


def load_audio(path: str, target_rate: int) -> np.ndarray:
    audio, sample_rate = sf.read(path, dtype="float32", always_2d=False)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if sample_rate != target_rate:
        audio = librosa.resample(audio, orig_sr=sample_rate, target_sr=target_rate)
    return np.asarray(audio, dtype=np.float32)


def write_failures(path: Path, failures: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(failures, indent=2), encoding="utf-8")


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    if args.model_key not in config["ssl_models"] and not args.mock:
        raise KeyError(f"Unknown model key: {args.model_key}")
    model = (
        {
            "model_id": "mock/deterministic",
            "revision": "local-mock-v1",
            "backend": "mock",
            "sample_rate": 16000,
        }
        if args.mock
        else config["ssl_models"][args.model_key]
    )
    precision = "fp32" if model.get("force_fp32") else args.precision
    window = config["windowing"]
    manifest = pd.read_csv(args.manifest)
    if args.limit:
        manifest = manifest.head(args.limit).copy()
    backend = build_backend(
        model["backend"],
        model["model_id"],
        model["revision"],
        int(model["sample_rate"]),
        args.device,
        precision,
    )
    store = EmbeddingStore(
        Path(args.output_root) / args.model_key,
        manifest["clip_id"].astype(str).to_numpy(),
        model["model_id"],
        model["revision"],
        int(model["sample_rate"]),
        float(window["window_seconds"]),
        float(window["hop_seconds"]),
    )
    failures = []
    run_started = time.perf_counter()
    for index, row in manifest.reset_index(drop=True).iterrows():
        if hasattr(store, "status") and bool(store.status[index]):
            continue
        try:
            clip_started = time.perf_counter()
            audio = load_audio(row.absolute_path, int(model["sample_rate"]))
            windows, lengths = window_audio(
                audio,
                int(model["sample_rate"]),
                float(window["window_seconds"]),
                float(window["hop_seconds"]),
            )
            vectors = backend.extract(windows, lengths, args.window_batch_size)
            store.initialise(vectors)
            store.write(index, vectors)
            elapsed = time.perf_counter() - clip_started
            print(
                json.dumps(
                    {
                        "model": args.model_key,
                        "clip": index + 1,
                        "total": len(manifest),
                        "windows": len(windows),
                        "layers": len(vectors),
                        "audio_seconds": len(audio) / int(model["sample_rate"]),
                        "elapsed_seconds": elapsed,
                        "processing_to_audio_ratio": elapsed
                        / max(len(audio) / int(model["sample_rate"]), 1e-9),
                    }
                ),
                flush=True,
            )
        except Exception as error:
            failures.append({"index": index, "clip_id": str(row.clip_id), "error": repr(error)})
            print(json.dumps({"event": "failure", **failures[-1]}), flush=True)
            if "out of memory" in str(error).lower():
                failure_path = Path(args.output_root) / args.model_key / "failures.json"
                write_failures(failure_path, failures)
                raise SystemExit(
                    "CUDA out of memory; extraction stopped immediately. "
                    "Resume with a smaller --window-batch-size."
                ) from error
    if failures:
        failure_path = Path(args.output_root) / args.model_key / "failures.json"
        write_failures(failure_path, failures)
        raise SystemExit(f"Extraction failed for {len(failures)} clips")
    print(
        json.dumps(
            {
                "event": "model_complete",
                "model": args.model_key,
                "clips": store.complete_count(),
                "output": str(store.root),
                "elapsed_seconds": time.perf_counter() - run_started,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
