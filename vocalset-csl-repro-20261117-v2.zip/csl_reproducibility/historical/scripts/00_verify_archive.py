"""Verify the downloaded VocalSet archive before any extraction."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

EXPECTED_BYTES = 5_991_573_193
EXPECTED_MD5 = "c5e5efab412637fc94972b93c343a2f0"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--archive",
        default='data/raw/VocalSet1-2.zip',
    )
    parser.add_argument("--chunk-mb", type=int, default=16)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    archive = Path(args.archive)
    if not archive.exists():
        raise FileNotFoundError(archive)
    size = archive.stat().st_size
    digest = hashlib.md5()
    with archive.open("rb") as handle:
        for chunk in iter(lambda: handle.read(args.chunk_mb * 1024 * 1024), b""):
            digest.update(chunk)
    observed = digest.hexdigest()
    result = {
        "archive": str(archive),
        "bytes": size,
        "expected_bytes": EXPECTED_BYTES,
        "md5": observed,
        "expected_md5": EXPECTED_MD5,
        "size_ok": size == EXPECTED_BYTES,
        "md5_ok": observed == EXPECTED_MD5,
    }
    print(json.dumps(result, indent=2))
    if not result["size_ok"] or not result["md5_ok"]:
        raise SystemExit("Archive verification failed")


if __name__ == "__main__":
    main()

