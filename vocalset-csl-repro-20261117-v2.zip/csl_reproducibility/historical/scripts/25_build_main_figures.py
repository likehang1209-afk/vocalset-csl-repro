"""Build publication-ready figures from a completed nested LOSO evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

from vocalset_csl.metrics import classification_metrics


METHOD_ORDER = (
    "acoustic",
    "acoustic_calibrated",
    "ssl",
    "ssl_calibrated",
    "early_fusion",
    "late_fusion_calibrated",
)

METHOD_LABELS = {
    "acoustic": "Acoustic",
    "acoustic_calibrated": "Acoustic + calibration",
    "ssl": "SSL",
    "ssl_calibrated": "SSL + calibration",
    "early_fusion": "Early fusion",
    "late_fusion_calibrated": "Late fusion + calibration",
}

METHOD_COLORS = {
    "acoustic": "#4C78A8",
    "acoustic_calibrated": "#72B7B2",
    "ssl": "#F58518",
    "ssl_calibrated": "#ECA82C",
    "early_fusion": "#54A24B",
    "late_fusion_calibrated": "#B279A2",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    return parser.parse_args()


def load_predictions(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    frame["probabilities"] = frame["probabilities"].map(json.loads)
    return frame


def representation_label(value: str) -> str:
    model, descriptor = value.split("__", maxsplit=1)
    detail = descriptor.replace("depth_", "d=").replace("_layer_", " | L")
    return f"{model} | {detail}"


def reliability_rows(probability: np.ndarray, truth: np.ndarray, bins: int = 15) -> pd.DataFrame:
    confidence = probability.max(axis=1)
    correct = probability.argmax(axis=1) == truth
    index = np.clip((confidence * bins).astype(int), 0, bins - 1)
    rows = []
    for bin_index in range(bins):
        mask = index == bin_index
        if mask.any():
            rows.append(
                {
                    "mean_confidence": float(confidence[mask].mean()),
                    "accuracy": float(correct[mask].mean()),
                    "count": int(mask.sum()),
                }
            )
    return pd.DataFrame(rows)


def save_metric_table(predictions: pd.DataFrame, class_count: int, output: Path) -> None:
    rows = []
    for method in METHOD_ORDER:
        frame = predictions[predictions.method.eq(method)]
        probability = np.stack(frame.probabilities.to_numpy())
        rows.append(
            {
                "method": method,
                "method_label": METHOD_LABELS[method],
                **classification_metrics(
                    frame.true_label.to_numpy(dtype=int), probability, class_count
                ),
            }
        )
    pd.DataFrame(rows).to_csv(output / "pooled_main_metrics.csv", index=False)


def plot_held_singer_metrics(metrics: pd.DataFrame, output: Path) -> None:
    import matplotlib.pyplot as plt

    pivot = metrics.pivot(index="held_out_singer", columns="method", values="macro_f1_present")
    ordered = [method for method in METHOD_ORDER if method in pivot.columns]
    pivot = pivot[ordered]
    figure, axis = plt.subplots(figsize=(12.0, 5.2), constrained_layout=True)
    positions = np.arange(len(ordered))
    for _, row in pivot.iterrows():
        axis.plot(positions, row.to_numpy(), color="#C8C8C8", linewidth=0.8, alpha=0.65, zorder=1)
    for index, method in enumerate(ordered):
        values = pivot[method].dropna().to_numpy()
        axis.scatter(
            np.full(len(values), index),
            values,
            s=24,
            color=METHOD_COLORS[method],
            edgecolor="white",
            linewidth=0.5,
            zorder=3,
        )
        standard_error = values.std(ddof=1) / np.sqrt(len(values)) if len(values) > 1 else 0.0
        axis.errorbar(
            index,
            values.mean(),
            yerr=standard_error,
            color="#202020",
            fmt="D",
            markersize=5,
            capsize=3,
            zorder=4,
        )
    axis.set_xticks(positions, [METHOD_LABELS[method] for method in ordered], rotation=20, ha="right")
    axis.set_ylabel("Held-singer macro-F1")
    axis.set_ylim(0.0, 1.02)
    axis.grid(axis="y", color="#E4E4E4", linewidth=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    figure.savefig(output / "figure_02_held_singer_macro_f1.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


def plot_selection_frequency(selections: pd.DataFrame, output: Path) -> None:
    import matplotlib.pyplot as plt

    counts = selections.ssl_representation.value_counts().sort_values()
    labels = [representation_label(value) for value in counts.index]
    figure, axis = plt.subplots(figsize=(10.5, max(3.5, 0.42 * len(counts))), constrained_layout=True)
    bars = axis.barh(labels, counts.to_numpy(), color="#4C78A8")
    axis.bar_label(bars, padding=3, fontsize=8)
    axis.set_xlabel("Outer folds selecting representation")
    axis.set_ylabel("SSL representation")
    axis.set_xlim(0, max(1, int(counts.max())) + 1)
    axis.grid(axis="x", color="#E4E4E4", linewidth=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    figure.savefig(output / "figure_03_ssl_selection_frequency.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


def plot_confusion(predictions: pd.DataFrame, labels: list[str], output: Path) -> None:
    import matplotlib.pyplot as plt

    frame = predictions[predictions.method.eq("late_fusion_calibrated")]
    matrix = confusion_matrix(
        frame.true_label.to_numpy(dtype=int),
        frame.predicted_label.to_numpy(dtype=int),
        labels=np.arange(len(labels)),
        normalize="true",
    )
    figure, axis = plt.subplots(figsize=(7.3, 6.1), constrained_layout=True)
    image = axis.imshow(matrix, cmap="Blues", vmin=0.0, vmax=1.0)
    axis.set_xticks(np.arange(len(labels)), labels, rotation=40, ha="right")
    axis.set_yticks(np.arange(len(labels)), labels)
    axis.set_xlabel("Predicted technique")
    axis.set_ylabel("True technique")
    for row in range(len(labels)):
        for column in range(len(labels)):
            value = matrix[row, column]
            axis.text(
                column,
                row,
                f"{value:.2f}",
                ha="center",
                va="center",
                fontsize=8,
                color="white" if value > 0.55 else "#202020",
            )
    colorbar = figure.colorbar(image, ax=axis, fraction=0.05, pad=0.04)
    colorbar.set_label("Row-normalized proportion")
    figure.savefig(output / "figure_04_late_fusion_confusion.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


def plot_reliability(predictions: pd.DataFrame, output: Path) -> None:
    import matplotlib.pyplot as plt

    methods = ("acoustic_calibrated", "ssl_calibrated", "late_fusion_calibrated")
    figure, axis = plt.subplots(figsize=(6.6, 5.6), constrained_layout=True)
    axis.plot([0, 1], [0, 1], linestyle="--", color="#6E6E6E", linewidth=1.0, label="Perfect calibration")
    for method in methods:
        frame = predictions[predictions.method.eq(method)]
        reliability = reliability_rows(
            np.stack(frame.probabilities.to_numpy()), frame.true_label.to_numpy(dtype=int)
        )
        axis.plot(
            reliability.mean_confidence,
            reliability.accuracy,
            marker="o",
            markersize=4,
            linewidth=1.8,
            color=METHOD_COLORS[method],
            label=METHOD_LABELS[method],
        )
    axis.set_xlim(0.0, 1.0)
    axis.set_ylim(0.0, 1.0)
    axis.set_xlabel("Mean predicted confidence")
    axis.set_ylabel("Observed accuracy")
    axis.legend(frameon=False, loc="upper left", fontsize=8)
    axis.grid(color="#E4E4E4", linewidth=0.8)
    axis.spines[["top", "right"]].set_visible(False)
    figure.savefig(output / "figure_05_reliability.png", dpi=600, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    results = Path(args.results_dir)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    summary = json.loads((results / "summary.json").read_text(encoding="utf-8"))
    labels = summary["labels"]
    predictions = load_predictions(results / "outer_predictions.csv")
    metrics = pd.read_csv(results / "singer_fold_metrics.csv")
    selections = pd.read_csv(results / "inner_selections.csv")
    save_metric_table(predictions, len(labels), output)
    plot_held_singer_metrics(metrics, output)
    plot_selection_frequency(selections, output)
    plot_confusion(predictions, labels, output)
    plot_reliability(predictions, output)
    print(json.dumps({"output": str(output), "figures": 4}, indent=2))


if __name__ == "__main__":
    main()
