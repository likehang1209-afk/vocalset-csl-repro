"""Create a content-hash and audio-header integrity receipt for the canonical corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd
import soundfile as sf

from vocalset_csl.feature_io import manifest_fingerprint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest", default='data/manifests/canonical/manifest.csv'
    )
    parser.add_argument(
        "--output-dir", default='data/manifests/integrity'
    )
    return parser.parse_args()


def sha256_file(path: Path, chunk_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    args = parse_args()
    manifest = pd.read_csv(args.manifest, dtype={"clip_id": str})
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for index, row in enumerate(manifest.itertuples(index=False), start=1):
        path = Path(row.absolute_path)
        record: dict[str, object] = {
            "clip_id": str(row.clip_id),
            "relative_path": str(row.relative_path),
            "exists": path.is_file(),
            "sha256": None,
            "sample_rate": None,
            "channels": None,
            "frames": None,
            "format": None,
            "subtype": None,
            "duration_header_seconds": None,
            "duration_difference_seconds": None,
            "error": None,
        }
        try:
            info = sf.info(path)
            header_duration = float(info.frames / info.samplerate)
            record.update(
                {
                    "sha256": sha256_file(path),
                    "sample_rate": int(info.samplerate),
                    "channels": int(info.channels),
                    "frames": int(info.frames),
                    "format": str(info.format),
                    "subtype": str(info.subtype),
                    "duration_header_seconds": header_duration,
                    "duration_difference_seconds": abs(
                        header_duration - float(row.duration_seconds)
                    ),
                }
            )
        except Exception as error:  # noqa: BLE001 - report every corrupt or missing file
            record["error"] = repr(error)
        rows.append(record)
        if index == 1 or index % 250 == 0 or index == len(manifest):
            print(json.dumps({"audited": index, "total": len(manifest)}), flush=True)
    receipt = pd.DataFrame(rows)
    duplicates = receipt[
        receipt["sha256"].notna() & receipt.duplicated("sha256", keep=False)
    ].sort_values(["sha256", "relative_path"])
    errors = receipt[receipt["error"].notna() | ~receipt["exists"]]
    summary = {
        "sample_count": len(manifest),
        "manifest_fingerprint": manifest_fingerprint(
            manifest["clip_id"].astype(str).to_numpy()
        ),
        "unique_clip_ids": int(manifest["clip_id"].nunique()),
        "unique_relative_paths": int(manifest["relative_path"].nunique()),
        "read_error_count": len(errors),
        "duplicate_hash_row_count": len(duplicates),
        "unique_content_hashes": int(receipt["sha256"].nunique(dropna=True)),
        "sample_rate_counts": {
            str(key): int(value)
            for key, value in receipt["sample_rate"].value_counts(dropna=False).items()
        },
        "channel_counts": {
            str(key): int(value)
            for key, value in receipt["channels"].value_counts(dropna=False).items()
        },
        "format_counts": {
            str(key): int(value)
            for key, value in receipt["format"].value_counts(dropna=False).items()
        },
        "subtype_counts": {
            str(key): int(value)
            for key, value in receipt["subtype"].value_counts(dropna=False).items()
        },
        "maximum_duration_discrepancy_seconds": float(
            receipt["duration_difference_seconds"].max()
        ),
    }
    receipt.to_csv(output / "audio_integrity.csv", index=False)
    duplicates.to_csv(output / "duplicate_content.csv", index=False)
    errors.to_csv(output / "read_errors.csv", index=False)
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if len(errors):
        raise SystemExit("Corpus integrity audit found missing or unreadable audio")
    if len(duplicates):
        print("Duplicate content requires deterministic adjudication before modeling.")


if __name__ == "__main__":
    main()
