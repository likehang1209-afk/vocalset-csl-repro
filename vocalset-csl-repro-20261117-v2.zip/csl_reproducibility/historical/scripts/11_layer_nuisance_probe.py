"""Probe technique information against context, vowel, and singer shortcuts by layer."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

from vocalset_csl.metrics import classification_metrics
from vocalset_csl.modeling import ModelSpec, aligned_probability, build_model
from vocalset_csl.representation_io import load_multiple_embedding_stores
from vocalset_csl.splitting import Split, leave_one_group_out
from vocalset_csl.tasks import select_task


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/protocol_v2.json")
    parser.add_argument(
        "--manifest", default='data/manifests/modeling/manifest.csv'
    )
    parser.add_argument(
        "--embedding-root", default='data/embeddings'
    )
    parser.add_argument("--models", default="mert95m,wavlm_base_plus,hubert_base,muq_large")
    parser.add_argument("--task", default="production_shared_6")
    parser.add_argument(
        "--output", default='data/results/layer_nuisance_probe.csv'
    )
    return parser.parse_args()


def pooled_oof(
    x: np.ndarray,
    y: np.ndarray,
    splits: list[Split],
    class_count: int,
    seed: int,
) -> dict[str, object]:
    spec = ModelSpec.create("probe_lr", "logistic", c=1.0)
    probability = np.full((len(y), class_count), np.nan, dtype=np.float64)
    for index, split in enumerate(splits):
        model = build_model(spec, seed + index)
        model.fit(x[split.train], y[split.train])
        probability[split.test] = aligned_probability(model, x[split.test], class_count)
    observed = np.isfinite(probability).all(axis=1)
    return classification_metrics(y[observed], probability[observed], class_count)


def random_file_splits(y: np.ndarray, folds: int, seed: int) -> list[Split]:
    splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    dummy = np.zeros((len(y), 1))
    return [
        Split(f"random_file_{index}", np.asarray(train), np.asarray(test))
        for index, (train, test) in enumerate(splitter.split(dummy, y))
    ]


def main() -> None:
    args = parse_args()
    config = json.loads(Path(args.config).read_text(encoding="utf-8"))
    frame = pd.read_csv(args.manifest)
    frame, labels = select_task(frame, config, args.task)
    clip_ids = frame.clip_id.astype(str).to_numpy()
    model_keys = [item.strip() for item in args.models.split(",") if item.strip()]
    representations, _ = load_multiple_embedding_stores(
        args.embedding_root,
        model_keys,
        clip_ids,
        config["layer_probe"]["normalized_depths"],
    )
    all_indices = np.arange(len(frame))
    groups = frame.singer_id.astype(str).to_numpy()
    targets = {
        "technique_singer_disjoint": (
            all_indices,
            frame.target.to_numpy(dtype=int),
            list(leave_one_group_out(groups)),
            len(labels),
            "Primary useful information",
        ),
        "context_singer_disjoint": (
            all_indices,
            pd.Categorical(frame.context).codes,
            list(leave_one_group_out(groups)),
            frame.context.nunique(),
            "Shared-context shortcut information",
        ),
    }
    vowel_indices = np.flatnonzero(frame.vowel.notna().to_numpy())
    vowel_groups = groups[vowel_indices]
    targets["vowel_singer_disjoint"] = (
        vowel_indices,
        pd.Categorical(frame.iloc[vowel_indices].vowel).codes,
        list(leave_one_group_out(vowel_groups)),
        frame.iloc[vowel_indices].vowel.nunique(),
        "Vowel-content information",
    )
    singer_target = pd.Categorical(frame.singer_id).codes
    targets["singer_random_file_diagnostic"] = (
        all_indices,
        singer_target,
        random_file_splits(singer_target, 5, int(config["evaluation"]["inner_seed"])),
        frame.singer_id.nunique(),
        "Diagnostic only; random-file singer identifiability",
    )
    rows = []
    for representation_name, x in representations.items():
        for probe_name, (
            indices,
            target,
            splits,
            class_count,
            interpretation,
        ) in targets.items():
            rows.append(
                {
                    "representation": representation_name,
                    "probe": probe_name,
                    "interpretation": interpretation,
                    "sample_count": len(indices),
                    **pooled_oof(
                        x[indices],
                        np.asarray(target, dtype=int),
                        splits,
                        int(class_count),
                        int(config["evaluation"]["inner_seed"]),
                    ),
                }
            )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    print(json.dumps({"output": str(output), "rows": len(rows)}, indent=2))


if __name__ == "__main__":
    main()
