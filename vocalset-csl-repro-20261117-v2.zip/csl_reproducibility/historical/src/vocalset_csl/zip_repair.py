"""Read the official VocalSet ZIP despite malformed pre-4GiB Zip64 offsets."""

from __future__ import annotations

import copy
import zipfile

FOUR_GIB = 2**32
LOCAL_HEADER_SIZE = 30
LOCAL_SIGNATURE = b"PK\x03\x04"
# General-purpose bit flag 11 denotes UTF-8 file names in the ZIP specification.
# ``zipfile._MASK_UTF_FILENAME`` was a private implementation detail and is absent
# in some supported Python versions.
UTF8_FILENAME_FLAG = 0x800


def _encoded_name(item: zipfile.ZipInfo) -> bytes:
    encoding = "utf-8" if item.flag_bits & UTF8_FILENAME_FLAG else "cp437"
    return item.orig_filename.encode(encoding)


def resolve_header_offset(archive: zipfile.ZipFile, item: zipfile.ZipInfo) -> int:
    """Return the candidate offset whose local header and filename both match."""

    candidates = [item.header_offset]
    if item.header_offset >= FOUR_GIB:
        candidates.append(item.header_offset - FOUR_GIB)
    expected_name = _encoded_name(item)
    original_position = archive.fp.tell() if archive.fp is not None else 0
    try:
        for offset in candidates:
            if offset < 0:
                continue
            archive.fp.seek(offset)
            header = archive.fp.read(LOCAL_HEADER_SIZE)
            if len(header) != LOCAL_HEADER_SIZE or header[:4] != LOCAL_SIGNATURE:
                continue
            name_length = int.from_bytes(header[26:28], "little")
            local_name = archive.fp.read(name_length)
            if local_name == expected_name:
                return offset
    finally:
        archive.fp.seek(original_position)
    raise zipfile.BadZipFile(f"No matching local header for {item.filename}")


def repaired_info(archive: zipfile.ZipFile, item: zipfile.ZipInfo) -> zipfile.ZipInfo:
    corrected = copy.copy(item)
    corrected.header_offset = resolve_header_offset(archive, item)
    return corrected


def open_repaired(archive: zipfile.ZipFile, item: zipfile.ZipInfo):
    return archive.open(repaired_info(archive, item))
